#ifndef STATE_MACHINE_NODE_H
#define STATE_MACHINE_NODE_H

#include <ros/ros.h>
#include <std_srvs/Empty.h>
#include <std_srvs/SetBool.h>
#include "sensor_msgs/Joy.h"
#include <luh_youbot_controller_api/controller_api.h>
#include <geometry_msgs/PoseStamped.h>
#include <math.h>
#include <autonome_navigation/api.h>
#include <tf/tf.h>


bool buttonPressedAndReleased(bool *button);


class StateMachineNode
{
public:
    StateMachineNode(ros::NodeHandle &nh);
    void run();

private:
    // functions
    void stateLoop();

    // youbot
    youbot_api::YoubotArm arm_;
    youbot_api::YoubotGripper gripper_;
    youbot_api::YoubotBase base_;
    navigation_api navigation_;


    // node handle
    ros::NodeHandle *node_;

    // ros communication

    ros::ServiceServer start_server_;
    ros::ServiceClient vision_client_;
    ros::ServiceClient area_client_;
    ros::ServiceClient thief_client_;
    ros::Subscriber pose_sub_;
    ros::Subscriber sad_sub_;
    ros::Subscriber thief_sub_;


    // parameters
    bool do_start_;
    std::vector<bool> platform_scanned_;
    std::vector<int> platform_counter_;
    int actual_platform_;
    std_srvs::SetBool enable_vison_;
    std_srvs::SetBool enable_area_;
    std_srvs::SetBool enable_thief_;
    std::string poses_file_;
    std::string tray_color_;
    bool searching_for_boxes_;
    bool lock_delete_pyramide_;

    bool thief_jumper_;




    // gripper
    bool gripper_loaded_;
    std::string drop_pose_;

    // Objectdetection
    geometry_msgs::PoseStamped pose_;
    geometry_msgs::PoseStamped safty_pose_;
    geometry_msgs::PoseStamped thief_;
    //Search on Area detection
    geometry_msgs::PoseStamped sad_;
    // Move arm on platform
    void moveArmTo(geometry_msgs::PoseStamped pose_in);



    // callbacks
    bool startCallback(std_srvs::Empty::Request &req, std_srvs::Empty::Response &res);
    void poseCallback(geometry_msgs::PoseStamped::ConstPtr msg);
    void sadCallback(geometry_msgs::PoseStamped::ConstPtr msg);
    void thiefCallback(geometry_msgs::PoseStamped::ConstPtr msg);
    void waitForMoveControl();
    void moveTo(std::string dest);


    // states
    enum
    {
      STATE_INITIALISE,
      STATE_DRIVE_TO_SERVICEAREA,
      STATE_SEARCH_OBJECTS,
      STATE_SEARCH_BOX,
      STATE_EMPTY_CARGO,
      STATE_SEARCH_ON_AREA,
      STATE_SEARCHING,
      STATE_PYRAMID,
      STATE_DECISION,
      STATE_FIRST_START,
      STATE_TRAY,
      STATE_RESCUE,
      STATE_THIEF




    }state_;

//----------------------------------------------------------------------------------------------
public:
    class CargoSlot
    {
    public:
      // constructor
      CargoSlot(StateMachineNode *sm ,std::string slot_position);
      CargoSlot(StateMachineNode *sm ,std::string slot_position, bool loaded);

      // functions to manipulate the slot
      bool placeObjectToSlot();
      bool pickObjectFromSlot();

      void pickColourFromSlot();
      void setLoadInfo(std::string name);
      void setLoadInfo(std::string name, std::string arg);

      // infoframtion functions
      bool isEmpty();
      std::string getObjectName();
      std::string getObjectArg();

      // bool to check is empty
      bool loaded_;


    private:
      StateMachineNode *sm_;
      void resetLoadInfo();

      // arm positions that are saved in parameters
      std::string slot_position_;


      // strings to save information
      std::string object_name_;
      std::string object_arg_;

    };
private:
    // cargo
    std::vector< CargoSlot > cargo_slots_;
};
//----------------------------------------------------------------------------------------------

#endif // STATE_MACHINE_NODE_H
