#include <state_machine/state_machine_node.h>
#include <autonome_navigation/api.h>

StateMachineNode::StateMachineNode(ros::NodeHandle &nh):
  node_(&nh),
  state_(STATE_INITIALISE),
  do_start_(false)
{
  // === PARAMETERS ===

  // === SUBSCRIBERS ===
  pose_sub_ = node_->subscribe("object_detection/object_pose", 1, &StateMachineNode::poseCallback, this);
  sad_sub_ = node_->subscribe("service_area_detection/object_pose", 1, &StateMachineNode::sadCallback, this);
  thief_sub_ = node_->subscribe("object_detection/objects_in_tray/object_pose", 1, &StateMachineNode::thiefCallback, this);

  // === PUBLISHERS ===

  // === SERVICE SERVERS ===
  start_server_ = node_->advertiseService("state_machine/start", &StateMachineNode::startCallback, this);

  // === SERVICE CLIENTS ===
  vision_client_ =node_->serviceClient<std_srvs::SetBool>("object_detection/trigger");
  area_client_ =node_->serviceClient<std_srvs::SetBool>("service_area_detection/trigger");
  thief_client_ =node_->serviceClient<std_srvs::SetBool>("object_detection/objects_in_tray/trigger");

}

//########## moveArmTo #################################################################################################
void StateMachineNode::moveArmTo(geometry_msgs::PoseStamped pose_in)
{
  double y_temp;
  double q5_temp;
  double theta_temp;
  // Pose from the Vison
  std::vector<double> pose;
  pose.resize(3);
  pose.at(0) = static_cast<double>(pose_in.pose.position.x);
  pose.at(1) = static_cast<double>(pose_in.pose.position.y);
  pose.at(2) = static_cast<double>(pose_in.pose.position.z);

  // Transform the pose[3] to the grip_pose[5] in the API
  luh_youbot_kinematics::CartesianPosition grip_pose;

  // Abfragen der Z-Höhe
  // entscheiden was bei welcher höhe gemacht wird
  // winkel Theta abhängig von der höhe berechnen / Staffeln, damit immer passend gegriffen wird


  // Calculate Grip poseangle Q5
  // y'=x sin(alpha)+ y cos(alpha)
  // q5= a+b*y'

  //      ROS_INFO("Calculating angle q5");

  y_temp=pose.at(0)*sin(0.57595865315813)+pose.at(1)*cos(0.57595865315813);
  q5_temp=1.5184364492351 -2.722713*y_temp;

  //      ROS_INFO("Angle q5 is %f",q5_temp);

  // Calculate Angle Theta
  // Abhängig von der Höhe -> Möglich Grenzen vorher schon abzufragen um zu gucken ob grip pose reachable ist?
  //ROS_INFO("Calculating angle theta");

  if (pose.at(2)< 0.15)
  {
    theta_temp=(M_PI/180)*165;
  }
  else if (pose.at(2)<0.16)
  {
    theta_temp=(M_PI/180)*164;
  }
  else if (pose.at(2)<0.17)
  {
    theta_temp=(M_PI/180)*163;
  }
  else if (pose.at(2)<0.18)
  {
    theta_temp=(M_PI/180)*162;
  }
  else if (pose.at(2)<0.19)
  {
    theta_temp=(M_PI/180)*161;
  }
  else if (pose.at(2)<0.20)
  {
    theta_temp=(M_PI/180)*160;
  }

  //      ROS_INFO("Calculated theta is %f", theta_temp);


  // Pose above the Object
  grip_pose.setX(static_cast<double>(pose.at(0)));
  grip_pose.setY(static_cast<double>(pose.at(1)));
  grip_pose.setZ(static_cast<double>(pose.at(2)-0.01));
  grip_pose.setTheta(theta_temp);
  grip_pose.setQ5(q5_temp);

  //      ROS_INFO_STREAM("Pose X:" << grip_pose.x());
  //      ROS_INFO_STREAM("Pose Y:" << grip_pose.y());
  //      ROS_INFO_STREAM("Pose Z:" << grip_pose.z());
  //      ROS_INFO_STREAM("Pose Theta:" << grip_pose.theta());
  //      ROS_INFO_STREAM("Pose q5:" << grip_pose.q5());

  gripper_.open();
  ros::Duration(1.0).sleep();

  // arm move to pre position
  arm_.moveToPose("PRE_GRIP");
  arm_.waitForCurrentAction();

  // arm move to pose + interpole
  arm_.moveToPose(grip_pose, youbot_api::MotionMode::INTERPOLATE);
  arm_.waitForCurrentAction();

  // gripp
  gripper_.setWidth(0);
  ros::Duration(1.0).sleep();
  gripper_loaded_=true;


  // ROS_INFO("befor INTERPOLATE in moveToArm");
  grip_pose.setZ(static_cast<double>(pose.at(2) + 0.04));
  arm_.moveToPose(grip_pose, youbot_api::MotionMode::INTERPOLATE);
  // ROS_INFO("after armMoveToPose in movetoArm");
  arm_.waitForCurrentAction();
  //ROS_INFO("After wait for action in moveToArm");


  return;

}

//########## RUN #######################################################################################################

void StateMachineNode::run()
{
  while(ros::ok())
  {
    stateLoop();
  }
}
//---------------------------------------------------------------------------------------------------------------------
void StateMachineNode::stateLoop()
{

  switch(state_)
  {
  //----------------------------------STATE_INITIALISE---------------------------------------------------------------
  case STATE_INITIALISE:
  {
    ROS_INFO("STATE: initialise.");

    // init cargo
    cargo_slots_.push_back(CargoSlot(this, "CARGO_1_CUBE", false));
    cargo_slots_.push_back(CargoSlot(this, "CARGO_2_CUBE", false));
    cargo_slots_.push_back(CargoSlot(this, "CARGO_3_CUBE", false));
    ROS_INFO("Cargo slots initiated...");

    gripper_loaded_ = false;
    drop_pose_="DROP_POSE";
    actual_platform_=0;

    ROS_WARN("SEARCHING for BOXES is enabeld");
    searching_for_boxes_=true;

    // Disable Object_detection
    enable_vison_.request.data = false;
    vision_client_.call(enable_vison_);

    // Disable Thief
    enable_thief_.request.data = false;
    vision_client_.call(enable_thief_);

    // Disable search_on_area_detection
    enable_area_.request.data = false;
    area_client_.call(enable_area_);

    // File for poses in navigation
    poses_file_="test.yaml";

    //Juping to thief and back
    thief_jumper_=false;
    lock_delete_pyramide_=false;

    // set an vector for the scanned platforms
    platform_scanned_.resize(7);
    platform_counter_.resize(7);
    std::fill (platform_scanned_.begin(),platform_scanned_.end(),false); // set all values to false

    // init youbot
    arm_.init(*node_);
    gripper_.init(*node_);
    base_.init(*node_);
    navigation_ = navigation_api(*node_);


    // open gripper
    gripper_.open();

    // Move Arm to Transport for driving
    arm_.moveToPose("TRANSPORT");
    arm_.waitForCurrentAction();

    ROS_INFO("Statemachine is initialised, ready to start");
    ROS_INFO("Write:");
    ROS_INFO("rosservice call /state_machine/start");
    ROS_INFO("in a new terminal");

    // wait for start signal
    // rosservice call /state_machine/start
    ros::Rate rate(10);
    while(ros::ok() && !do_start_)
    {
      rate.sleep();
      ros::spinOnce();
    }

    ROS_INFO("STATE_MASCHINE started");

    state_ = STATE_FIRST_START;
    //state_= STATE_SEARCH_OBJECTS;
    break;
  }
    //---------------------------------------------------------------------//
  case STATE_FIRST_START:
  {
    ROS_INFO("Move to next Pyramide");
    if (navigation_.nextPyramide())
    {
      state_=STATE_SEARCH_OBJECTS;
    }
    break;
  }
    //---------------------------------------------------------------------//
  case STATE_SEARCHING:
  {
    ROS_INFO("State: STATE_SEARCHING");
    // Scan order: 5 6 11 10 9 4 3

    bool finisher=false;
    bool rescue=false;

    // if platform scanned = false and finisher = false -> navigate to pose
    // if move to pose is true -> finisher = true -> exit state

    if (!platform_scanned_.at(0) && !finisher && platform_counter_.at(0) < 3)
    {
      ROS_INFO("Move to Pose Area 5");
      if(navigation_.moveToPose("service_area_5", poses_file_))
      {
        actual_platform_=0;
        finisher=true;
      }
      else
      {
        platform_counter_.at(0) ++;
      }
    }
    if (!platform_scanned_.at(1) && !finisher && platform_counter_.at(1) < 3)
    {
      ROS_INFO("Move to Pose Area 6");
      if(navigation_.moveToPose("service_area_6", poses_file_))
      {
        actual_platform_=1;
        finisher=true;
      }
      else
      {
        platform_counter_.at(1) ++;
      }
    }
    if (!platform_scanned_.at(2) && !finisher && platform_counter_.at(2) < 3)
    {
      ROS_INFO("Move to Pose Area 11");
      if(navigation_.moveToPose("service_area_11_l", poses_file_))
      {
        actual_platform_=2;
        finisher=true;
      }
      else
      {
        platform_counter_.at(2) ++;
      }
    }
    if (!platform_scanned_.at(3) && !finisher && platform_counter_.at(3) < 3)
    {
      ROS_INFO("Move to Pose Area 10");
      if(navigation_.moveToPose("service_area_10", poses_file_))
      {
        actual_platform_=3;
        finisher=true;
      }
      else
      {
        platform_counter_.at(3) ++;
      }
    }
    if (!platform_scanned_.at(4) && !finisher && platform_counter_.at(4) < 3)
    {
      ROS_INFO("Move to Pose Area 9");
      if(navigation_.moveToPose("service_area_9", poses_file_))
      {
        actual_platform_=4;
        finisher=true;
      }
      else
      {
        platform_counter_.at(4) ++;
      }
    }
    if (!platform_scanned_.at(5) && !finisher && platform_counter_.at(5) < 3)
    {
      ROS_INFO("Move to Pose Area 4");
      if(navigation_.moveToPose("service_area_4", poses_file_))
      {
        actual_platform_=5;
        finisher=true;
      }
      else
      {
        platform_counter_.at(5) ++;
      }
    }
    if (!platform_scanned_.at(6) && !finisher && platform_counter_.at(6) < 3)
    {
      ROS_INFO("Move to Pose Area 3");
      if(navigation_.moveToPose("service_area_3", poses_file_))
      {
        actual_platform_=6;
        finisher=true;
      }
      else
      {
        platform_counter_.at(0) ++;
        rescue=true;
      }

    }



    state_=STATE_SEARCH_ON_AREA;

    // Entering the rescue state
    if(rescue)
    {
      state_=STATE_RESCUE;
    }
    break;
  }
    //---------------------------------------------------------------------//
  case STATE_SEARCH_OBJECTS:
  {
    ROS_INFO("STATE: STATE_SEARCH_OBJECTS");

    //Approach to Plattform
    ROS_INFO("Approaching base to platform");
    base_.approach(0.07, 0.0);
    //base_.approach(0.08, 0.0);
    base_.waitForCurrentAction();

    bool empty_detected = false;

    for(int cargo_slot_num = 0; cargo_slot_num < cargo_slots_.size(); cargo_slot_num++)
    {
      //ROS_INFO("in while wit i =  %i", i);
      if (cargo_slots_[cargo_slot_num].isEmpty())
      {
        // move arm to search pose
        arm_.moveToPose("SEARCH_OBJECT");
        arm_.waitForCurrentAction();

        //Enable Vison
        enable_vison_.request.data = true;
        vision_client_.call(enable_vison_);
        ROS_INFO("Enable Object_detection");

        // Open Gripper for security reason
        gripper_.open();
        gripper_.waitForCurrentAction();

        // Wait 2 sec for detecting objects
        ros::Time last = ros::Time::now();
        ros::Rate rate(10);


        while((ros::Time::now() - last) < ros::Duration(2.0))
        {
          rate.sleep();
          ros::spinOnce();
        }


        //Wait for the Object detection if the last message is younger than 0.5
        while(!((ros::Time::now() - pose_.header.stamp) < ros::Duration(0.5)))
        {
          ROS_INFO("Timeout to detection");
          ros::Duration(0.5).sleep();
          ros::spinOnce();
        }

        //Disable Vison
        enable_vison_.request.data = false;
        vision_client_.call(enable_vison_);
        ROS_INFO("Disable Object_detection");

        // Break if no colour ist detected -> header is empty
        if(pose_.header.frame_id == "empty")
        {
          ROS_INFO("No Colour detected!! BREAK!!");
          empty_detected = true;
          break;
        }

        // grip object
        ROS_INFO_STREAM("Want to grip COLOR:   " << pose_.header.frame_id);
        moveArmTo(pose_);
        arm_.waitForCurrentAction();

        //place to cargo
        ROS_INFO("after wait for curent action in SM");
        cargo_slots_[cargo_slot_num].placeObjectToSlot();

        // save objectcolor
        ROS_INFO_STREAM("Set COLOR " << pose_.header.frame_id << " to Cargoslot " << cargo_slot_num);
        cargo_slots_[cargo_slot_num].setLoadInfo(pose_.header.frame_id, "empty");

        //open gripper for security reason
        gripper_.open();
        gripper_.waitForCurrentAction();


      }

    }


    if(!empty_detected)
    {
      // move arm to search pose
      arm_.moveToPose("SEARCH_OBJECT");
      arm_.waitForCurrentAction();

      //Enable Vison
      enable_vison_.request.data = true;
      vision_client_.call(enable_vison_);
      ROS_INFO("Enable Object_detection");

      // Wait 2 sec for detecting objects
      ros::Time last = ros::Time::now();
      ros::Rate rate(10);


      while((ros::Time::now() - last) < ros::Duration(2.0))
      {
        rate.sleep();
        ros::spinOnce();
      }


      //Wait for the Object detection if the last message is younger than 0.5
      while(!((ros::Time::now() - pose_.header.stamp) < ros::Duration(0.5)))
      {
        ROS_INFO_ONCE("Timeout to detection");
        ros::Duration(0.5).sleep();
        ros::spinOnce();
      }

      //Disable Vison
      enable_vison_.request.data = false;
      vision_client_.call(enable_vison_);
      ROS_INFO("Disable Object_detection");

      // Break if no colour ist detected -> header is empty
      if(pose_.header.frame_id == "empty")
      {
        ROS_INFO("Platform is empty");

        empty_detected = true;
      }

    }

    if(empty_detected && !lock_delete_pyramide_)
    {
      // if empty plattform delete position
      ROS_INFO("Deleting next Pyramide");
      navigation_.deleteNextPyramide();

    }

    // before to go to next state
    arm_.moveToPose("TRANSPORT");
    arm_.waitForCurrentAction();
    gripper_.open();
    gripper_loaded_=false;

    state_=STATE_DECISION;


    //Search only in the first state for boxes
    if(searching_for_boxes_)
    {
      state_=STATE_SEARCH_BOX;
      searching_for_boxes_=false;
    }

    lock_delete_pyramide_=false;
    break;

  }
    //---------------------------------------------------------------------//
  case STATE_DECISION:
  {

    int objects_on_cargo=0;

    ROS_INFO("State: STATE_DECISION");


    // Counting objects_on_cargo
    for(int i=0;i<3;i++)
    {
      if (!cargo_slots_[i].isEmpty())
      {
        objects_on_cargo++;
        //ROS_INFO("in for objects_on_cargo= %i",objects_on_cargo);
      }
    }
    //ROS_INFO("after for objects_on_cargo= %i",objects_on_cargo);
    // if cargo is emtpy -> drive to pyramid
    if(objects_on_cargo!=0)
    {

      state_ = STATE_TRAY;
    }
    else
    {
      state_ = STATE_PYRAMID;
    }
    break;
  }
    //---------------------------------------------------------------------//
  case STATE_PYRAMID:
  {
    ROS_INFO("State: STATE_PYRAMID");

    bool reachable=false;

    arm_.moveToPose("TRANSPORT");
    arm_.waitForCurrentAction();


    for(int i=0;i<3;i++)
    {
      ROS_INFO("The %i try to reach a pyramide", i);
      if(navigation_.nextPyramide())
      {
        //Approache to plattform
        ROS_INFO("Approaching base to platform to take a byte of the pyramide");
        base_.approach(0.07,0.0);
        //base_.approach(0.07,0.0);
        base_.waitForCurrentAction();
        reachable=true;
        break;
      }
    }

    /*
    // Fist try to navigate to a pyramide

    if(navigation_.nextPyramide())
    {
      ROS_INFO("First try to look for a nice pyramide");
      //Approache to plattform
      ROS_INFO("Approaching base to platform to take a byte of the pyramide");
      base_.approach(0.07,0.0);
      //base_.approach(0.07,0.0);
      base_.waitForCurrentAction();
      state_=STATE_SEARCH_OBJECTS;
      break;
    }

    //Second try to navigate to a pyramide

    if(navigation_.nextPyramide())
    {
      ROS_INFO("Second try to look for a nice pyramide");
      //Approache to plattform
      ROS_INFO("Approaching base to platform to take a byte of the pyramide");
      base_.approach(0.07,0.0);
      //base_.approach(0.07,0.0);
      base_.waitForCurrentAction();
      state_=STATE_SEARCH_OBJECTS;
      break;
    }

    //Last try to navigate to a pyramide

    if(navigation_.nextPyramide())
    {
      ROS_INFO("Last try to look for a nice pyramide");
      //Approache to plattform
      ROS_INFO("Approaching base to platform to take a byte of the pyramide");
      base_.approach(0.07,0.0);
      //base_.approach(0.07,0.0);
      base_.waitForCurrentAction();
      state_=STATE_SEARCH_OBJECTS;
      break;
    }
    */

    ROS_INFO("No pyramide reachable");
    state_=STATE_SEARCHING;

    if(reachable)
    {
      state_=STATE_SEARCH_OBJECTS;
    }

    break;

  }
    //---------------------------------------------------------------------//
  case STATE_TRAY:
  {
    ROS_INFO("State: STATE_TRAY");

    bool reachable=false;

    arm_.moveToPose("TRANSPORT");
    arm_.waitForCurrentAction();

    //calculate the colour in Cargo
    std::vector<std::string> colours;

    for (int i=0;i<3;i++)
    {

      if(cargo_slots_[i].getObjectName() == "yellow")
      {
        colours.push_back("yellow");
        colours.push_back("green");
        colours.push_back("red");
      }
      if(cargo_slots_[i].getObjectName() == "blue")
      {
        colours.push_back("blue");
        colours.push_back("green");
        colours.push_back("red");
      }
      if(cargo_slots_[i].getObjectName() == "green")
      {
        colours.push_back("red");
      }
      if(cargo_slots_[i].getObjectName() == "red")
      {

        colours.push_back("green");
      }

    }

    // Try to reach a Tray

    for(int i=0;i<3;i++)
    {
      ROS_INFO("The %i try to reach a tray",i);
      if(navigation_.nextTray(colours, tray_color_)) //DUMMY STRING
      {
        //Approache to plattform
        ROS_INFO_STREAM("From navigation get color: " << tray_color_);
        ROS_INFO("Approaching base to platform to empty tray");
        base_.approach(0.07,0.0);
        //base_.approach(0.05,0.0);
        base_.waitForCurrentAction();
        reachable=true;
        break;
      }
    }

    ROS_INFO("No Tray reachable");
    state_=STATE_SEARCHING;
    if (reachable)
    {
      state_=STATE_EMPTY_CARGO;
    }
    break;

  }
    //---------------------------------------------------------------------//
  case STATE_EMPTY_CARGO:
  {
    bool thief_trigger=false;
    bool object_detection_trigger=false;

    ROS_INFO("STATE: STATE_EMPTY_CARGO");
    arm_.moveToPose("TRANSPORT");
    arm_.waitForCurrentAction();

    // Place blue objectes in the blue tray
    if (tray_color_=="blue")
    {
      ROS_INFO("It's a blue tray, place blue objects in tray");
      for (int i = 0;i<3;i++)
      {
        if (cargo_slots_[i].getObjectName()=="blue")
        {
          cargo_slots_[i].pickObjectFromSlot();
        }
      }
     object_detection_trigger=true;


    }

    // Place yellow objects in the yellow tray
    if (tray_color_=="yellow")
    {
      ROS_INFO("It's a yellow tray, place yellow objects in tray");
      for (int i = 0;i<3;i++)
      {
        if (cargo_slots_[i].getObjectName()=="yellow")
        {
          cargo_slots_[i].pickObjectFromSlot();
        }
      }
      object_detection_trigger=true;

    }

    // Place red in the green tray
    if (tray_color_=="green")
    {
      ROS_INFO("It's a green tray, place !green objects in tray");
      for (int i = 0;i<3;i++)
      {
        if (cargo_slots_[i].getObjectName()!="green" && cargo_slots_[i].getObjectName()!= "")
        {
          cargo_slots_[i].pickObjectFromSlot();
        }
      }
      thief_trigger=true;


    }
    // Place green in the red tray
    if (tray_color_=="red")
    {
      ROS_INFO("It's a red tray, place !red objects in tray");
      for (int i = 0;i<3;i++)
      {
        if (cargo_slots_[i].getObjectName()!="red" && cargo_slots_[i].getObjectName()!= "")
        {
          cargo_slots_[i].pickObjectFromSlot();
        }
      }
      thief_trigger=true;

    }
    ROS_INFO("CARGOs are empty");


    ROS_WARN("THIEF mode is deaktivated on red and green!!");
    thief_trigger=false;
    ROS_WARN("OBJECT_detection on yellow and blue ENABLED");
    object_detection_trigger=false;
    state_=STATE_DECISION;

    if(object_detection_trigger)
    {
      state_=STATE_SEARCH_OBJECTS;
      lock_delete_pyramide_=true;
    }


    if(thief_trigger)
    {
      state_=STATE_THIEF;

    }
    break;
  }
    //---------------------------------------------------------------------//
  case STATE_SEARCH_BOX:
  {

    ROS_INFO("State: STATE_SEARCH_BOX");
    int boxes=0;
    int max_hidden_area=0;
    bool finish_hidden_tray=false;

    while(!finish_hidden_tray)
    {

      //navigate to hidden tray
      if(navigation_.nextHiddenTray())
      {

        //move arm to detection pose
        arm_.moveToPose("JOY_CONTROLL");
        arm_.waitForCurrentAction();

        //Enable Search_on_area_detection
        enable_area_.request.data = true;
        area_client_.call(enable_area_);
        ROS_INFO("Enable Service_on_area_detection");

        //Waiting for Result
        ros::Time last = ros::Time::now();
        ros::Rate rate(10);
        while((ros::Time::now() - last) < ros::Duration(1.0))
        {
          rate.sleep();
          ros::spinOnce();
        }

        //Wait for the Object detection if the last message is younger than 0.5
        while(!((ros::Time::now() - sad_.header.stamp) < ros::Duration(0.5)))
        {
          ROS_INFO_ONCE("Timeout to detection");
          ros::Duration(0.3).sleep();
          ros::spinOnce();
        }

        //Disable Search_on_area_detection
        enable_area_.request.data = false;
        area_client_.call(enable_area_);
        ROS_INFO("Disable Service_on_area_detection");

        //move arm to detection pose
        arm_.moveToPose("TRANSPORT");
        arm_.waitForCurrentAction();

        if (sad_.pose.position.z==0)
        {
          ROS_INFO_STREAM("Detect Tray -> Save Tray with Color  " << sad_.header.frame_id);

          //Approache to plattform
          ROS_INFO("Approaching base to platform to search on area");
          base_.approach(0.10,0.0);
          //base_.approach(0.07,0.0);
          base_.waitForCurrentAction();
          navigation_.saveTray(sad_.pose.position.y, sad_.header.frame_id);
          boxes++;

          ROS_INFO("Deleting next hidden tray");
          navigation_.deleteNextHiddenTray();
        }
        else
        {
          ROS_INFO("Deleting next hidden Tray");
          navigation_.deleteNextHiddenTray();
        }

      }

      max_hidden_area++;

      if(max_hidden_area==10 || boxes==2)
      {
        finish_hidden_tray=true;
      }

    }

    state_=STATE_DECISION;
    break;
  }
    //---------------------------------------------------------------------//
  case STATE_SEARCH_ON_AREA:
  {
    ROS_INFO("State: STATE_SEARCH_ON_AREA");

    std::string search_pose;


    //Approache to plattform
    ROS_INFO("Approaching base to platform to search on area");
    base_.approach(0.07,0.0);
    //base_.approach(0.07,0.0);
    base_.waitForCurrentAction();

    for(int t=0;t<3;t++)
    {
      //ROS_INFO("in State_search_on_area: t is %i",t);
      //Detect objects on the left side on the area
      if(t==0) {search_pose="DETECT_LEFT";}
      if(t==1) {search_pose="SEARCH_OBJECT";}
      if(t==2) {search_pose="DETECT_RIGHT";}

      ROS_INFO_STREAM("Move to " << search_pose);
      arm_.moveToPose(search_pose);
      arm_.waitForCurrentAction();

      //Enable Search_on_area_detection
      enable_area_.request.data = true;
      area_client_.call(enable_area_);
      ROS_INFO("Enable Service_on_area_detection");

      //Waiting for Result
      ros::Time last = ros::Time::now();
      ros::Rate rate(10);
      while((ros::Time::now() - last) < ros::Duration(1.0))
      {
        rate.sleep();
        ros::spinOnce();
      }

      //Wait for the Object detection if the last message is younger than 0.5
      while(!((ros::Time::now() - sad_.header.stamp) < ros::Duration(0.5)))
      {
        ROS_INFO_ONCE("Timeout to detection");
        ros::Duration(0.3).sleep();
        ros::spinOnce();
      }


      ROS_INFO_STREAM("Z from object_detection z=  " << sad_.pose.position.z);

      if (sad_.pose.position.z==0)
      {
        ROS_INFO_STREAM("Detect Tray -> Save Tray with Color  " << sad_.header.frame_id);
        navigation_.saveTray(sad_.pose.position.y, sad_.header.frame_id); // y angeben bitte jan
      }
      else if (sad_.pose.position.z==1)
      {
        ROS_INFO("Detect small pyramide -> Save small pyramide");
        navigation_.savePyramide(sad_.pose.position.y); // y angeben bitte jan
      }

      else
      {
        ROS_INFO("Detect nothing -> Save nothing");
      }
    }

    //Disable Search_on_area_detection
    enable_area_.request.data = false;
    area_client_.call(enable_area_);
    ROS_INFO("Disable Service_on_area_detection");



    //Mark scanned platform as true
    platform_scanned_.at(actual_platform_)=true;

    state_=STATE_DECISION;
    break;
  }
    //---------------------------------------------------------------------//
  case STATE_RESCUE:
  {
    ROS_INFO("State: STATE_RESCUE");

    //navigate to rescue pose
    if(!navigation_.moveToPose("drop_pose",poses_file_))
    {
      navigation_.moveToPose("service_area_1", poses_file_);
    }

    //Temp save the drop pose
    std::string temp=drop_pose_;
    //drop_pose_="DROP_BACK";
    drop_pose_="PRESENT";
    for(int i=0;i<3;i++)
    {
      if(!cargo_slots_[i].isEmpty())
      {
        cargo_slots_[i].pickObjectFromSlot();
      }
    }

    // place the original drop pose in the global string
    drop_pose_=temp;

    state_=STATE_PYRAMID;
    break;
  }
    //---------------------------------------------------------------------//
  case STATE_THIEF:
  {
    ROS_INFO("State: STATE_THIEF");


    for(int cargo_slot_num = 0; cargo_slot_num < cargo_slots_.size(); cargo_slot_num++)
    {
      //ROS_INFO("in while wit i =  %i", i);
      if (cargo_slots_[cargo_slot_num].isEmpty())
      {
        // move arm to search pose
        arm_.moveToPose("SEARCH_OBJECT");
        arm_.waitForCurrentAction();

        //Enable Vison
        enable_thief_.request.data = true;
        vision_client_.call(enable_thief_);
        ROS_INFO("Enable Object_detection");

        // Open Gripper for security reason
        gripper_.open();
        gripper_.waitForCurrentAction();

        // Wait 2 sec for detecting objects
        ros::Time last = ros::Time::now();
        ros::Rate rate(10);


        while((ros::Time::now() - last) < ros::Duration(2.0))
        {
          rate.sleep();
          ros::spinOnce();
        }


        //Wait for the Object detection if the last message is younger than 0.5
        while(!((ros::Time::now() - thief_.header.stamp) < ros::Duration(0.5)))
        {
          ROS_INFO("Timeout to detection");
          ros::Duration(0.5).sleep();
          ros::spinOnce();
        }

        //Disable Vison
        enable_thief_.request.data = false;
        vision_client_.call(enable_thief_);
        ROS_INFO("Disable Object_detection thief");

        // Break if no colour ist detected -> header is empty
        if(thief_.header.frame_id == "empty")
        {
          ROS_INFO("No Colour detected!! BREAK!!");
          break;
        }

        // grip object
        ROS_INFO_STREAM("Want to grip COLOR:   " << thief_.header.frame_id);
        moveArmTo(thief_);
        arm_.waitForCurrentAction();

        //place to cargo
        //ROS_INFO("after wait for curent action in SM");
        cargo_slots_[cargo_slot_num].placeObjectToSlot();

        // save objectcolor
        ROS_INFO_STREAM("Set COLOR " << thief_.header.frame_id << " to Cargoslot " << cargo_slot_num);
        cargo_slots_[cargo_slot_num].setLoadInfo(thief_.header.frame_id, "empty");

        //open gripper for security reason
        gripper_.open();
        gripper_.waitForCurrentAction();


      }

    }

    state_=STATE_DECISION;
    break;
  }
    //---------------------------------------------------------------------//
  }
}

//########################################################################################################################################################
//########################################################################################################################################################
//########################################################################################################################################################
//########################################################################################################################################################
//########################################################################################################################################################



//########## START SERVICE CALLBACK ####################################################################################
bool StateMachineNode::startCallback(std_srvs::Empty::Request &req, std_srvs::Empty::Response &res)
{
  do_start_ = true;
  return true;
}
//############### OBJECT DETECTION SUBSCRIBER #############################################################################
void StateMachineNode::poseCallback(const geometry_msgs::PoseStamped::ConstPtr msg)
{

  pose_ = *msg;
  //ROS_INFO_STREAM(pose_);
}

void StateMachineNode::thiefCallback(const geometry_msgs::PoseStamped::ConstPtr msg)
{

  thief_ = *msg;

}
//############### SERVICE AREA DETECTION SUBSCRIBER #############################################################################

void StateMachineNode::sadCallback(const geometry_msgs::PoseStamped::ConstPtr msg)
{

  //z=0 -> Tray
  //z=1 -> Pyramide
  //z=2 -> Empty
  sad_ = *msg;
  //ROS_INFO("sadCallback recieved");
  //ROS_INFO_STREAM("Recieved time is "<<sad_.header.stamp);
  //ROS_INFO_STREAM(pose_);
}

//##############################################################################
//############################## CARGO #########################################
//##############################################################################

StateMachineNode::CargoSlot::CargoSlot(StateMachineNode *sm, std::string slot_position)
{
  slot_position_ = slot_position;

  sm_ = sm;

  loaded_ = false;
  object_name_ = "none";
  object_arg_ = "none";

}
StateMachineNode::CargoSlot::CargoSlot(StateMachineNode *sm, std::string slot_position, bool loaded)
{
  slot_position_ = slot_position;
  loaded_ = loaded;

  sm_ = sm;

  object_name_ = "none";
  object_arg_ = "none";
}

//############################## getObjectARG #######################################
std::string StateMachineNode::CargoSlot::getObjectArg()
{
  return object_arg_;
}

//############################## getObjectName #######################################
std::string StateMachineNode::CargoSlot::getObjectName()
{
  return object_name_;
}
//############################## LOAD ##############################
void StateMachineNode::CargoSlot::setLoadInfo(std::string name)
{
  object_name_ = name;
}

void StateMachineNode::CargoSlot::setLoadInfo(std::string name, std::string arg)
{
  object_name_ = name;
  object_arg_ = arg;
}

//############################## isEmpty #######################################
bool StateMachineNode::CargoSlot::isEmpty()
{
  if(!loaded_){
    return true;
  }else
  {
    return false;
  }
}


//############################## placeObjectToSlot #######################################
bool StateMachineNode::CargoSlot::placeObjectToSlot()
{
  //ROS_INFO_STREAM(sm_->gripper_loaded_);
  //ROS_INFO("before sm-> cargo");
  if(sm_->gripper_loaded_)
  {
    //ROS_INFO("in placeObjectToSlot in if");
    //ROS_INFO_STREAM("slot_position_ in placeObjectToSlot   "<< slot_position_);
    sm_->arm_.moveToPose(slot_position_);
    //ROS_INFO("In placeObjectToSlot after moveToPose");
    sm_->arm_.waitForCurrentAction();

    // gripper auf
    sm_->gripper_.open();
    //ros::Duration(0.8).sleep();
    sm_->gripper_.waitForCurrentAction();

    // move back??

    loaded_ = true;
  }
  return true;
}


//############################## pickObjectFromSlot #######################################
bool StateMachineNode::CargoSlot::pickObjectFromSlot()
{
  ROS_INFO("PICK OBJECT FROM SLOT");
  if(!sm_->gripper_loaded_)
  {
    ROS_INFO("OPEN GRIPPER");
    // gripper auf
    sm_->gripper_.open();
    sm_->gripper_.waitForCurrentAction();

    ROS_INFO("Arm move to cargo %s",slot_position_.c_str());

    // move to pose
    sm_->arm_.moveToPose(slot_position_);
    sm_->arm_.waitForCurrentAction();

    ROS_INFO("CLOSE GRIPPER");
    // grip
    sm_->gripper_.setWidth(0);
    sm_->gripper_.waitForCurrentAction();
    ros::Duration(0.5).sleep();

    sm_->gripper_loaded_ = true;
    loaded_ = false;
    object_name_="";
    object_arg_="";

    ROS_INFO("MOVE DROP POSE");

    //    // move arm to def pos to drop the object on the table
    sm_->arm_.moveToPose(sm_->drop_pose_);
    sm_->arm_.waitForCurrentAction();

    // gripper open
    sm_->gripper_.open();
    sm_->gripper_.waitForCurrentAction();
    sm_->gripper_loaded_ = false;
    ros::Duration(0.5).sleep();

    ROS_INFO("Gripper opened");


  }
  return true;

}


//############################### MAIN ##########################################
int main(int argc, char **argv)
{
  ros::init(argc, argv, "state_machine_node");
  ros::NodeHandle nh;

  StateMachineNode state_machine_node(nh);

  ROS_INFO("state_machine_node is spinning...");
  state_machine_node.run();


  ros::spin();

  return 0;
}
