/* *****************************************************************
 *
 * object_detection
 *
 * Copyright (c) %YEAR%,
 * Institute of Mechatronic Systems,
 * Leibniz Universitaet Hannover.
 * (BSD License)
 * All rights reserved.
 *
 * http://www.imes.uni-hannover.de
 *
 * This software is distributed WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE.
 *
 * For further information see http://www.linfo.org/bsdlicense.html
 *
 ******************************************************************/

/**
 * @file   %FILENAME%
 * @author %USER% (%$EMAIL%)
 * @date   %DATE%
 *
 * @brief  Filedescription
 */

#include "object_detection/object_detection_node.h"



using namespace cv;
using namespace std;



//########## CONSTRUCTOR ###############################################################################################
ObjectDetection::ObjectDetection(ros::NodeHandle &node_handle):
  node_(&node_handle),
  it_(node_handle)
{
  // publisher/subscriber
  trigger_ = node_->advertiseService("object_detection/trigger", &ObjectDetection::serviceTrigger, this);
  trigger2_ = node_->advertiseService("service_area_detection/trigger", &ObjectDetection::serviceTrigger2, this);
  trigger3_ = node_->advertiseService("objects_in_tray_detection/trigger", &ObjectDetection::serviceTrigger3, this);
  trigger4_ = node_->advertiseService("objects_in_tray_detection/trigger2", &ObjectDetection::serviceTrigger4, this);
  //point_cloud_sub_ = node_->subscribe("camera/depth_registered/points_corrected", 1, &ObjectDetection::pointCloudCallback, this);
  //point_cloud_sub_ = node_->subscribe("camera/depth_registered/points", 1, &ObjectDetection::pointCloudCallback, this);
  image_pub_ = it_.advertise("object_detection/debug_image", 1);
  image_pub_result_ = it_.advertise("object_detection/result", 1);
  //image_sub_ = it_.subscribe("/camera/rgb/image_raw", 1, &ObjectDetection::imageCallback, this);
  camera_sub_ = node_->subscribe("/camera/rgb/camera_info", 1, &ObjectDetection::cameraCallback, this);
  object_pub_ = node_->advertise<geometry_msgs::PoseStamped>("object_detection/object_pose", 1);
  object_pub2_ = node_->advertise<geometry_msgs::PoseStamped>("service_area_detection/object_pose", 1);
  object_pub3_ = node_->advertise<geometry_msgs::PoseStamped>("objects_in_tray_detection/object_pose", 1);
  object_pub4_ = node_->advertise<geometry_msgs::PoseStamped>("objects_in_tray_detection2/object_pose", 1);



  //image_sub_.shutdown();

  // dynamic reconfigure
  dynamic_reconfigure::Server<object_detection::ObjectDetectionConfig>::CallbackType f;
  f = boost::bind(&ObjectDetection::dynamicReconfigureCallback, this, _1, _2);
  dyn_reconf_server_.setCallback(f);
}



//########## DESTRUCTOR ################################################################################################
ObjectDetection::~ObjectDetection()
{

}

bool ObjectDetection::serviceTrigger(std_srvs::SetBool::Request &req, std_srvs::SetBool::Response &res)
{
  bool status = req.data;

  if(status)
  {
    mode_ = 0;
    image_sub_ = it_.subscribe("/camera/rgb/image_raw", 1, &ObjectDetection::imageCallback, this);
    //    point_cloud_sub_ = node_->subscribe("camera/depth_registered/points_corrected", 1, &ObjectDetection::pointCloudCallback, this);
    point_cloud_sub_ = node_->subscribe("camera/depth_registered/points", 1, &ObjectDetection::pointCloudCallback, this);
    res.message = "object detection turned on";
  }else
  {
    //image_sub_ = it_.subscribe("/camera/empty_topic", 1, &ObjectDetection::imageCallback, this);
    image_sub_.shutdown();
    point_cloud_sub_.shutdown();
    res.message = "object detection turned off";
  }
  return true;
}

bool ObjectDetection::serviceTrigger2(std_srvs::SetBool::Request &req, std_srvs::SetBool::Response &res)
{
  bool status = req.data;

  if(status)
  {
    mode_ = 1;
    image_sub_ = it_.subscribe("/camera/rgb/image_raw", 1, &ObjectDetection::imageCallback, this);
    //     point_cloud_sub_ = node_->subscribe("camera/depth_registered/points_corrected", 1, &ServiceAreaDetection::pointCloudCallback, this);
    point_cloud_sub_ = node_->subscribe("camera/depth_registered/points", 1, &ObjectDetection::pointCloudCallback, this);
    res.message = "service area detection turned on";
  }else
  {
    //image_sub_ = it_.subscribe("/camera/empty_topic", 1, &ServiceAreaDetection::imageCallback, this);
    image_sub_.shutdown();
    point_cloud_sub_.shutdown();
    res.message = "service area detection turned off";
  }
  return true;
}

bool ObjectDetection::serviceTrigger3(std_srvs::SetBool::Request &req, std_srvs::SetBool::Response &res)
{
  bool status = req.data;

  if(status)
  {
    mode_ = 2;
    image_sub_ = it_.subscribe("/camera/rgb/image_raw", 1, &ObjectDetection::imageCallback, this);
    //     point_cloud_sub_ = node_->subscribe("camera/depth_registered/points_corrected", 1, &ServiceAreaDetection::pointCloudCallback, this);
    point_cloud_sub_ = node_->subscribe("camera/depth_registered/points", 1, &ObjectDetection::pointCloudCallback, this);
    res.message = "objects in tray detection turned on";
  }else
  {
    //image_sub_ = it_.subscribe("/camera/empty_topic", 1, &ServiceAreaDetection::imageCallback, this);
    image_sub_.shutdown();
    point_cloud_sub_.shutdown();
    res.message = "objects in tray detection turned off";
  }
  return true;
}

bool ObjectDetection::serviceTrigger4(std_srvs::SetBool::Request &req, std_srvs::SetBool::Response &res)
{
  bool status = req.data;

  if(status)
  {
    mode_ = 3;
    image_sub_ = it_.subscribe("/camera/rgb/image_raw", 1, &ObjectDetection::imageCallback, this);
    //     point_cloud_sub_ = node_->subscribe("camera/depth_registered/points_corrected", 1, &ServiceAreaDetection::pointCloudCallback, this);
    point_cloud_sub_ = node_->subscribe("camera/depth_registered/points", 1, &ObjectDetection::pointCloudCallback, this);
    res.message = "objects in tray detection turned on";
  }else
  {
    //image_sub_ = it_.subscribe("/camera/empty_topic", 1, &ServiceAreaDetection::imageCallback, this);
    image_sub_.shutdown();
    point_cloud_sub_.shutdown();
    res.message = "objects in tray detection turned off";
  }
  return true;
}

//########## CAMERA CALLBACK ############################################################################################
void ObjectDetection::cameraCallback(const sensor_msgs::CameraInfoConstPtr &info_msg)
{
  // save camera parameters to camera model
  camera_model_.fromCameraInfo(info_msg);
}

//########## IMAGE CALLBACK ############################################################################################
void ObjectDetection::imageCallback(const sensor_msgs::ImageConstPtr& image_msg)
{
  // convert image to cv::Mat
  cv_bridge::CvImagePtr input_bridge;
  try {
    input_bridge = cv_bridge::toCvCopy(image_msg, sensor_msgs::image_encodings::BGR8);
    rgb_img = input_bridge->image;
  }
  catch (cv_bridge::Exception& ex){
    ROS_ERROR("Failed to convert image");
  }
}

//########## POINTCLOUD CALLBACK #######################################################################################
void ObjectDetection::pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr& input)
{
  if(mode_ == 0)
  {
    // Prüfen, ob RGB-Bild und Kamerainfo verfügbar sind
    if(!camera_model_.initialized() || rgb_img.empty())
      return;

    // Punktwolke in PCL-Datentyp konvertieren
    pcl::PointCloud<pcl::PointXYZRGB> cloud;

    pcl::fromROSMsg (*input, cloud);
    std_msgs::Header pc_header = input->header;

    // HSV-Farbraum
    // Zweiter Index = 0: h_min
    // Zweiter Index = 1: h_max
    // Zweiter Index = 2: s_min
    // Zweiter Index = 3: s_max
    // Zweiter Index = 4: v_min
    // Zweiter Index = 5: v_max

    vector<vector<float> > hsvTable(5,vector<float>(6));

    // BLAU: Erster Index = 0
    hsvTable[0][0] =   0;
    hsvTable[0][1] =  20;
    hsvTable[0][2] =  60;
    hsvTable[0][3] = 255;
    hsvTable[0][4] =  40;
    hsvTable[0][5] = 255;

    // GRÜN: Erster Index = 1
    hsvTable[1][0] =  40;
    hsvTable[1][1] =  70;
    hsvTable[1][2] =  60;
    hsvTable[1][3] = 255;
    hsvTable[1][4] =  40;
    hsvTable[1][5] = 255;

    // GELB: Erster Index = 2
    hsvTable[2][0] =  80;
    hsvTable[2][1] = 100;
    hsvTable[2][2] =  60;
    hsvTable[2][3] = 255;
    hsvTable[2][4] =  40;
    hsvTable[2][5] = 255;

    // ROT: Erster Index = 3
    hsvTable[3][0] = 110;
    hsvTable[3][1] = 130;
    hsvTable[3][2] =  60;
    hsvTable[3][3] = 255;
    hsvTable[3][4] =  40;
    hsvTable[3][5] = 255;

    std::vector<ObjectProperties> objects_level_4;
    std::vector<ObjectProperties> objects_level_3;
    std::vector<ObjectProperties> objects_level_2;
    std::vector<ObjectProperties> objects_level_1;

    objects_level_4.resize(4);
    objects_level_3.resize(4);
    objects_level_2.resize(4);
    objects_level_1.resize(4);

    std::vector<bool> objects_detected_level_4;
    std::vector<bool> objects_detected_level_3;
    std::vector<bool> objects_detected_level_2;
    std::vector<bool> objects_detected_level_1;

    objects_detected_level_4.resize(4);
    objects_detected_level_3.resize(4);
    objects_detected_level_2.resize(4);
    objects_detected_level_1.resize(4);

    int index_closest_level_4;
    int index_closest_level_3;
    int index_closest_level_2;
    int index_closest_level_1;

    std::vector<bool> closest_object_detected_level_4;
    std::vector<bool> closest_object_detected_level_3;
    std::vector<bool> closest_object_detected_level_2;
    std::vector<bool> closest_object_detected_level_1;

    closest_object_detected_level_1.resize(4);
    closest_object_detected_level_2.resize(4);
    closest_object_detected_level_3.resize(4);
    closest_object_detected_level_4.resize(4);


    double closest_distance_level_4;
    double closest_distance_level_3;
    double closest_distance_level_2;
    double closest_distance_level_1;

    closest_distance_level_4 = -0.10;
    closest_distance_level_3 = -0.10;
    closest_distance_level_2 = -0.10;
    closest_distance_level_1 = -0.10;

    //    ROS_INFO("########### SEARCH COLORS LEVEL 4 ##############");
    morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*35+1, 2*35+1),
                                                cv::Point(35, 35));
    morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*30+1, 2*30+1),
                                                cv::Point(30, 30));
    morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*2+1, 2*2+1),
                                                cv::Point(2, 2));

    for(int i = 0; i < 4; i++)
    {
      object_detected = false;

      h_min_ = hsvTable[i][0];
      h_max_ = hsvTable[i][1];
      s_min_ = hsvTable[i][2];
      s_max_ = hsvTable[i][3];
      v_min_ = hsvTable[i][4];
      v_max_ = hsvTable[i][5];

      cv::Mat raw_mask = createObjectMask(cloud);
      cv::Mat filtered_mask = filterObjectMask(raw_mask);
      clearBorder(filtered_mask);
      cv::Mat object_mask = selectBlob(filtered_mask);
      ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

      if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
      {
        //        ROS_INFO_STREAM("Color " << i << " NOT detected in level 4");
        objects_detected_level_4.at(i) = false;
        continue;
      }
      else
      {
        //        ROS_INFO_STREAM("Color " << i << " is detected in level 4");
        objects_detected_level_4.at(i) = true;
      }

      objects_level_4.at(i) = transformProperties(object_properties, pc_header);
    }

    //    ROS_INFO("########### SEARCH CLOSEST OBJECT IN LEVEL 4 ##############");
    for(int i = 0; i < 4 ; i++)
    {
      if(objects_detected_level_4.at(i) && objects_level_4.at(i).center.z > closest_distance_level_4)
      {
        index_closest_level_4 = i;
        closest_distance_level_4 = objects_level_4.at(i).center.z;
        closest_object_detected_level_4.at(i) = true;
      }
      else
      {
        closest_object_detected_level_4.at(i) = false;
      }
    }


    //    ROS_INFO("########### SEARCH COLORS LEVEL 3 ##############");
    morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*30+1, 2*30+1),
                                                cv::Point(30, 30));
    morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*25+1, 2*25+1),
                                                cv::Point(25, 25));
    morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*2+1, 2*2+1),
                                                cv::Point(2, 2));

    for(int i = 0; i < 4; i++)
    {
      object_detected = false;

      h_min_ = hsvTable[i][0];
      h_max_ = hsvTable[i][1];
      s_min_ = hsvTable[i][2];
      s_max_ = hsvTable[i][3];
      v_min_ = hsvTable[i][4];
      v_max_ = hsvTable[i][5];

      cv::Mat raw_mask = createObjectMask(cloud);
      cv::Mat filtered_mask = filterObjectMask(raw_mask);
      clearBorder(filtered_mask);
      cv::Mat object_mask = selectBlob(filtered_mask);
      ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

      if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
      {
        //        ROS_INFO_STREAM("Color " << i << " NOT detected in level 3");
        objects_detected_level_3.at(i) = false;
        continue;
      }
      else
      {
        //        ROS_INFO_STREAM("Color " << i << " is detected in level 3");
        objects_detected_level_3.at(i) = true;
      }

      objects_level_3.at(i) = transformProperties(object_properties, pc_header);
    }

    //    ROS_INFO("########### SEARCH CLOSEST OBJECT IN LEVEL 3 ##############");
    for(int i = 0; i < 4 ; i++)
    {
      if(objects_detected_level_3.at(i) && objects_level_3.at(i).center.z > closest_distance_level_3)
      {
        index_closest_level_3 = i;
        closest_distance_level_3 = objects_level_3.at(i).center.z;
        closest_object_detected_level_3.at(i) = true;
      }
      else
      {
        closest_object_detected_level_3.at(i) = false;
      }
    }

    //    ROS_INFO("########### SEARCH COLORS LEVEL 2 ##############");
    morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*25+1, 2*25+1),
                                                cv::Point(25, 25));
    morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*20+1, 2*20+1),
                                                cv::Point(20, 20));
    morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*2+1, 2*2+1),
                                                cv::Point(2, 2));

    for(int i = 0; i < 4; i++)
    {
      object_detected = false;

      h_min_ = hsvTable[i][0];
      h_max_ = hsvTable[i][1];
      s_min_ = hsvTable[i][2];
      s_max_ = hsvTable[i][3];
      v_min_ = hsvTable[i][4];
      v_max_ = hsvTable[i][5];

      cv::Mat raw_mask = createObjectMask(cloud);
      cv::Mat filtered_mask = filterObjectMask(raw_mask);
      clearBorder(filtered_mask);
      cv::Mat object_mask = selectBlob(filtered_mask);
      ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

      if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
      {
        //        ROS_INFO_STREAM("Color " << i << " NOT detected in level 2");
        objects_detected_level_2.at(i) = false;
        continue;
      }
      else
      {
        //        ROS_INFO_STREAM("Color " << i << " is detected in level 2");
        objects_detected_level_2.at(i) = true;
      }

      objects_level_2.at(i) = transformProperties(object_properties, pc_header);
    }

    //    ROS_INFO("########### SEARCH CLOSEST OBJECT IN LEVEL 2 ##############");
    for(int i = 0; i < 4 ; i++)
    {
      if(objects_detected_level_2.at(i) && objects_level_2.at(i).center.z > closest_distance_level_2)
      {
        index_closest_level_2 = i;
        closest_distance_level_2 = objects_level_2.at(i).center.z;
        closest_object_detected_level_2.at(i) = true;
      }
      else
      {
        closest_object_detected_level_2.at(i) = false;
      }
    }


    //    ROS_INFO("########### SEARCH COLORS LEVEL 1 ##############");
    morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*20+1, 2*20+1),
                                                cv::Point(20, 20));
    morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*15+1, 2*15+1),
                                                cv::Point(15, 15));
    morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*2+1, 2*2+1),
                                                cv::Point(2, 2));

    for(int i = 0; i < 4; i++)
    {
      object_detected = false;

      h_min_ = hsvTable[i][0];
      h_max_ = hsvTable[i][1];
      s_min_ = hsvTable[i][2];
      s_max_ = hsvTable[i][3];
      v_min_ = hsvTable[i][4];
      v_max_ = hsvTable[i][5];

      cv::Mat raw_mask = createObjectMask(cloud);
      cv::Mat filtered_mask = filterObjectMask(raw_mask);
      clearBorder(filtered_mask);
      cv::Mat object_mask = selectBlob(filtered_mask);
      ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

      if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
      {
        //        ROS_INFO_STREAM("Color " << i << " NOT detected in level 1");
        objects_detected_level_1.at(i) = false;
        continue;
      }
      else
      {
        //        ROS_INFO_STREAM("Color " << i << " is detected in level 1");
        objects_detected_level_1.at(i) = true;
      }

      objects_level_1.at(i) = transformProperties(object_properties, pc_header);
    }

    //    ROS_INFO("########### SEARCH CLOSEST OBJECT IN LEVEL 1 ##############");
    for(int i = 0; i < 4 ; i++)
    {
      if(objects_detected_level_1.at(i) && objects_level_1.at(i).center.z > closest_distance_level_1)
      {
        index_closest_level_1 = i;
        closest_distance_level_1 = objects_level_1.at(i).center.z;
        closest_object_detected_level_1.at(i) = true;
      }
      else
      {
        closest_object_detected_level_1.at(i) = false;
      }
    }



    // handle for closest object
    std_msgs::Header new_head = input->header;

    for(int i = 0; i < 4; i++)
    {
      if(closest_object_detected_level_4.at(i))
      {
        if(index_closest_level_4 == 0)
        {
          //          ROS_INFO_STREAM("closest object is BLUE with distance:    " << closest_distance_level_4);
          new_head.frame_id = "blue";
        }
        else if(index_closest_level_4 == 1)
        {
          //          ROS_INFO_STREAM("closest object is GREEN with distance:   " << closest_distance_level_4);
          new_head.frame_id = "green";
        }
        else if(index_closest_level_4 == 2)
        {
          //          ROS_INFO_STREAM("closest object is YELLOW with distance:  " << closest_distance_level_4);
          new_head.frame_id = "yellow";
        }
        else if(index_closest_level_4 == 3)
        {
          //          ROS_INFO_STREAM("closest object is RED with distance:     " << closest_distance_level_4);
          new_head.frame_id = "red";
        }
        else
        {
          //          ROS_INFO_STREAM("No closest object detected in level 4");
        }

        ROS_INFO_STREAM("object detected in level 4: " << new_head.frame_id);
        ROS_INFO_STREAM("z:    " << objects_level_4.at(index_closest_level_4).center.z);
        publishObjectPose(objects_level_4.at(index_closest_level_4).center, new_head);
      }
      else if(closest_object_detected_level_3.at(i))
      {
        if(index_closest_level_3 == 0)
        {
          //          ROS_INFO_STREAM("closest object is BLUE with distance:    " << closest_distance_level_3);
          new_head.frame_id = "blue";
        }
        else if(index_closest_level_3 == 1)
        {
          //          ROS_INFO_STREAM("closest object is GREEN with distance:   " << closest_distance_level_3);
          new_head.frame_id = "green";
        }
        else if(index_closest_level_3 == 2)
        {
          //          ROS_INFO_STREAM("closest object is YELLOW with distance:  " << closest_distance_level_3);
          new_head.frame_id = "yellow";
        }
        else if(index_closest_level_3 == 3)
        {
          //          ROS_INFO_STREAM("closest object is RED with distance:     " << closest_distance_level_3);
          new_head.frame_id = "red";
        }
        else
        {
          //          ROS_INFO_STREAM("No closest object detected in level 3");
        }

        ROS_INFO_STREAM("object detected in level 3: " << new_head.frame_id);
        ROS_INFO_STREAM("z:    " << objects_level_3.at(index_closest_level_3).center.z);
        publishObjectPose(objects_level_3.at(index_closest_level_3).center, new_head);
      }
      else if(closest_object_detected_level_2.at(i))
      {
        if(index_closest_level_2 == 0)
        {
          //          ROS_INFO_STREAM("closest object is BLUE with distance:    " << closest_distance_level_2);
          new_head.frame_id = "blue";
        }
        else if(index_closest_level_2 == 1)
        {
          //          ROS_INFO_STREAM("closest object is GREEN with distance:   " << closest_distance_level_2);
          new_head.frame_id = "green";
        }
        else if(index_closest_level_2 == 2)
        {
          //          ROS_INFO_STREAM("closest object is YELLOW with distance:  " << closest_distance_level_2);
          new_head.frame_id = "yellow";
        }
        else if(index_closest_level_2 == 3)
        {
          //          ROS_INFO_STREAM("closest object is RED with distance:     " << closest_distance_level_2);
          new_head.frame_id = "red";
        }
        else
        {
          //          ROS_INFO_STREAM("No closest object detected in level 2");
        }

        ROS_INFO_STREAM("object detected in level 2: " << new_head.frame_id);
        ROS_INFO_STREAM("z:    " << objects_level_2.at(index_closest_level_2).center.z);
        publishObjectPose(objects_level_2.at(index_closest_level_2).center, new_head);
      }
      else if(closest_object_detected_level_1.at(i))
      {
        if(index_closest_level_1 == 0)
        {
          //          ROS_INFO_STREAM("closest object is BLUE with distance:    " << closest_distance_level_1);
          new_head.frame_id = "blue";
        }
        else if(index_closest_level_1 == 1)
        {
          //          ROS_INFO_STREAM("closest object is GREEN with distance:   " << closest_distance_level_1);
          new_head.frame_id = "green";
        }
        else if(index_closest_level_1 == 2)
        {
          //          ROS_INFO_STREAM("closest object is YELLOW with distance:  " << closest_distance_level_1);
          new_head.frame_id = "yellow";
        }
        else if(index_closest_level_1 == 3)
        {
          //          ROS_INFO_STREAM("closest object is RED with distance:     " << closest_distance_level_1);
          new_head.frame_id = "red";
        }
        else
        {
          //          ROS_INFO_STREAM("No closest object detected in level 1");
        }

        ROS_INFO_STREAM("object detected in level 1: " << new_head.frame_id);
        ROS_INFO_STREAM("z:    " << objects_level_1.at(index_closest_level_1).center.z);
        publishObjectPose(objects_level_1.at(index_closest_level_1).center, new_head);
      }
    }

    if(closest_object_detected_level_1.at(0) == false && closest_object_detected_level_1.at(1) == false && closest_object_detected_level_1.at(2) == false && closest_object_detected_level_1.at(3) == false &&
       closest_object_detected_level_2.at(0) == false && closest_object_detected_level_2.at(1) == false && closest_object_detected_level_2.at(2) == false && closest_object_detected_level_2.at(3) == false &&
       closest_object_detected_level_3.at(0) == false && closest_object_detected_level_3.at(1) == false && closest_object_detected_level_3.at(2) == false && closest_object_detected_level_3.at(3) == false &&
       closest_object_detected_level_4.at(0) == false && closest_object_detected_level_4.at(1) == false && closest_object_detected_level_4.at(2) == false && closest_object_detected_level_4.at(3) == false)
    {
      ROS_INFO("No object detected in all levels");
      new_head.frame_id = "empty";
      publishObjectPose(objects_level_1.at(1).center, new_head);
    }

  }
  else if(mode_ == 1)
  {

    // Prüfen, ob RGB-Bild und Kamerainfo verfügbar sind
    if(!camera_model_.initialized() || rgb_img.empty())
      return;

    // Punktwolke in PCL-Datentyp konvertieren
    pcl::PointCloud<pcl::PointXYZRGB> cloud;

    pcl::fromROSMsg (*input, cloud);
    std_msgs::Header pc_header = input->header;

    // HSV-Farbraum
    // Zweiter Index = 0: h_min
    // Zweiter Index = 1: h_max
    // Zweiter Index = 2: s_min
    // Zweiter Index = 3: s_max
    // Zweiter Index = 4: v_min
    // Zweiter Index = 5: v_max

    vector<vector<float> > hsvTablePyramide(5,vector<float>(6));

    // HSV-Raum Pyramide

    // BLAU: Erster Index = 0
    hsvTablePyramide[0][0] =   0;
    hsvTablePyramide[0][1] =  20;
    hsvTablePyramide[0][2] =  60;
    hsvTablePyramide[0][3] = 255;
    hsvTablePyramide[0][4] =  40;
    hsvTablePyramide[0][5] = 255;

    // GRÜN: Erster Index = 1
    hsvTablePyramide[1][0] =  40;
    hsvTablePyramide[1][1] =  70;
    hsvTablePyramide[1][2] =  60;
    hsvTablePyramide[1][3] = 255;
    hsvTablePyramide[1][4] =  40;
    hsvTablePyramide[1][5] = 255;

    // GELB: Erster Index = 2
    hsvTablePyramide[2][0] =  75;
    hsvTablePyramide[2][1] = 105;
    hsvTablePyramide[2][2] =  175;
    hsvTablePyramide[2][3] = 255;
    hsvTablePyramide[2][4] = 140;
    hsvTablePyramide[2][5] = 255;

    // ROT: Erster Index = 3
    hsvTablePyramide[3][0] = 110;
    hsvTablePyramide[3][1] = 130;
    hsvTablePyramide[3][2] =  60;
    hsvTablePyramide[3][3] = 255;
    hsvTablePyramide[3][4] =  40;
    hsvTablePyramide[3][5] = 255;


    vector<vector<float> > hsvTableTray(5,vector<float>(6));

    // HSV-Raum Tray

    // BLAU: Erster Index = 0
    hsvTableTray[0][0] =   0;
    hsvTableTray[0][1] =  20;
    hsvTableTray[0][2] =   0;
    hsvTableTray[0][3] = 255;
    hsvTableTray[0][4] =   0;
    hsvTableTray[0][5] = 255;

    // GRÜN: Erster Index = 1
    hsvTableTray[1][0] =  40;
    hsvTableTray[1][1] =  70;
    hsvTableTray[1][2] =   0;
    hsvTableTray[1][3] = 255;
    hsvTableTray[1][4] =   0;
    hsvTableTray[1][5] = 255;

    // GELB: Erster Index = 2
    hsvTableTray[2][0] =  75;
    hsvTableTray[2][1] = 105;
    hsvTableTray[2][2] = 170;
    hsvTableTray[2][3] = 255;
    hsvTableTray[2][4] = 140;
    hsvTableTray[2][5] = 200;

    // ROT: Erster Index = 3
    hsvTableTray[3][0] = 115;
    hsvTableTray[3][1] = 145;
    hsvTableTray[3][2] =   0;
    hsvTableTray[3][3] = 255;
    hsvTableTray[3][4] =   0;
    hsvTableTray[3][5] = 255;


    // declare variables
    std::vector<ObjectProperties> objects_trays;
    std::vector<ObjectProperties> objects_pyramids;

    objects_trays.resize(4);
    objects_pyramids.resize(4);

    std::vector<bool> trays_detected;
    std::vector<bool> pyramids_detected;

    trays_detected.resize(4);
    pyramids_detected.resize(4);

    int index_tray;
    int index_pyramide;

    std::vector<bool> tray_detected;
    std::vector<bool> pyramide_detected;

    tray_detected.resize(4);
    pyramide_detected.resize(4);


    //    ROS_INFO("########### SEARCH PYRAMIDES ##############");
    morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*5+1, 2*5+1),
                                                cv::Point(5, 5));
    morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*3+1, 2*3+1),
                                                cv::Point(3, 3));
    morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*1+1, 2*1+1),
                                                cv::Point(1, 1));

    for(int i = 0; i < 4; i++)
    {
      object_detected = false;

      h_min_ = hsvTablePyramide[i][0];
      h_max_ = hsvTablePyramide[i][1];
      s_min_ = hsvTablePyramide[i][2];
      s_max_ = hsvTablePyramide[i][3];
      v_min_ = hsvTablePyramide[i][4];
      v_max_ = hsvTablePyramide[i][5];

      cv::Mat raw_mask = createObjectMask(cloud);
      cv::Mat filtered_mask = filterObjectMask(raw_mask);
      clearBorder(filtered_mask);
      cv::Mat object_mask = selectBlob(filtered_mask);
      ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

      if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
      {
        // ROS_INFO_STREAM("Color " << i << " NOT detected at pyramids");
        pyramids_detected.at(i) = false;
        continue;
      }
      else
      {
        // ROS_INFO_STREAM("Color " << i << " is detected at pyramids");
        pyramids_detected.at(i) = true;
        index_pyramide = i;
      }

      objects_pyramids.at(i) = transformProperties(object_properties, pc_header);
    }


    //    ROS_INFO("########### SEARCH TRAYS ##############");
//    morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
//                                                cv::Size(2*35+1, 2*35+1),
//                                                cv::Point(35, 35));
//    morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
//                                                cv::Size(2*35+1, 2*35+1),
//                                                cv::Point(35, 35));
//    morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
//                                                cv::Size(2*2+1, 2*2+1),
//                                                cv::Point(2, 2));

    for(int i = 0; i < 4; i++)
    {
      if(i == 2)
      {
        morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                    cv::Size(2*35+1, 2*35+1),
                                                    cv::Point(35, 35));
        morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                    cv::Size(2*35+1, 2*35+1),
                                                    cv::Point(35, 35));
        morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                    cv::Size(2*2+1, 2*2+1),
                                                    cv::Point(2, 2));
      }
      else
      {
        morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                    cv::Size(2*50+1, 2*50+1),
                                                    cv::Point(50, 50));
        morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                    cv::Size(2*45+1, 2*45+1),
                                                    cv::Point(45, 45));
        morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                    cv::Size(2*2+1, 2*2+1),
                                                    cv::Point(2, 2));
      }

      object_detected = false;

      h_min_ = hsvTableTray[i][0];
      h_max_ = hsvTableTray[i][1];
      s_min_ = hsvTableTray[i][2];
      s_max_ = hsvTableTray[i][3];
      v_min_ = hsvTableTray[i][4];
      v_max_ = hsvTableTray[i][5];

      cv::Mat raw_mask = createObjectMask(cloud);
      cv::Mat filtered_mask = filterObjectMask(raw_mask);
      // clearBorder(filtered_mask);
      cv::Mat object_mask = selectBlob(filtered_mask);
      ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

      if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
      {
        //ROS_INFO_STREAM("Color " << i << " NOT detected at trays");
        trays_detected.at(i) = false;
        continue;
      }
      else
      {
        //ROS_INFO_STREAM("Color " << i << " is detected at trays");
        trays_detected.at(i) = true;
        index_tray = i;
      }

      objects_trays.at(i) = transformProperties(object_properties, pc_header);
    }

    for(int i = 0; i < 4; i++)
    {
      if((pyramids_detected.at(i) == trays_detected.at(i)) && pyramids_detected.at(i))
      {
        pyramids_detected.at(i) = false;
        trays_detected.at(i) = true;
      }
    }

    bool one_tray_detected = false;

    for(int i = 0; i < 4; i++)
    {
      if(trays_detected.at(i))
      {
        one_tray_detected = true;
      }
    }


    std_msgs::Header new_head = input->header;

    for(int i = 0; i < 4; i++)
    {
      if(trays_detected.at(i))
      {
        if(index_tray == 0)
        {
          //ROS_INFO_STREAM("BLUE Tray - x:   " << objects_trays.at(0).center.x << "  y:  " << objects_trays.at(0).center.y);
          new_head.frame_id = "blue";
        }
        else if(index_tray == 1)
        {
          //ROS_INFO_STREAM("GREEN Tray - x:  " << objects_trays.at(1).center.x << "  y:  " << objects_trays.at(1).center.y);
          new_head.frame_id = "green";
        }
        else if(index_tray == 2)
        {
          //ROS_INFO_STREAM("YELLOW Tray - x: " << objects_trays.at(2).center.x << "  y:  " << objects_trays.at(2).center.y);
          new_head.frame_id = "yellow";
        }
        else if(index_tray == 3)
        {
          //ROS_INFO_STREAM("RED Tray - x:    " << objects_trays.at(3).center.x << "  y:  " << objects_trays.at(3).center.y);
          new_head.frame_id = "red";
        }

        ROS_INFO_STREAM("tray detected: " << new_head.frame_id);
        ROS_INFO_STREAM("x:    " << objects_trays.at(index_tray).center.x << "  y:  " << objects_trays.at(index_tray).center.y);
        // Übergabe an StateMachine zum erkennen eines Tray z = 0
        objects_trays.at(index_tray).center.z = 0;
        publishObjectPose(objects_trays.at(index_tray).center, new_head);
      }
      else if(pyramids_detected.at(i) && !one_tray_detected)
      {
        if(index_pyramide == 0)
        {
          //ROS_INFO_STREAM("BLUE Pyram - x:  " << objects_pyramids.at(0).center.x << "  y:  " << objects_pyramids.at(0).center.y);
          new_head.frame_id = "blue";
        }
        else if(index_pyramide == 1)
        {
          //ROS_INFO_STREAM("GREEN Pyram - x: " << objects_pyramids.at(1).center.x << "  y:  " << objects_pyramids.at(1).center.y);
          new_head.frame_id = "green";
        }
        else if(index_pyramide == 2)
        {
          //ROS_INFO_STREAM("YELLOW Pyram - x:" << objects_pyramids.at(2).center.x << "  y:  " << objects_pyramids.at(2).center.y);
          new_head.frame_id = "yellow";
        }
        else if(index_pyramide == 3)
        {
          //ROS_INFO_STREAM("RED Pyram - x:   " << objects_pyramids.at(3).center.x << "  y:  " << objects_pyramids.at(3).center.y);
          new_head.frame_id = "red";
        }

        ROS_INFO_STREAM("pyramide detected: " << new_head.frame_id);
        ROS_INFO_STREAM("x:    " << objects_pyramids.at(index_pyramide).center.x << "  y:  " << objects_pyramids.at(index_pyramide).center.y);
        // Übergabe an StateMachine zum erkennen einer Pyramide z = 1
        objects_pyramids.at(index_pyramide).center.z = 1;
        publishObjectPose(objects_pyramids.at(index_pyramide).center, new_head);
      }

    }

    if(trays_detected.at(0) == false && trays_detected.at(1) == false && trays_detected.at(2) == false && trays_detected.at(3) == false &&
       pyramids_detected.at(0) == false && pyramids_detected.at(1) == false && pyramids_detected.at(2) == false && pyramids_detected.at(3) == false)
    {
      ROS_INFO_STREAM("Nothing detected");
      new_head.frame_id = "empty";
      // Übergabe an StateMachine zum erkennen einer leeren Area z = 2
      objects_trays.at(1).center.z = 2;
      publishObjectPose(objects_trays.at(1).center, new_head);
    }

  }
  else if(mode_ == 2)
  {
    // Prüfen, ob RGB-Bild und Kamerainfo verfügbar sind
    if(!camera_model_.initialized() || rgb_img.empty())
      return;

    // Punktwolke in PCL-Datentyp konvertieren
    pcl::PointCloud<pcl::PointXYZRGB> cloud;

    pcl::fromROSMsg (*input, cloud);
    std_msgs::Header pc_header = input->header;

    // HSV-Farbraum
    // Zweiter Index = 0: h_min
    // Zweiter Index = 1: h_max
    // Zweiter Index = 2: s_min
    // Zweiter Index = 3: s_max
    // Zweiter Index = 4: v_min
    // Zweiter Index = 5: v_max

    vector<vector<float> > hsvTable(5,vector<float>(6));

    // BLAU: Erster Index = 0
    hsvTable[0][0] =   0;
    hsvTable[0][1] =  35;
    hsvTable[0][2] =  0;
    hsvTable[0][3] = 200;
    hsvTable[0][4] =  0;
    hsvTable[0][5] = 200;

    // GRÜN: Erster Index = 1
    hsvTable[1][0] =  35;
    hsvTable[1][1] =  75;
    hsvTable[1][2] =  0;
    hsvTable[1][3] = 200;
    hsvTable[1][4] =  0;
    hsvTable[1][5] = 200;

    // GELB: Erster Index = 2
    hsvTable[2][0] =  75;
    hsvTable[2][1] = 105;
    hsvTable[2][2] =  0;
    hsvTable[2][3] = 200;
    hsvTable[2][4] =  0;
    hsvTable[2][5] = 200;

    // ROT: Erster Index = 3
    hsvTable[3][0] = 105;
    hsvTable[3][1] = 140;
    hsvTable[3][2] =  0;
    hsvTable[3][3] = 200;
    hsvTable[3][4] =  0;
    hsvTable[3][5] = 200;


    std::vector<ObjectProperties> objects_in_tray;
    objects_in_tray.resize(4);

    std::vector<bool> objects_detected_in_tray;
    objects_detected_in_tray.resize(4);

    int index_closest_object_in_tray;

    std::vector<bool> closest_object_detected_in_tray;
    closest_object_detected_in_tray.resize(4);

    double closest_distance;
    closest_distance = -0.10;


    //    ROS_INFO("########### SEARCH COLORS LEVEL 1 ##############");
    morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*3+1, 2*3+1),
                                                cv::Point(3, 3));
    morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*20+1, 2*20+1),
                                                cv::Point(20, 20));
    morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*1+1, 2*1+1),
                                                cv::Point(1, 1));

    for(int i = 0; i < 4; i++)
    {
      object_detected = false;

      h_min_ = hsvTable[i][0];
      h_max_ = hsvTable[i][1];
      s_min_ = hsvTable[i][2];
      s_max_ = hsvTable[i][3];
      v_min_ = hsvTable[i][4];
      v_max_ = hsvTable[i][5];

      cv::Mat raw_mask = createObjectMask(cloud);
      cv::Mat filtered_mask = filterObjectMask(raw_mask);
      // clearBorder(filtered_mask);
      cv::Mat object_mask = selectBlob(filtered_mask);
      ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

      if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
      {
        //        ROS_INFO_STREAM("Color " << i << " NOT detected in tray");
        objects_detected_in_tray.at(i) = false;
        continue;
      }
      else
      {
        //        ROS_INFO_STREAM("Color " << i << " is detected in tray");
        objects_detected_in_tray.at(i) = true;
      }

      objects_in_tray.at(i) = transformProperties(object_properties, pc_header);
    }

    //    ROS_INFO("########### SEARCH CLOSEST OBJECT IN LEVEL 1 ##############");
    for(int i = 0; i < 4 ; i++)
    {
      if(objects_detected_in_tray.at(i) && objects_in_tray.at(i).center.z > closest_distance)
      {
        index_closest_object_in_tray = i;
        closest_distance = objects_in_tray.at(i).center.z;
        closest_object_detected_in_tray.at(i) = true;
      }
      else
      {
        closest_object_detected_in_tray.at(i) = false;
      }
    }

    // handle for closest object
    std_msgs::Header new_head = input->header;

    for(int i = 0; i < 4; i++)
    {
      if(closest_object_detected_in_tray.at(i))
      {
        if(index_closest_object_in_tray == 0)
        {
          //          ROS_INFO_STREAM("closest object is BLUE with distance:    " << closest_distance_level_1);
          new_head.frame_id = "blue";
        }
        else if(index_closest_object_in_tray == 1)
        {
          //          ROS_INFO_STREAM("closest object is GREEN with distance:   " << closest_distance_level_1);
          new_head.frame_id = "green";
        }
        else if(index_closest_object_in_tray == 2)
        {
          //          ROS_INFO_STREAM("closest object is YELLOW with distance:  " << closest_distance_level_1);
          new_head.frame_id = "yellow";
        }
        else if(index_closest_object_in_tray == 3)
        {
          //          ROS_INFO_STREAM("closest object is RED with distance:     " << closest_distance_level_1);
          new_head.frame_id = "red";
        }
        else
        {
          //          ROS_INFO_STREAM("No closest object detected in level 1");
        }

        ROS_INFO_STREAM("object in tray detected: " << new_head.frame_id);
        ROS_INFO_STREAM("x:    " << objects_in_tray.at(index_closest_object_in_tray).center.x << "y:    " << objects_in_tray.at(index_closest_object_in_tray).center.y << "z:    " << objects_in_tray.at(index_closest_object_in_tray).center.z);
        publishObjectPose(objects_in_tray.at(index_closest_object_in_tray).center, new_head);
      }
    }

    if(closest_object_detected_in_tray.at(0) == false && closest_object_detected_in_tray.at(1) == false && closest_object_detected_in_tray.at(2) == false && closest_object_detected_in_tray.at(3) == false)
    {
      ROS_INFO("No object detected in tray with same color");
      new_head.frame_id = "empty";
      publishObjectPose(objects_in_tray.at(1).center, new_head);
    }
  }
  else if(mode_ == 3)
  {
    // Prüfen, ob RGB-Bild und Kamerainfo verfügbar sind
    if(!camera_model_.initialized() || rgb_img.empty())
      return;

    // Punktwolke in PCL-Datentyp konvertieren
    pcl::PointCloud<pcl::PointXYZRGB> cloud;

    pcl::fromROSMsg (*input, cloud);
    std_msgs::Header pc_header = input->header;

    // HSV-Farbraum
    // Zweiter Index = 0: h_min
    // Zweiter Index = 1: h_max
    // Zweiter Index = 2: s_min
    // Zweiter Index = 3: s_max
    // Zweiter Index = 4: v_min
    // Zweiter Index = 5: v_max

    vector<vector<float> > hsvTable(5,vector<float>(6));

    // BLAU: Erster Index = 0
    hsvTable[0][0] =   0;
    hsvTable[0][1] =  20;
    hsvTable[0][2] =  60;
    hsvTable[0][3] = 255;
    hsvTable[0][4] =  40;
    hsvTable[0][5] = 255;

    // GRÜN: Erster Index = 1
    hsvTable[1][0] =  40;
    hsvTable[1][1] =  70;
    hsvTable[1][2] =  60;
    hsvTable[1][3] = 255;
    hsvTable[1][4] =  40;
    hsvTable[1][5] = 255;

    // GELB: Erster Index = 2
    hsvTable[2][0] =  75;
    hsvTable[2][1] = 105;
    hsvTable[2][2] =  60;
    hsvTable[2][3] = 255;
    hsvTable[2][4] =  40;
    hsvTable[2][5] = 255;

    // ROT: Erster Index = 3
    hsvTable[3][0] = 110;
    hsvTable[3][1] = 130;
    hsvTable[3][2] =  60;
    hsvTable[3][3] = 255;
    hsvTable[3][4] =  40;
    hsvTable[3][5] = 255;


    std::vector<ObjectProperties> objects_in_tray;
    objects_in_tray.resize(4);

    std::vector<bool> objects_detected_in_tray;
    objects_detected_in_tray.resize(4);

    int index_closest_object_in_tray;

    std::vector<bool> closest_object_detected_in_tray;
    closest_object_detected_in_tray.resize(4);

    double closest_distance;
    closest_distance = -0.10;


    //    ROS_INFO("########### SEARCH COLORS LEVEL 1 ##############");
    morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*45+1, 2*45+1),
                                                cv::Point(45, 45));
    morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*40+1, 2*40+1),
                                                cv::Point(40, 40));
    morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                                cv::Size(2*2+1, 2*2+1),
                                                cv::Point(2, 2));

    for(int i = 0; i < 4; i++)
    {
      object_detected = false;

      h_min_ = hsvTable[i][0];
      h_max_ = hsvTable[i][1];
      s_min_ = hsvTable[i][2];
      s_max_ = hsvTable[i][3];
      v_min_ = hsvTable[i][4];
      v_max_ = hsvTable[i][5];

      cv::Mat raw_mask = createObjectMask(cloud);
      cv::Mat filtered_mask = filterObjectMask(raw_mask);
      // clearBorder(filtered_mask);
      cv::Mat object_mask = selectBlob(filtered_mask);
      ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

      if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
      {
        //        ROS_INFO_STREAM("Color " << i << " NOT detected in tray");
        objects_detected_in_tray.at(i) = false;
        continue;
      }
      else
      {
        //        ROS_INFO_STREAM("Color " << i << " is detected in tray");
        objects_detected_in_tray.at(i) = true;
      }

      objects_in_tray.at(i) = transformProperties(object_properties, pc_header);
    }

    //    ROS_INFO("########### SEARCH CLOSEST OBJECT IN LEVEL 1 ##############");
    for(int i = 0; i < 4 ; i++)
    {
      if(objects_detected_in_tray.at(i) && objects_in_tray.at(i).center.z > closest_distance)
      {
        index_closest_object_in_tray = i;
        closest_distance = objects_in_tray.at(i).center.z;
        closest_object_detected_in_tray.at(i) = true;
      }
      else
      {
        closest_object_detected_in_tray.at(i) = false;
      }
    }

    // handle for closest object
    std_msgs::Header new_head = input->header;

    for(int i = 0; i < 4; i++)
    {
      if(closest_object_detected_in_tray.at(i))
      {
        if(index_closest_object_in_tray == 0)
        {
          //          ROS_INFO_STREAM("closest object is BLUE with distance:    " << closest_distance_level_1);
          new_head.frame_id = "blue";
        }
        else if(index_closest_object_in_tray == 1)
        {
          //          ROS_INFO_STREAM("closest object is GREEN with distance:   " << closest_distance_level_1);
          new_head.frame_id = "green";
        }
        else if(index_closest_object_in_tray == 2)
        {
          //          ROS_INFO_STREAM("closest object is YELLOW with distance:  " << closest_distance_level_1);
          new_head.frame_id = "yellow";
        }
        else if(index_closest_object_in_tray == 3)
        {
          //          ROS_INFO_STREAM("closest object is RED with distance:     " << closest_distance_level_1);
          new_head.frame_id = "red";
        }
        else
        {
          //          ROS_INFO_STREAM("No closest object detected in level 1");
        }

        ROS_INFO_STREAM("object in tray detected: " << new_head.frame_id);
        ROS_INFO_STREAM("x:    " << objects_in_tray.at(index_closest_object_in_tray).center.x << "y:    " << objects_in_tray.at(index_closest_object_in_tray).center.y << "z:    " << objects_in_tray.at(index_closest_object_in_tray).center.z);
        publishObjectPose(objects_in_tray.at(index_closest_object_in_tray).center, new_head);
      }
    }

    if(closest_object_detected_in_tray.at(0) == false && closest_object_detected_in_tray.at(1) == false && closest_object_detected_in_tray.at(2) == false && closest_object_detected_in_tray.at(3) == false)
    {
      ROS_INFO("No object detected in tray with same color");
      new_head.frame_id = "empty";
      publishObjectPose(objects_in_tray.at(1).center, new_head);
    }
  }
}


// void ObjectDetection::allFunctions(cloud, pc_header){


//}

//########## CREATE OBJECT MASK ########################################################################################
cv::Mat ObjectDetection::createObjectMask(pcl::PointCloud<pcl::PointXYZRGB> &cloud)
{
  // =========== Aufgabe 1 ===========================================================================================

  /* Um die Punktwolke später nach Farbwerten filtern zu können, soll in dieser Methode zunächst eine Maske erstellt
     * werden, in welcher hinterlegt ist, welche Punkte den Filterkriterien entsprechen und welche nicht.
     * Ein Pixel der binären Maske soll einen Wert größer Null haben, wenn der zugehörige Punkt der Punktwolke den
     * Filterkriterien entspricht. Alle anderen Pixel sollen den Wert Null haben.
     * Die Filterkriterien sind als obere und untere Grenzwerte im HSV-Farbraum gegeben und stehen als Klassen-Member
     * zur Verfügung:
     * h_min_, h_max_, s_min_, s_max_, v_min_, v_max_
     *
     * Als Rückgabewert der Methode wird eine binäre OpenCV-Matrix (Typ CV_8UC1) mit gleicher Breite und Höhe wie die
     * Punktwolke erwartet.
     *
     * ==> Implementieren Sie den Farbfilter und geben Sie die Maske als Rückgabewert zurück!
     */

  // =========== Hinweise ============================================================================================

  /*  Eine Bildmatrix mit 3 (Farb-)Kanälen initialisieren:
    *    cv::Mat rgb_img(cloud_.width, cloud_.height, CV_8UC3);

    *  Pixel-Zugriff auf eine Bildmatrix über Pointer:
    *    unsigned char* rgb_ptr = rgb_img.ptr<unsigned char>();
    *    rgb_ptr[0] = R (Pixel 1)
    *    rgb_ptr[1] = G (Pixel 1)
    *    rgb_ptr[2] = B (Pixel 1)
    *    rgb_ptr[3] = R (Pixel 2)
    *    rgb_ptr[4] = G (Pixel 2)
    *    rgb_ptr[5] = B (Pixel 2)
    *    etc...

    *  Zugriff auf Punkte der Punktwolke:
    *    cloud.points[i].x;
    *    cloud.points[i].y;
    *    cloud.points[i].z;
    *    cloud.points[i].r;
    *    cloud.points[i].g;
    *    cloud.points[i].b;

    *  Nützliche Funktionen:
    *    cv::cvtColor
    *    cv::inRange

    *  Nützliche Klassen
    *    cv::Mat
    *    cv::Scalar
    */
  // =================================================================================================================

  // Eine Bildmatrix mit 3 Farb-Kanälen initialisieren:
  cv::Mat rgb_img(cloud.height, cloud.width, CV_8UC3);

  // Maske Bildmatrix mit 1 Farb-Kanal initialisieren (binary)
  cv::Mat maske(cloud.height, cloud.width, CV_8UC1);

  // Eine Bildmatrix im HSV-Raum
  cv::Mat hsvimage;


  for(int h = 0; h < cloud.height; h++)
  {
    for(int w = 0; w < cloud.width; w++)
    {
      pcl::PointXYZRGB point = cloud.at(w, h);

      Eigen::Vector3i rgb = point.getRGBVector3i();

      rgb_img.at<cv::Vec3b>(h, w)[0] = rgb[2];
      rgb_img.at<cv::Vec3b>(h, w)[1] = rgb[1];
      rgb_img.at<cv::Vec3b>(h, w)[2] = rgb[0];
    }
  }


  //    cv::imshow("RGB-Bild", rgb_img);
  //    cv::waitKey(1);

  // RGB-Bild in HSV-Bild
  //src = rgb_img;
  cv::cvtColor(rgb_img, hsvimage, CV_RGB2HSV);
  //cv::imshow("HSV-Bild", hsvimage);
  //cv::waitKey(1);

  // HSV-Bild in Binär-Bild

  cv::Mat binaer;
  cv::inRange(hsvimage, cv::Scalar(h_min_, s_min_, v_min_), cv::Scalar(h_max_, s_max_, v_max_), binaer);
  //        cv::imshow("Binaer-Bild", binaer);
  //        cv::waitKey(1);

  maske = binaer;

  return maske; // mask is one channel and it's binary. it's the result of cv::inrange
}

//########## FILTER OBJECT MASK ########################################################################################
cv::Mat ObjectDetection::filterObjectMask(cv::Mat &mask)
{
  // =========== Aufgabe 2 ===========================================================================================

  /* Mit morphologischen Filtern kann die binäre Maske "bereinigt" werden. Z.B. können vereinzelte Pixel eliminiert
     * oder Löcher in zusammengehörenden Bereichen gefüllt werden.
     * Sehen Sie sich die Maske vor der Filterung an und implementieren Sie geeignete morphologische Operationen, um
     * unerwünschte Artefakte in der Maske zu beseitigen.
     *
     * ==> Implementieren Sie zwei morphologische Filteroperationen und verwenden Sie die Parameter
     *     "morph_kernel_1_" und "morph_kernel_2_" als Filterkerne.
     */

  // =========== Hinweise ============================================================================================

  /*
     * Links:
     *     http://docs.opencv.org/2.4.2/doc/tutorials/imgproc/erosion_dilatation/erosion_dilatation.html
     *     http://docs.opencv.org/2.4.2/doc/tutorials/imgproc/opening_closing_hats/opening_closing_hats.html
    */
  // =================================================================================================================

  Mat opening_result;
  Mat closing_result;
  Mat erosion_result;

  // Operator
  // Opening:     0
  // Closing:     1
  // Gradient:    2
  // Top Hat:     3
  // Black Hat:   4
  int operator_opening = 0;
  int operator_closing = 1;

  morphologyEx(mask, opening_result, operator_opening, morph_kernel_1_);
  //    imshow("Opening Demo", opening_result);
  //    cv::waitKey(1);

  morphologyEx(opening_result, closing_result, operator_closing, morph_kernel_2_);
  //    imshow("Closing Demo", opening_result);
  //    cv::waitKey(1);

  erode(closing_result, erosion_result, morph_kernel_3_);
//   imshow("Erosion Demo", erosion_result);
//   cv::waitKey(1);

  mask = erosion_result;

  return mask; 
}

//########## CLEAR BORDER ##############################################################################################
void ObjectDetection::clearBorder(cv::Mat &mask)
{
  // remove all blobs that touch the image border
  unsigned char* p = mask.ptr<unsigned char>(0);
  for(int i = 0; i < mask.cols; i++)
  {
    p[i] = 255;
    p[mask.cols*mask.rows-1-i] = 255;
  }
  for(int i = 1; i < mask.rows; i++)
  {
    int j = i*mask.cols-1;
    p[j++] = 255;
    p[j] = 255;
  }
  cv::floodFill(mask,cv::Point(0, 0), 0);
}

//########## TUNA FISH ##############################################################################################
void onTunaFishTrackbar(int, void*)
{
  cv::Mat hist, histImg, tmp;
  brightness.copyTo(tmp);

  if (blursSize >= 3)
  {
    blursSize += (1 - blursSize % 2);
    cv::GaussianBlur(tmp, tmp, cv::Size(blursSize, blursSize), 0);
  }
  if (useEqualize)
    cv::equalizeHist(tmp, tmp);

  cv::imshow("Brightness Preprocess", tmp);

  // threshold to select dark tuna
  cv::threshold(tmp, tmp, th1, 255, cv::THRESH_BINARY_INV);
  cv::imshow(winName, tmp);

  // find external contours ignores holes in the fish
  vector<vector<cv::Point> > contours;
  vector<cv::Vec4i> hierarchy;
  cv::findContours(tmp, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);

  // draw all contours and select the largest
  src.copyTo(dst);
  double maxDim = 0;
  int largest = -1;
  for (int i = 0; i< contours.size(); i++)
  {
    // draw all contours in red
    cv::drawContours(dst, contours, largest, cv::Scalar(0, 0, 255), 1);
    int dim = contours[i].size(); //area is more accurate but more expensive
    //double dim = contourArea(contours[i]);
    //double dim = cvRound(arcLength(contours[i], true));
    if (dim> maxDim)
    {
      maxDim = dim;
      largest = i;
    }
  }

  //The tuna as binary mask
  cv::Mat fishMask = cv::Mat::zeros(src.size(), CV_8UC1);
  //The tuna as contour
  vector<cv::Point> theFish;
  if (largest >= 0)
  {
    theFish = contours[largest];
    // draw selected contour in bold green
    cv::polylines(dst, theFish, true, cv::Scalar(0, 255, 0), 2);
    // draw the fish into its mask
    cv::drawContours(fishMask, contours, largest, 255, -1);
  }
  cv::imshow("Result Fish Mask", fishMask);
  cv::imshow("Result Contour", dst);
}

//########## SAME OBJECTCOLOR AND BACKGROUNDCOLOR ##############################################################################################
void ObjectDetection::trackingColorBackground()
{

  cvtColor(src, dst, CV_BGR2HSV);
  vector<cv::Mat > hsv_planes;
  split(dst, hsv_planes);
  //hue = hsv_planes[0];
  //saturation = hsv_planes[1];
  brightness = hsv_planes[2];

  // default settings for params
  useEqualize = 1;
  blursSize = 21;
  th1 = 33.0 * 255 / 100; //tuna is dark than select dark zone below 33% of full range
  cv::createTrackbar("Equalize", winName, &useEqualize, 1, onTunaFishTrackbar, 0);
  cv::createTrackbar("Blur Sigma", winName, &blursSize, 100, onTunaFishTrackbar, 0);
  cv::createTrackbar("Threshold", winName, &th1, 255, onTunaFishTrackbar, 0);

  onTunaFishTrackbar(0, 0);
}

//########## DETECT BLOBS ##############################################################################################
cv::Mat ObjectDetection::selectBlob(cv::Mat &mask)
{
  // =========== Aufgabe 3 ===========================================================================================

  /* Um einzelne Objekte im Bild identifizieren zu können, müssen in der Maske zusammenhängende Bereiche (sog. Blobs)
     * gefunden werden. Diese Methode soll zunächst alle Blobs in der Maske finden und anschließend einen geeigneten
     * Blob auswählen und als neue Maske zurückgeben. Die Rückgabe-Maske soll die gleiche Größe und den gleichen Typ
     * wie die Eingangsmaske haben.
     *
     * Zur Vorauswahl geeigneter Blobs können Sie die Parameter "min_blob_size_" und "max_blob_size_" verwenden. Eine
     * Möglichkeit zur Auswahl wäre z.B., den größten Blob auszuwählen, der kleiner als "max_blob_size_" ist.
     *
     * ==> Finden Sie zuerst alle Blobs in der Eingangsmaske und wählen Sie anschließend einen geeigneten Blob aus und
     *     geben diesen als neue binäre Maske zurück.
     */

  // =========== Hinweise ============================================================================================

  /*
     * Links:
     *    http://docs.opencv.org/2.4/doc/tutorials/imgproc/shapedescriptors/find_contours/find_contours.html
     *    http://docs.opencv.org/2.4/modules/imgproc/doc/structural_analysis_and_shape_descriptors.html
     *
     * Nützliche Funktionen:
     *    cv::findContours
     *    cv::ContourArea
     *    cv::drawContours

    */
  // =================================================================================================================

  Mat blob_output;
  vector<vector<Point> > contours;
  vector<Vec4i> hierarchy;

  blob_output = mask;

  // Find contours
  findContours(blob_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));


  // Draw contours
  Mat drawing = Mat::zeros(blob_output.size(), CV_8UC3);
  Scalar color = Scalar(0, 0, 255);
  for(int i = 0; i < contours.size(); i++)
  {
    drawContours(drawing, contours, i, color, 2, 8, hierarchy, 0, Point());
  }

  Mat drawing2 = Mat::zeros(blob_output.size(), CV_8UC1);
  int i_max = 0, size_max = 0;
  for(int i = 0; i < contours.size(); i++)
  {
    double area_size = contourArea(contours[i]);
    if((area_size > min_blob_size_) && (area_size < max_blob_size_))
    {
      if(area_size > size_max)
      {
        size_max = area_size;
        i_max = i;
        //        ROS_INFO("Max Area %d", size_max);
        object_detected = true;
      }
      //            if(!object_detected)
      //            {
      //                ROS_INFO("No Object Detected");
      //            }

      rectangle(drawing2, boundingRect(contours[i]), Scalar(0,255,0), 2, 8, 0);
    }

  }

  color = Scalar(255, 255, 255);
  drawContours(drawing2, contours, i_max, color, -1, 8, hierarchy, 0, Point());
  //  imshow("Contours", drawing);
  //  cv::waitKey(1);

  mask = drawing2;

  return mask;
}

//########## GET OBJECT CENTERS ########################################################################################
ObjectProperties ObjectDetection::getObjectProperties(pcl::PointCloud<pcl::PointXYZRGB> &cloud, cv::Mat &mask)
{
  // =========== Aufgabe 4 ===========================================================================================

  /* Wenn die Maske für ein einzelnes Objekt vorliegt, kann diese verwendet werden, um die Position des Objekts
     * aus der Punktwolke zu berechnen. In dieser Methode soll der 3D-Mittelpunkt und die 3D-Bounding-Box der über die
     * Maske selektierten Punkte berechnet werden.
     * Die Bounding-Box wird über zwei Eckpunkte (min und max) definiert. Alle Rückgabewerte können in der Struktur
     * "ObjectProperties" gespeichert und zurückgegeben werden.
     *
     * ==> Iterieren Sie durch die Maske bzw. Punktwolke und berechnen Sie Mittelpunkt und Bounding-Box des über die
     *     Maske selektierten Objekts.
     */


  /* =========== Hinweise ============================================================================================
    *  Zugriff auf Maske über Pointer:
    *    bool* mask_ptr = mask.ptr<bool>();
    *    bool value = mask_ptr[i];
    *
    * Zugriff auf Punkte der Punktwolke:
    *    float x = cloud.points[i].x
    *    float y = cloud.points[i].y
    *    float z = cloud.points[i].z
    *
    * Nützliche Funktionen:
    *    std::min
    *    std::max
    *
    * Achtung: In der Punktwolke gibt es immer einige ungültige Punkte mit z-Wert = NaN.
    *          Um diese Punkte zu ignorieren, kann die folgende Bedingung geprüft werden: isnan(cloud.points[i].z)

    */
  // =================================================================================================================

  bool* mask_ptr = mask.ptr<bool>();

  std::vector<float> x_vec;
  std::vector<float> y_vec;
  std::vector<float> z_vec;

  std::vector<float> x_vec_object_in_tray;
  std::vector<float> y_vec_object_in_tray;
  std::vector<float> z_vec_object_in_tray;


  Size s = mask.size();
  int boarder = s.height * s.width;
  float min_x = HUGE_VAL, min_y = HUGE_VAL, min_z = HUGE_VAL, max_x = 0.0, max_y = 0.0;
  for (int i = 0; i < boarder; i++)
  {
    if (mask_ptr[i] == 255)
    {
      if (!isnan(cloud.points[i].x) && !isinf(cloud.points[i].x))
      {
        x_vec.push_back(cloud.points[i].x);
        //                min_x = min(min_x,cloud.points[i].x);
        //                max_x = max(max_x,cloud.points[i].x);
      }
      if (!isnan(cloud.points[i].y) && !isinf(cloud.points[i].y))
      {
        y_vec.push_back(cloud.points[i].y);
        //                min_y = min(min_y,cloud.points[i].y);
        //                max_y = max(max_y,cloud.points[i].y);
      }
      if (!isnan(cloud.points[i].z) && !isinf(cloud.points[i].z))
      {
        z_vec.push_back(cloud.points[i].z);
        //                min_z = min(min_z,cloud.points[i].z);
      }
      //      if (!isnan(cloud.points[i].x) && !isnan(cloud.points[i].y) && !isnan(cloud.points[i].z))
      //      {
      //        x_vec_object_in_tray.push_back(cloud.points[i].x);
      //        y_vec_object_in_tray.push_back(cloud.points[i].y);
      //        y_vec_object_in_tray.push_back(cloud.points[i].z);
      //      }
    }
  }


  float x_median;
  float y_median;
  float z_median;

  std::sort(x_vec.begin(), x_vec.end());
  std::sort(y_vec.begin(), y_vec.end());
  std::sort(z_vec.begin(), z_vec.end());

  int x_size = x_vec.size();
  int y_size = y_vec.size();
  int z_size = z_vec.size();

  if(x_size != 0)
  {
    if(x_size % 2 == 0)
    {
      x_median = (x_vec[x_size/2-1] + x_vec[x_size/2]) / 2;
    }
    else
    {
      x_median = x_vec[x_size/2];
    }
  }
  else
  {
    x_median = std::numeric_limits<float>::quiet_NaN();
  }

  if(y_size != 0)
  {
    if(y_size % 2 == 0)
    {
      y_median = (y_vec[y_size/2-1] + y_vec[y_size/2]) / 2;
    }
    else
    {
      y_median = y_vec[y_size/2];
    }
  }
  else
  {
    y_median = std::numeric_limits<float>::quiet_NaN();
  }

  if(z_size != 0)
  {
    if(z_size % 2 == 0)
    {
      z_median = (z_vec[z_size/2-1] + z_vec[z_size/2]) / 2;
    }
    else
    {
      z_median = z_vec[z_size/2];
    }
  }
  else
  {
    z_median = std::numeric_limits<float>::quiet_NaN();
  }

  //  float radius = sqrt(x_median*x_median + y_median*y_median);
  //  float radius_limit_float = float(radius_limit);

  //  if(radius > radius_limit_float)
  //  {
  //    x_median = std::numeric_limits<float>::quiet_NaN();
  //    y_median = std::numeric_limits<float>::quiet_NaN();
  //    z_median = std::numeric_limits<float>::quiet_NaN();
  //  }

  // Bounding Box ums Objekt
  ObjectProperties OP_bbox;

  //    if(object_detected == true)
  //    {
  //        OP_bbox.bounding_box_min_corner.x = min_x;
  //        OP_bbox.bounding_box_min_corner.y = min_y;
  //        OP_bbox.bounding_box_min_corner.z = min_z;
  //        OP_bbox.bounding_box_max_corner.x = max_x;
  //        OP_bbox.bounding_box_max_corner.y = max_y;
  //    }

  // Mittelpunkt Bounding Box
  //    OP_bbox.center.x = min_x + ((max_x - min_x) / 2);
  //    OP_bbox.center.y = min_y + ((max_y - min_y) / 2);
  //    OP_bbox.center.z = min_z + 0.01;

  OP_bbox.center.x = x_median;
  OP_bbox.center.y = y_median + 0.005;
  OP_bbox.center.z = z_median;


  if(mode_ == 2)
  {
    bool* mask_ptr = mask.ptr<bool>();

    Size s = mask.size();
    int boarder = s.height * s.width;
    float min_x = 99, min_y = 99, min_z = 99, max_x = 0.0, max_y = 0.0;
    for (int i = 0; i < boarder; i++)
    {
      if (mask_ptr[i] == 255)
      {
        if (!isnan(cloud.points[i].x) && !isinf(cloud.points[i].x))
        {
          x_vec.push_back(cloud.points[i].x);
          min_x = min(min_x, cloud.points[i].x);
          max_x = min(max_x, cloud.points[i].x);
        }
        if (!isnan(cloud.points[i].y) && !isinf(cloud.points[i].y))
        {
          y_vec.push_back(cloud.points[i].y);
          min_y = min(min_y, cloud.points[i].y);
          max_y = min(max_y, cloud.points[i].y);
        }
        if (!isnan(cloud.points[i].z) && !isinf(cloud.points[i].z))
        {
          z_vec.push_back(cloud.points[i].z);
          min_z = min(min_z, cloud.points[i].z);
        }
      }
    }

    float x_min_tray = min_x + 0.015;
    float x_max_tray = max_x - 0.015;
    float y_min_tray = min_y + 0.05;
    float y_max_tray = max_y - 0.05;
    float z_min_tray = min_z;
    float z_max_tray = z_min_tray + 0.02;

    ROS_INFO_STREAM("x_min: " << x_min_tray);
    ROS_INFO_STREAM("x_max: " << x_max_tray);
    ROS_INFO_STREAM("y_min: " << y_min_tray);
    ROS_INFO_STREAM("y_max: " << y_max_tray);
    ROS_INFO_STREAM("z_min: " << z_min_tray);
    ROS_INFO_STREAM("z_max: " << z_max_tray);


    int z_size = z_vec.size();



    float x_object_in_tray;
    float y_object_in_tray;
    float z_object_in_tray;

    for(unsigned int i = 1; i < z_size; i++)
    {
      if((z_vec.at(i) > z_min_tray) && (z_vec.at(i) < z_max_tray) && (x_vec.at(i) < x_max_tray) && (x_vec.at(i) > x_min_tray)  && (y_vec.at(i) < y_max_tray) && (y_vec.at(i) > y_min_tray))
      {
        if(fabs(z_vec.at(i) - z_vec.at(i-1)) > 0.01)
        {
          //        x_vec_object_in_tray.push_back(i);
          //        y_vec_object_in_tray.push_back(i);
          //        z_vec_object_in_tray.push_back(i);
          //        z_object_in_tray = min(z_object_in_tray, z_vec_object_in_tray.at(i));
          z_object_in_tray = z_vec_object_in_tray.at(i);
        }
      }
    }

    for(int i = 0; i < z_size; i++)
    {
      if(z_object_in_tray == z_vec.at(i))
      {
        x_object_in_tray = x_vec_object_in_tray.at(i);
        y_object_in_tray = y_vec_object_in_tray.at(i);
      }
    }

    ObjectProperties OP_bbox;

    OP_bbox.center.x = x_object_in_tray;
    OP_bbox.center.y = y_object_in_tray + 0.005;
    OP_bbox.center.z = z_object_in_tray;

  }

  //    std::sort(x_vec_object_in_tray.begin(), x_vec_object_in_tray.end());
  //    std::sort(y_vec_object_in_tray.begin(), y_vec_object_in_tray.end());
  //    std::sort(z_vec_object_in_tray.begin(), z_vec_object_in_tray.end());

  //    float x_median_object_in_tray;
  //    float y_median_object_in_tray;
  //    float z_median_object_in_tray;

  //    int x_size_object_in_tray = x_vec_object_in_tray.size();
  //    int y_size_object_in_tray = y_vec_object_in_tray.size();
  //    int z_size_object_in_tray = z_vec_object_in_tray.size();

  //    if(x_size_object_in_tray != 0)
  //    {
  //      if(x_size_object_in_tray % 2 == 0)
  //      {
  //        x_median_object_in_tray = (x_vec_object_in_tray[x_size_object_in_tray/2-1] + x_vec_object_in_tray[x_size_object_in_tray/2]) / 2;
  //      }
  //      else
  //      {
  //        x_median_object_in_tray = x_vec_object_in_tray[x_size_object_in_tray/2];
  //      }
  //    }
  //    else
  //    {
  //      x_median_object_in_tray = std::numeric_limits<float>::quiet_NaN();
  //    }

  //    if(y_size_object_in_tray != 0)
  //    {
  //      if(y_size_object_in_tray % 2 == 0)
  //      {
  //        y_median_object_in_tray = (y_vec_object_in_tray[y_size_object_in_tray/2-1] + y_vec_object_in_tray[y_size_object_in_tray/2]) / 2;
  //      }
  //      else
  //      {
  //        y_median_object_in_tray = y_vec_object_in_tray[y_size_object_in_tray/2];
  //      }
  //    }
  //    else
  //    {
  //      y_median_object_in_tray = std::numeric_limits<float>::quiet_NaN();
  //    }

  //    if(z_size_object_in_tray != 0)
  //    {
  //      if(z_size_object_in_tray % 2 == 0)
  //      {
  //        z_median_object_in_tray = (z_vec_object_in_tray[z_size_object_in_tray/2-1] + z_vec_object_in_tray[z_size_object_in_tray/2]) / 2;
  //      }
  //      else
  //      {
  //        z_median_object_in_tray = z_vec_object_in_tray[z_size_object_in_tray/2];
  //      }
  //    }
  //    else
  //    {
  //      z_median_object_in_tray = std::numeric_limits<float>::quiet_NaN();
  //    }







  //    ROS_INFO_STREAM(boarder);

  //    std::vector<float> x_left;
  //    std::vector<float> y_left;
  //    std::vector<float> z_left;

  //    int x_left_last;
  //    int y_left_last;
  //    int z_left_last;

  //    std::vector<float> x_right;
  //    std::vector<float> y_right;
  //    std::vector<float> z_right;

  //    int x_right_last;
  //    int y_right_last;
  //    int z_right_last;

  //    ROS_INFO_STREAM(z_vec_object_in_tray.size());
  //    for(unsigned int i = 1; i < (z_vec_object_in_tray.size()); i++)
  //    {
  //      ROS_INFO("in schlef");
  //      if((z_vec_object_in_tray.at(i) - z_vec_object_in_tray.at((i-1))) < -0.008)
  //      {
  //        ROS_INFO("in");
  //        x_left.push_back(x_vec_object_in_tray.at(i));
  //        y_left.push_back(y_vec_object_in_tray.at(i));
  //        z_left.push_back(z_vec_object_in_tray.at(i));

  //        x_left_last = x_left.at(i);
  //        y_left_last = y_left.at(i);
  //        z_left_last = z_left.at(i);
  //      }
  //      if((z_vec_object_in_tray.at(i) - z_vec_object_in_tray.at((i-1))) > 0.008)
  //      {
  //        ROS_INFO("in 2");
  //        x_right.push_back(x_vec_object_in_tray.at(i));
  //        y_right.push_back(y_vec_object_in_tray.at(i));
  //        z_right.push_back(z_vec_object_in_tray.at(i));

  //        x_right_last = x_right.at(i);
  //        y_right_last = y_right.at(i);
  //        z_right_last = z_right.at(i);
  //      }
  //    }

  //    ROS_INFO_STREAM(z_left.size());

  //    if(z_left.size() != 0 || z_right.size() != 0)
  //    {
  //      for(int i = 0; i < z_left.size() && i < z_right.size(); i++)
  //      {
  //        if(x_left.size() < x_right.size())
  //        {
  //          ROS_INFO_STREAM("x_left ist größer als x_right");
  //          if((x_right.at(i) - x_left.at(i) < 0.03) || (y_left.at(0) - y_left.at(x_left.size()-1) < 0.03))
  //          {
  //            ROS_INFO_STREAM("erkannt left");
  //            OP_bbox.center.x = x_left_last + ((x_right_last - x_left_last) / 2);
  //            OP_bbox.center.y = x_left_last + ((x_right_last - x_left_last) / 2);
  //            OP_bbox.center.z = z_left_last;
  //          }
  //        }
  //        else if(x_left.size() > x_right.size())
  //        {
  //          ROS_INFO_STREAM("x_left ist kleiner als x_right");
  //          if((x_right.at(i) - x_left.at(i) < 0.03) || (y_left.at(0) - y_left.at(x_right.size()-1) < 0.03))
  //          {
  //            ROS_INFO_STREAM("erkannt right");
  //            OP_bbox.center.x = x_left_last + ((x_right_last - x_left_last) / 2);
  //            OP_bbox.center.y = x_left_last + ((x_right_last - x_left_last) / 2);
  //            OP_bbox.center.z = z_left_last;
  //          }
  //        }
  //      }
  //    }

  //  }

  return  OP_bbox;
}

//########## DRAW BOUNDING BOX #########################################################################################
cv::Mat ObjectDetection::drawBoundingBox(ObjectProperties properties, cv::Mat &image)
{
  // =========== Aufgabe 5 ===========================================================================================

  /* Die Bounding-Box des detektierten Objekts soll in das Farbild (image) eingezeichnet werden. Das Bild mit
     * eingezeichneter Bounding-Box soll zurückgegeben werden. Das Ausgangsbild soll die gleiche Größe und Dimension
     * wie das Eingangsbild haben.
     *
     * ==> Projizieren Sie die Bounding-Box (aus properties) in das Farbbild (image). Zeichnen dann Sie eine
     *     2D-Bounding-Box in das Farbbild ein und geben dieses als Rückgabewert zurück
     */

  // =========== Hinweise ============================================================================================

  /*
     * Links:
     *   http://wiki.ros.org/image_geometry/Tutorials/ProjectTfFrameToImage
     *   http://docs.opencv.org/2.4/modules/core/doc/drawing_functions.html
     *
     */
  // =================================================================================================================

  // Mittelpunkt
  cv::Point3d pt_cv(properties.center.x, properties.center.y, properties.center.z);

  uv = camera_model_.project3dToPixel(pt_cv);
  cv::circle(image, uv, 3, CV_RGB(0,0,0), -1);

  // 3-dimensional
  //    // 8 Boxpunkte
  //    cv::Point3d point1_3d(properties.bounding_box_min_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_min_corner.z);
  //    cv::Point2d point1;
  //    point1 = camera_model_.project3dToPixel(point1_3d);

  //    cv::Point3d point2_3d(properties.bounding_box_min_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_min_corner.z);
  //    cv::Point2d point2;
  //    point2 = camera_model_.project3dToPixel(point2_3d);

  //    cv::Point3d point3_3d(properties.bounding_box_min_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_max_corner.z);
  //    cv::Point2d point3;
  //    point3 = camera_model_.project3dToPixel(point3_3d);

  //    cv::Point3d point4_3d(properties.bounding_box_min_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_max_corner.z);
  //    cv::Point2d point4;
  //    point4 = camera_model_.project3dToPixel(point4_3d);

  //    cv::Point3d point5_3d(properties.bounding_box_max_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_min_corner.z);
  //    cv::Point2d point5;
  //    point5 = camera_model_.project3dToPixel(point5_3d);

  //    cv::Point3d point6_3d(properties.bounding_box_max_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_max_corner.z);
  //    cv::Point2d point6;
  //    point6 = camera_model_.project3dToPixel(point6_3d);

  //    cv::Point3d point7_3d(properties.bounding_box_max_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_min_corner.z);
  //    cv::Point2d point7;
  //    point7 = camera_model_.project3dToPixel(point7_3d);

  //    cv::Point3d point8_3d(properties.bounding_box_max_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_max_corner.z);
  //    cv::Point2d point8;
  //    point8 = camera_model_.project3dToPixel(point8_3d);

  //    // Polylinien für die Box zusammengesetzt aus den Boxpunkten
  //    vector<Point> points_a;
  //    points_a.push_back(point1);
  //    points_a.push_back(point2);
  //    points_a.push_back(point3);
  //    points_a.push_back(point4);
  //    cv::polylines(image, points_a, 3, Scalar(0, 0, 0));

  //    vector<Point> points_b;
  //    points_b.push_back(point3);
  //    points_b.push_back(point4);
  //    points_b.push_back(point8);
  //    points_b.push_back(point6);
  //    cv::polylines(image, points_b, 3, Scalar(0, 0, 0));

  //    vector<Point> points_c;
  //    points_c.push_back(point5);
  //    points_c.push_back(point6);
  //    points_c.push_back(point8);
  //    points_c.push_back(point7);
  //    cv::polylines(image, points_c, 3, Scalar(0, 0, 0));

  //    vector<Point> points_d;
  //    points_d.push_back(point1);
  //    points_d.push_back(point2);
  //    points_d.push_back(point5);
  //    points_d.push_back(point7);
  //    cv::polylines(image, points_d, 3, Scalar(0, 0, 0));

  // 2-dimensional
  // 4 Boxpunkte
  cv::Point3d point1_3d(properties.bounding_box_min_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_min_corner.z);
  cv::Point2d point1;
  point1 = camera_model_.project3dToPixel(point1_3d);

  cv::Point3d point2_3d(properties.bounding_box_min_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_min_corner.z);
  cv::Point2d point2;
  point2 = camera_model_.project3dToPixel(point2_3d);

  cv::Point3d point3_3d(properties.bounding_box_max_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_min_corner.z);
  cv::Point2d point3;
  point3 = camera_model_.project3dToPixel(point3_3d);

  cv::Point3d point4_3d(properties.bounding_box_max_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_min_corner.z);
  cv::Point2d point4;
  point4 = camera_model_.project3dToPixel(point4_3d);

  // Polylinien für die Box zusammengesetzt aus den Boxpunkten
  vector<Point> points_a;
  points_a.push_back(point1);
  points_a.push_back(point2);
  points_a.push_back(point3);
  points_a.push_back(point4);
  cv::polylines(image, points_a, 3, Scalar(0, 0, 0));

  cv_bridge::CvImage img_bridge;
  sensor_msgs::Image img_msg;

  std_msgs::Header header;
  header.stamp = ros::Time::now();
  img_bridge = cv_bridge::CvImage(header, sensor_msgs::image_encodings::RGB8, image);
  img_bridge.toImageMsg(img_msg);
  image_pub_result_.publish(img_msg);

  //        imshow("Bounding Box und Mittelpunkt", image);
  //        cv::waitKey(1);

  return image;
}

//########## PUBLISH OBJECT POSE #######################################################################################
void ObjectDetection::publishObjectPose(cv::Point3d position, std_msgs::Header header)
{
  geometry_msgs::PoseStamped pose_msg;
  pose_msg.header = header;
  pose_msg.header.stamp = ros::Time::now();
  pose_msg.pose.position.x = position.x;
  pose_msg.pose.position.y = position.y;
  pose_msg.pose.position.z = position.z;
  pose_msg.pose.orientation.w = 1;

  if (mode_ == 0)
  {
    object_pub_.publish(pose_msg);
  }
  else if(mode_ == 1)
  {
    object_pub2_.publish(pose_msg);
  }
  else if(mode_ == 2)
  {
    object_pub3_.publish(pose_msg);
  }

}

//########## TRANSFORM TO RGB FRAME ####################################################################################
ObjectProperties ObjectDetection::transformProperties(ObjectProperties properties, std_msgs::Header pointcloud_header)
{
  tf::StampedTransform transform;
  // camera_model_.tfFrame()
  if(mode_ == 0 || mode_ == 2 || mode_ == 3)
  {
    try
    {
      tf_listener_.waitForTransform("/arm_link_0", pointcloud_header.frame_id,
                                    ros::Time(0), ros::Duration(0.1));
      tf_listener_.lookupTransform("/arm_link_0", pointcloud_header.frame_id,
                                   ros::Time(0), transform);

    }
    catch(tf::TransformException& ex)
    {
      ROS_WARN("TF exception:\n%s", ex.what());
      return properties;
    }
  }
  else if(mode_ == 1)
  {
    try
    {
      tf_listener_.waitForTransform("/base_link", pointcloud_header.frame_id,
                                    ros::Time(0), ros::Duration(0.1));
      tf_listener_.lookupTransform("/base_link", pointcloud_header.frame_id,
                                   ros::Time(0), transform);
    }
    catch(tf::TransformException& ex)
    {
      ROS_WARN("TF exception:\n%s", ex.what());
      return properties;
    }
  }

  ObjectProperties transformed_props;

  tf::Vector3 center;
  center.setX(properties.center.x);
  center.setY(properties.center.y);
  center.setZ(properties.center.z);

  center = transform(center);


  double x = center.getX();
  double y = center.getY();
  double z = center.getZ();

  if(mode_ == 0)
  {
    double radius = sqrt(x*x + y*y);
    //    ROS_INFO_STREAM(radius);

    if (radius > 0.15 && radius < 0.40)
    {
      x = x;
      y = y;
      z = z;
    }
    else
    {
      x = std::numeric_limits<double>::quiet_NaN();
      y = std::numeric_limits<double>::quiet_NaN();
      z = std::numeric_limits<double>::quiet_NaN();
    }
  }
  else if(mode_ == 2 || mode_ == 3)
  {
    double radius = sqrt(x*x + y*y);

    if (radius > 0.25 && radius < 0.35)
    {
      x = x;
      y = y;
      z = z;
    }
    else
    {
      x = std::numeric_limits<double>::quiet_NaN();
      y = std::numeric_limits<double>::quiet_NaN();
      z = std::numeric_limits<double>::quiet_NaN();
    }
  }

  center.setX(x);
  center.setY(y);
  center.setZ(z);


  if(object_detected == true)
  {

    tf::Vector3 bbmin;
    bbmin.setX(properties.bounding_box_min_corner.x);
    bbmin.setY(properties.bounding_box_min_corner.y);
    bbmin.setZ(properties.bounding_box_min_corner.z);

    tf::Vector3 bbmax;
    bbmax.setX(properties.bounding_box_max_corner.x);
    bbmax.setY(properties.bounding_box_max_corner.y);
    bbmax.setZ(properties.bounding_box_max_corner.z);
    bbmin = transform(bbmin);
    bbmax = transform(bbmax);
    transformed_props.bounding_box_min_corner.x = bbmin.x();
    transformed_props.bounding_box_min_corner.y = bbmin.y();
    transformed_props.bounding_box_min_corner.z = bbmin.z();
    transformed_props.bounding_box_max_corner.x = bbmax.x();
    transformed_props.bounding_box_max_corner.y = bbmax.y();
    transformed_props.bounding_box_max_corner.z = bbmax.z();
  }

  transformed_props.center.x = center.x();
  transformed_props.center.y = center.y();
  transformed_props.center.z = center.z();

  return transformed_props;
}

//########## PUBLISH DEBUG IMAGE #######################################################################################
void ObjectDetection::publishDebugImage(cv::Mat &image)
{
  // convert image to image message and publish
  sensor_msgs::Image msg;
  msg.width = image.cols;
  msg.height = image.rows;
  msg.step = image.cols * 3;
  msg.data.assign(image.data, image.data + image.cols*image.rows*image.channels());
  msg.encoding = sensor_msgs::image_encodings::RGB8;
  image_pub_.publish(msg);
}

//########## DYNAMIC RECONFIGURE CALLBACK ##############################################################################
void ObjectDetection::dynamicReconfigureCallback(object_detection::ObjectDetectionConfig &config, uint32_t level)
{
  // === Params for blob detection ===
  min_blob_size_ = config.blob_min_size * config.blob_min_size; // square to get logarithmic scale for slider element
  max_blob_size_ = config.blob_max_size * config.blob_max_size; // square to get logarithmic scale for slider element

  radius_limit = config.radius;

  //      morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
  //                                                  cv::Size(2 * config.morph_kernel_size_1 + 1,
  //                                                           2 * config.morph_kernel_size_1 + 1),
  //                                                  cv::Point(config.morph_kernel_size_1, config.morph_kernel_size_1));
  //      morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
  //                                                  cv::Size(2 * config.morph_kernel_size_2 + 1,
  //                                                           2 * config.morph_kernel_size_2 + 1),
  //                                                  cv::Point(config.morph_kernel_size_2, config.morph_kernel_size_2));
  //      morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
  //                                                  cv::Size(2 * config.morph_kernel_size_3 + 1,
  //                                                           2 * config.morph_kernel_size_3 + 1),
  //                                                  cv::Point(config.morph_kernel_size_3, config.morph_kernel_size_3));

  //      h_min_ = config.color_filter_h_min;
  //    h_max_ = config.color_filter_h_max;
  //  s_min_ = config.color_filter_s_min;
  //   s_max_ = config.color_filter_s_max;
  //  v_min_ = config.color_filter_v_min;
  // v_max_ = config.color_filter_v_max;
}

//########## MAIN ######################################################################################################
int main(int argc, char** argv)
{
  ros::init(argc, argv, "object_detection_node");

  ros::NodeHandle node_handle;
  ObjectDetection object_detection(node_handle);

  ROS_INFO("Node is spinning ...");
  ros::spin();

  return 0;
}
