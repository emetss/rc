/* *****************************************************************
 *
 * object_detection
 *
 * Copyright (c) %YEAR%,
 * Institute of Mechatronic Systems,
 * Leibniz Universitaet Hannover.
 * (BSD License)
 * All rights reserved.
 *
 * http://www.imes.uni-hannover.de
 *
 * This software is distributed WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE.
 *
 * For further information see http://www.linfo.org/bsdlicense.html
 *
 ******************************************************************/

/**
 * @file   %FILENAME%
 * @author %USER% (%$EMAIL%)
 * @date   %DATE%
 *
 * @brief  Filedescription
 */

#include "service_area_detection/service_area_detection_node.h"



using namespace cv;
using namespace std;



//########## CONSTRUCTOR ###############################################################################################
ServiceAreaDetection::ServiceAreaDetection(ros::NodeHandle &node_handle):
  node_(&node_handle),
  it_(node_handle)
{
  // publisher/subscriber
  trigger_ = node_->advertiseService("service_area_detection/trigger", &ServiceAreaDetection::serviceTrigger, this);
  //point_cloud_sub_ = node_->subscribe("camera/depth_registered/points_corrected", 1, &ServiceAreaDetection::pointCloudCallback, this);
  //point_cloud_sub_ = node_->subscribe("camera/depth_registered/points", 1, &ServiceAreaDetection::pointCloudCallback, this);
  image_pub_ = it_.advertise("service_area_detection/debug_image", 1);
  image_pub_result_ = it_.advertise("service_area_detection/result", 1);
  //image_sub_ = it_.subscribe("/camera/rgb/image_raw", 1, &ServiceAreaDetection::imageCallback, this);
  camera_sub_ = node_->subscribe("/camera/rgb/camera_info", 1, &ServiceAreaDetection::cameraCallback, this);
  object_pub_ = node_->advertise<geometry_msgs::PoseStamped>("service_area_detection/object_pose", 1);

  //image_sub_.shutdown();

  // dynamic reconfigure
  dynamic_reconfigure::Server<service_area_detection::ServiceAreaDetectionConfig>::CallbackType f;
  f = boost::bind(&ServiceAreaDetection::dynamicReconfigureCallback, this, _1, _2);
  dyn_reconf_server_.setCallback(f);
}



//########## DESTRUCTOR ################################################################################################
ServiceAreaDetection::~ServiceAreaDetection()
{

}

bool ServiceAreaDetection::serviceTrigger(std_srvs::SetBool::Request &req, std_srvs::SetBool::Response &res)
{
  bool status = req.data;

  if(status)
  {
    image_sub_ = it_.subscribe("/camera/rgb/image_raw", 1, &ServiceAreaDetection::imageCallback, this);
    //     point_cloud_sub_ = node_->subscribe("camera/depth_registered/points_corrected", 1, &ServiceAreaDetection::pointCloudCallback, this);
    point_cloud_sub_ = node_->subscribe("camera/depth_registered/points", 1, &ServiceAreaDetection::pointCloudCallback, this);
    res.message = "turned on";
  }else
  {
    //image_sub_ = it_.subscribe("/camera/empty_topic", 1, &ServiceAreaDetection::imageCallback, this);
    image_sub_.shutdown();
    point_cloud_sub_.shutdown();
    res.message = "turned off";
  }
  return true;
}

//########## CAMERA CALLBACK ############################################################################################
void ServiceAreaDetection::cameraCallback(const sensor_msgs::CameraInfoConstPtr &info_msg)
{
  // save camera parameters to camera model
  camera_model_.fromCameraInfo(info_msg);
}

//########## IMAGE CALLBACK ############################################################################################
void ServiceAreaDetection::imageCallback(const sensor_msgs::ImageConstPtr& image_msg)
{
  // convert image to cv::Mat
  cv_bridge::CvImagePtr input_bridge;
  try {
    input_bridge = cv_bridge::toCvCopy(image_msg, sensor_msgs::image_encodings::BGR8);
    rgb_img = input_bridge->image;
  }
  catch (cv_bridge::Exception& ex){
    ROS_ERROR("Failed to convert image");
  }
}

//########## POINTCLOUD CALLBACK #######################################################################################
void ServiceAreaDetection::pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr& input)
{
  // Prüfen, ob RGB-Bild und Kamerainfo verfügbar sind
  if(!camera_model_.initialized() || rgb_img.empty())
    return;

  // Punktwolke in PCL-Datentyp konvertieren
  pcl::PointCloud<pcl::PointXYZRGB> cloud;

  pcl::fromROSMsg (*input, cloud);
  std_msgs::Header pc_header = input->header;

  // HSV-Farbraum
  // Zweiter Index = 0: h_min
  // Zweiter Index = 1: h_max
  // Zweiter Index = 2: s_min
  // Zweiter Index = 3: s_max
  // Zweiter Index = 4: v_min
  // Zweiter Index = 5: v_max

  //  vector<vector<float> > hsvTableTray(5,vector<float>(6));

  //  // HSV-Raum Tray

  //  // BLAU: Erster Index = 0
  //  hsvTableTray[0][0] =   0;
  //  hsvTableTray[0][1] =  20;
  //  hsvTableTray[0][2] =   0;
  //  hsvTableTray[0][3] = 255;
  //  hsvTableTray[0][4] = 140;
  //  hsvTableTray[0][5] = 255;

  //  // GRÜN: Erster Index = 1
  //  hsvTableTray[1][0] =  40;
  //  hsvTableTray[1][1] =  70;
  //  hsvTableTray[1][2] =   0;
  //  hsvTableTray[1][3] = 255;
  //  hsvTableTray[1][4] =   0;
  //  hsvTableTray[1][5] = 255;

  //  // GELB: Erster Index = 2
  //  hsvTableTray[2][0] =  80;
  //  hsvTableTray[2][1] = 100;
  //  hsvTableTray[2][2] =   0;
  //  hsvTableTray[2][3] = 255;
  //  hsvTableTray[2][4] =   0;
  //  hsvTableTray[2][5] = 255;

  //  // ROT: Erster Index = 3
  //  hsvTableTray[3][0] = 110;
  //  hsvTableTray[3][1] = 130;
  //  hsvTableTray[3][2] =   0;
  //  hsvTableTray[3][3] = 255;
  //  hsvTableTray[3][4] =   0;
  //  hsvTableTray[3][5] = 255;

  vector<vector<float> > hsvTablePyramide(5,vector<float>(6));

  // HSV-Raum Pyramide

  // BLAU: Erster Index = 0
  hsvTablePyramide[0][0] =   0;
  hsvTablePyramide[0][1] =  20;
  hsvTablePyramide[0][2] =  60;
  hsvTablePyramide[0][3] = 255;
  hsvTablePyramide[0][4] =  40;
  hsvTablePyramide[0][5] = 255;

  // GRÜN: Erster Index = 1
  hsvTablePyramide[1][0] =  40;
  hsvTablePyramide[1][1] =  70;
  hsvTablePyramide[1][2] =  60;
  hsvTablePyramide[1][3] = 255;
  hsvTablePyramide[1][4] =  40;
  hsvTablePyramide[1][5] = 255;

  // GELB: Erster Index = 2
  hsvTablePyramide[2][0] =  80;
  hsvTablePyramide[2][1] = 100;
  hsvTablePyramide[2][2] =  60;
  hsvTablePyramide[2][3] = 255;
  hsvTablePyramide[2][4] =  40;
  hsvTablePyramide[2][5] = 255;

  // ROT: Erster Index = 3
  hsvTablePyramide[3][0] = 110;
  hsvTablePyramide[3][1] = 130;
  hsvTablePyramide[3][2] =  60;
  hsvTablePyramide[3][3] = 255;
  hsvTablePyramide[3][4] =  40;
  hsvTablePyramide[3][5] = 255;

  //  std::vector<int> morph_opening;
  //  std::vector<int> morph_closing;
  //  std::vector<int> morph_erosion;

  //  morph_opening.resize(2);
  //  morph_closing.resize(2);
  //  morph_erosion.resize(2);

  //  morph_opening[0] = 12;
  //  morph_opening[1] = 55;

  //  morph_closing[0] = 10;
  //  morph_closing[1] = 50;

  //  morph_erosion[0] = 2;
  //  morph_erosion[1] = 2;


  // declare variables
  std::vector<ObjectProperties> objects_trays;
  std::vector<ObjectProperties> objects_pyramids;

  objects_trays.resize(4);
  objects_pyramids.resize(4);

  std::vector<bool> trays_detected;
  std::vector<bool> pyramids_detected;

  trays_detected.resize(4);
  pyramids_detected.resize(4);

  int index_tray;
  int index_pyramide;

  std::vector<bool> tray_detected;
  std::vector<bool> pyramide_detected;

  tray_detected.resize(4);
  pyramide_detected.resize(4);






  ROS_INFO("########### SEARCH PYRAMIDES ##############");
  //  morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
  //                                              cv::Size(2*12+1, 2*12+1),
  //                                              cv::Point(12, 12));
  //  morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
  //                                              cv::Size(2*10+1, 2*10+1),
  //                                              cv::Point(10, 10));
  //  morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
  //                                              cv::Size(2*2+1, 2*2+1),
  //                                              cv::Point(2, 2));

  for(int i = 0; i < 4; i++)
  {
    object_detected = false;

    h_min_ = hsvTablePyramide[i][0];
    h_max_ = hsvTablePyramide[i][1];
    s_min_ = hsvTablePyramide[i][2];
    s_max_ = hsvTablePyramide[i][3];
    v_min_ = hsvTablePyramide[i][4];
    v_max_ = hsvTablePyramide[i][5];

    cv::Mat raw_mask = createObjectMask(cloud);
    cv::Mat filtered_mask = filterObjectMask(raw_mask);
    clearBorder(filtered_mask);
    cv::Mat object_mask = selectBlob(filtered_mask);
    ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

    if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
    {
      ROS_INFO_STREAM("Color " << i << " NOT detected at pyramids");
      ROS_INFO_STREAM("x: " << object_properties.center.x << " y: " << object_properties.center.y << " z: " << object_properties.center.z);
      pyramids_detected.at(i) = false;
      continue;
    }
    else
    {
      ROS_INFO_STREAM("Color " << i << " is detected at pyramids");
      pyramids_detected.at(i) = true;
      index_pyramide = i;
    }

    objects_pyramids.at(i) = transformProperties(object_properties, pc_header);
  }

  ROS_INFO("########### SEARCH TRAYS ##############");
  //  morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
  //                                              cv::Size(2*45+1, 2*45+1),
  //                                              cv::Point(45, 45));
  //  morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
  //                                              cv::Size(2*40+1, 2*40+1),
  //                                              cv::Point(40, 40));
  //  morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
  //                                              cv::Size(2*2+1, 2*2+1),
  //                                              cv::Point(2, 2));

  for(int i = 0; i < 4; i++)
  {
    object_detected = false;

    h_min_ = hsvTablePyramide[i][0];
    h_max_ = hsvTablePyramide[i][1];
    s_min_ = hsvTablePyramide[i][2];
    s_max_ = hsvTablePyramide[i][3];
    v_min_ = hsvTablePyramide[i][4];
    v_max_ = hsvTablePyramide[i][5];

    cv::Mat raw_mask = createObjectMask(cloud);
    cv::Mat filtered_mask = filterObjectMask(raw_mask);
    clearBorder(filtered_mask);
    cv::Mat object_mask = selectBlob(filtered_mask);
    ObjectProperties object_properties = getObjectProperties(cloud, object_mask);

    if(isnan(object_properties.center.x) || isnan(object_properties.center.y) || isnan(object_properties.center.z))
    {
      ROS_INFO_STREAM("Color " << i << " NOT detected at trays");
      ROS_INFO_STREAM("x: " << object_properties.center.x << " y: " << object_properties.center.y << " z: " << object_properties.center.z);
      trays_detected.at(i) = false;
      continue;
    }
    else
    {
      ROS_INFO_STREAM("Color " << i << " is detected at trays");
      trays_detected.at(i) = true;
      index_tray = i;
    }

    objects_trays.at(i) = transformProperties(object_properties, pc_header);
  }

  for(int i = 0; i < 4; i++)
  {
    if(pyramids_detected.at(i) == trays_detected.at(i) && pyramids_detected.at(i))
    {
      pyramide_detected.at(i) = false;
      tray_detected.at(i) = true;
    }
  }

  std_msgs::Header new_head = input->header;

  for(int i = 0; i < 4; i++)
  {

    if(pyramide_detected.at(i))
    {
      if(index_pyramide == 0)
      {
        ROS_INFO_STREAM("BLUE Pyram - x:  " << objects_pyramids.at(0).center.x << "  y:  " << objects_pyramids.at(0).center.y);
        new_head.frame_id = "blue";
      }
      else if(index_pyramide == 1)
      {
        ROS_INFO_STREAM("GREEN Pyram - x: " << objects_pyramids.at(1).center.x << "  y:  " << objects_pyramids.at(1).center.y);
        new_head.frame_id = "green";
      }
      else if(index_pyramide == 2)
      {
        ROS_INFO_STREAM("YELLOW Pyram - x:" << objects_pyramids.at(2).center.x << "  y:  " << objects_pyramids.at(2).center.y);
        new_head.frame_id = "yellow";
      }
      else if(index_pyramide == 3)
      {
        ROS_INFO_STREAM("RED Pyram - x:   " << objects_pyramids.at(3).center.x << "  y:  " << objects_pyramids.at(3).center.y);
        new_head.frame_id = "red";
      }
      // Übergabe an StateMachine zum erkennen einer Pyramide z = 1
      objects_pyramids.at(index_pyramide).center.z = 1;
      publishObjectPose(objects_pyramids.at(index_pyramide).center, new_head);
    }
    else if(tray_detected.at(i))
    {
      if(index_tray == 0)
      {
        ROS_INFO_STREAM("BLUE Tray - x:   " << objects_trays.at(0).center.x << "  y:  " << objects_trays.at(0).center.y);
        new_head.frame_id = "blue";
      }
      else if(index_tray == 1)
      {
        ROS_INFO_STREAM("GREEN Tray - x:  " << objects_trays.at(1).center.x << "  y:  " << objects_trays.at(1).center.y);
        new_head.frame_id = "green";
      }
      else if(index_tray == 2)
      {
        ROS_INFO_STREAM("YELLOW Tray - x: " << objects_trays.at(2).center.x << "  y:  " << objects_trays.at(2).center.y);
        new_head.frame_id = "yellow";
      }
      else if(index_tray == 3)
      {
        ROS_INFO_STREAM("RED Tray - x:    " << objects_trays.at(3).center.x << "  y:  " << objects_trays.at(3).center.y);
        new_head.frame_id = "red";
      }
      // Übergabe an StateMachine zum erkennen eines Tray z = 0
      objects_trays.at(index_tray).center.z = 0;
      publishObjectPose(objects_trays.at(index_tray).center, new_head);
    }
  }

  if(tray_detected.at(0) == false && tray_detected.at(1) == false && tray_detected.at(2) == false && tray_detected.at(3) == false &&
     pyramide_detected.at(0) == false && pyramide_detected.at(1) == false && pyramide_detected.at(2) == false && pyramide_detected.at(3) == false)
  {
    ROS_INFO_STREAM("Nothing detected");
    new_head.frame_id = "empty";
    // Übergabe an StateMachine zum erkennen einer leeren Area z = 2
    objects_trays.at(1).center.z = 2;
    publishObjectPose(objects_trays.at(1).center, new_head);
  }

}

// void ServiceAreaDetection::allFunctions(cloud, pc_header){


//}

//########## CREATE OBJECT MASK ########################################################################################
cv::Mat ServiceAreaDetection::createObjectMask(pcl::PointCloud<pcl::PointXYZRGB> &cloud)
{
  // =========== Aufgabe 1 ===========================================================================================

  /* Um die Punktwolke später nach Farbwerten filtern zu können, soll in dieser Methode zunächst eine Maske erstellt
     * werden, in welcher hinterlegt ist, welche Punkte den Filterkriterien entsprechen und welche nicht.
     * Ein Pixel der binären Maske soll einen Wert größer Null haben, wenn der zugehörige Punkt der Punktwolke den
     * Filterkriterien entspricht. Alle anderen Pixel sollen den Wert Null haben.
     * Die Filterkriterien sind als obere und untere Grenzwerte im HSV-Farbraum gegeben und stehen als Klassen-Member
     * zur Verfügung:
     * h_min_, h_max_, s_min_, s_max_, v_min_, v_max_
     *
     * Als Rückgabewert der Methode wird eine binäre OpenCV-Matrix (Typ CV_8UC1) mit gleicher Breite und Höhe wie die
     * Punktwolke erwartet.
     *
     * ==> Implementieren Sie den Farbfilter und geben Sie die Maske als Rückgabewert zurück!
     */

  // =========== Hinweise ============================================================================================

  /*  Eine Bildmatrix mit 3 (Farb-)Kanälen initialisieren:
    *    cv::Mat rgb_img(cloud_.width, cloud_.height, CV_8UC3);

    *  Pixel-Zugriff auf eine Bildmatrix über Pointer:
    *    unsigned char* rgb_ptr = rgb_img.ptr<unsigned char>();
    *    rgb_ptr[0] = R (Pixel 1)
    *    rgb_ptr[1] = G (Pixel 1)
    *    rgb_ptr[2] = B (Pixel 1)
    *    rgb_ptr[3] = R (Pixel 2)
    *    rgb_ptr[4] = G (Pixel 2)
    *    rgb_ptr[5] = B (Pixel 2)
    *    etc...

    *  Zugriff auf Punkte der Punktwolke:
    *    cloud.points[i].x;
    *    cloud.points[i].y;
    *    cloud.points[i].z;
    *    cloud.points[i].r;
    *    cloud.points[i].g;
    *    cloud.points[i].b;

    *  Nützliche Funktionen:
    *    cv::cvtColor
    *    cv::inRange

    *  Nützliche Klassen
    *    cv::Mat
    *    cv::Scalar
    */
  // =================================================================================================================

  // Eine Bildmatrix mit 3 Farb-Kanälen initialisieren:
  cv::Mat rgb_img(cloud.height, cloud.width, CV_8UC3);

  // Maske Bildmatrix mit 1 Farb-Kanal initialisieren
  cv::Mat maske(cloud.height, cloud.width, CV_8UC1);

  // Eine Bildmatrix im HSV-Raum
  cv::Mat hsvimage;

  for(int h = 0; h < cloud.height; h++)
  {
    for(int w = 0; w < cloud.width; w++)
    {
      pcl::PointXYZRGB point = cloud.at(w, h);

      Eigen::Vector3i rgb = point.getRGBVector3i();

      rgb_img.at<cv::Vec3b>(h, w)[0] = rgb[2];
      rgb_img.at<cv::Vec3b>(h, w)[1] = rgb[1];
      rgb_img.at<cv::Vec3b>(h, w)[2] = rgb[0];
    }
  }

  //    cv::imshow("RGB-Bild", rgb_img);
  //    cv::waitKey(1);

  // RGB-Bild in HSV-Bild
  cv::cvtColor(rgb_img, hsvimage, CV_RGB2HSV);
  //    cv::imshow("HSV-Bild", hsvimage);
  //    cv::waitKey(1);

  // HSV-Bild in Binär-Bild
  cv::Mat binaer;
  cv::inRange(hsvimage, cv::Scalar(h_min_, s_min_, v_min_), cv::Scalar(h_max_, s_max_, v_max_), binaer);
  //        cv::imshow("Binaer-Bild", binaer);
  //        cv::waitKey(1);

  maske = binaer;

  return maske;
}

//########## FILTER OBJECT MASK ########################################################################################
cv::Mat ServiceAreaDetection::filterObjectMask(cv::Mat &mask)
{
  // =========== Aufgabe 2 ===========================================================================================

  /* Mit morphologischen Filtern kann die binäre Maske "bereinigt" werden. Z.B. können vereinzelte Pixel eliminiert
     * oder Löcher in zusammengehörenden Bereichen gefüllt werden.
     * Sehen Sie sich die Maske vor der Filterung an und implementieren Sie geeignete morphologische Operationen, um
     * unerwünschte Artefakte in der Maske zu beseitigen.
     *
     * ==> Implementieren Sie zwei morphologische Filteroperationen und verwenden Sie die Parameter
     *     "morph_kernel_1_" und "morph_kernel_2_" als Filterkerne.
     */

  // =========== Hinweise ============================================================================================

  /*
     * Links:
     *     http://docs.opencv.org/2.4.2/doc/tutorials/imgproc/erosion_dilatation/erosion_dilatation.html
     *     http://docs.opencv.org/2.4.2/doc/tutorials/imgproc/opening_closing_hats/opening_closing_hats.html
    */
  // =================================================================================================================

  Mat opening_result;
  Mat closing_result;
  Mat erosion_result;

  // Operator
  // Opening:     0
  // Closing:     1
  // Gradient:    2
  // Top Hat:     3
  // Black Hat:   4
  int operator_opening = 0;
  int operator_closing = 1;

  morphologyEx(mask, opening_result, operator_opening, morph_kernel_1_);
  //    imshow("Opening Demo", opening_result);
  //    cv::waitKey(1);

  morphologyEx(opening_result, closing_result, operator_closing, morph_kernel_2_);
  //    imshow("Closing Demo", opening_result);
  //    cv::waitKey(1);

  erode(closing_result, erosion_result, morph_kernel_3_);
  // imshow("Erosion Demo", erosion_result);
  // cv::waitKey(1);

  mask = erosion_result;

  return mask;
}

//########## CLEAR BORDER ##############################################################################################
void ServiceAreaDetection::clearBorder(cv::Mat &mask)
{
  // remove all blobs that touch the image border
  unsigned char* p = mask.ptr<unsigned char>(0);
  for(int i = 0; i < mask.cols; i++)
  {
    p[i] = 255;
    p[mask.cols*mask.rows-1-i] = 255;
  }
  for(int i = 1; i < mask.rows; i++)
  {
    int j = i*mask.cols-1;
    p[j++] = 255;
    p[j] = 255;
  }
  cv::floodFill(mask,cv::Point(0, 0), 0);
}

//########## DETECT BLOBS ##############################################################################################
cv::Mat ServiceAreaDetection::selectBlob(cv::Mat &mask)
{
  // =========== Aufgabe 3 ===========================================================================================

  /* Um einzelne Objekte im Bild identifizieren zu können, müssen in der Maske zusammenhängende Bereiche (sog. Blobs)
     * gefunden werden. Diese Methode soll zunächst alle Blobs in der Maske finden und anschließend einen geeigneten
     * Blob auswählen und als neue Maske zurückgeben. Die Rückgabe-Maske soll die gleiche Größe und den gleichen Typ
     * wie die Eingangsmaske haben.
     *
     * Zur Vorauswahl geeigneter Blobs können Sie die Parameter "min_blob_size_" und "max_blob_size_" verwenden. Eine
     * Möglichkeit zur Auswahl wäre z.B., den größten Blob auszuwählen, der kleiner als "max_blob_size_" ist.
     *
     * ==> Finden Sie zuerst alle Blobs in der Eingangsmaske und wählen Sie anschließend einen geeigneten Blob aus und
     *     geben diesen als neue binäre Maske zurück.
     */

  // =========== Hinweise ============================================================================================

  /*
     * Links:
     *    http://docs.opencv.org/2.4/doc/tutorials/imgproc/shapedescriptors/find_contours/find_contours.html
     *    http://docs.opencv.org/2.4/modules/imgproc/doc/structural_analysis_and_shape_descriptors.html
     *
     * Nützliche Funktionen:
     *    cv::findContours
     *    cv::ContourArea
     *    cv::drawContours

    */
  // =================================================================================================================

  Mat blob_output;
  vector<vector<Point> > contours;
  vector<Vec4i> hierarchy;

  blob_output = mask;

  // Find contours
  findContours(blob_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));


  // Draw contours
  Mat drawing = Mat::zeros(blob_output.size(), CV_8UC3);
  Scalar color = Scalar(0, 0, 255);
  for(int i = 0; i < contours.size(); i++)
  {
    drawContours(drawing, contours, i, color, 2, 8, hierarchy, 0, Point());
  }

  Mat drawing2 = Mat::zeros(blob_output.size(), CV_8UC1);
  int i_max = 0, size_max = 0;
  for(int i = 0; i < contours.size(); i++)
  {
    double area_size = contourArea(contours[i]);
    if((area_size > min_blob_size_) && (area_size < max_blob_size_))
    {
      if(area_size > size_max)
      {
        size_max = area_size;
        i_max = i;
        //ROS_INFO("Max Area %d", size_max);
        object_detected = true;
      }
      //            if(!object_detected)
      //            {
      //                ROS_INFO("No Object Detected");
      //            }

      rectangle(drawing2, boundingRect(contours[i]), Scalar(0,255,0), 2, 8, 0);
    }
  }

  color = Scalar(255, 255, 255);
  drawContours(drawing2, contours, i_max, color, -1, 8, hierarchy, 0, Point());
  //        imshow("Contours", drawing);
  //        cv::waitKey(1);

  mask = drawing2;

  return mask;
}

//########## GET OBJECT CENTERS ########################################################################################
ObjectProperties ServiceAreaDetection::getObjectProperties(pcl::PointCloud<pcl::PointXYZRGB> &cloud, cv::Mat &mask)
{
  // =========== Aufgabe 4 ===========================================================================================

  /* Wenn die Maske für ein einzelnes Objekt vorliegt, kann diese verwendet werden, um die Position des Objekts
     * aus der Punktwolke zu berechnen. In dieser Methode soll der 3D-Mittelpunkt und die 3D-Bounding-Box der über die
     * Maske selektierten Punkte berechnet werden.
     * Die Bounding-Box wird über zwei Eckpunkte (min und max) definiert. Alle Rückgabewerte können in der Struktur
     * "ObjectProperties" gespeichert und zurückgegeben werden.
     *
     * ==> Iterieren Sie durch die Maske bzw. Punktwolke und berechnen Sie Mittelpunkt und Bounding-Box des über die
     *     Maske selektierten Objekts.
     */


  /* =========== Hinweise ============================================================================================
    *  Zugriff auf Maske über Pointer:
    *    bool* mask_ptr = mask.ptr<bool>();
    *    bool value = mask_ptr[i];
    *
    * Zugriff auf Punkte der Punktwolke:
    *    float x = cloud.points[i].x
    *    float y = cloud.points[i].y
    *    float z = cloud.points[i].z
    *
    * Nützliche Funktionen:
    *    std::min
    *    std::max
    *
    * Achtung: In der Punktwolke gibt es immer einige ungültige Punkte mit z-Wert = NaN.
    *          Um diese Punkte zu ignorieren, kann die folgende Bedingung geprüft werden: isnan(cloud.points[i].z)

    */
  // =================================================================================================================

  bool* mask_ptr = mask.ptr<bool>();

  std::vector<float> x_vec;
  std::vector<float> y_vec;
  std::vector<float> z_vec;

  Size s = mask.size();

//ROS_INFO_STREAM("Mask:	" << mask.size());
  int boarder = s.height * s.width;
  for (int i = 0; i < boarder; i++)
  {

// ROS_INFO_STREAM("x_point: " << cloud.points[i].x << " y_point:  " << cloud.points[i].y << " z_point:  " << cloud.points[i].x);
// ROS_INFO_STREAM("index: " << i << "	mask: " << mask_ptr[i]);
    if (mask_ptr[i])
    {
// ROS_INFO_STREAM("mask: " << mask_ptr[i]);
// ROS_INFO_STREAM("true ");

      if (!isnan(cloud.points[i].x))
      {
        x_vec.push_back(cloud.points[i].x);
      }
      if (!isnan(cloud.points[i].y))
      {
        y_vec.push_back(cloud.points[i].y);
      }
      if (!isnan(cloud.points[i].z))
      {
        z_vec.push_back(cloud.points[i].z);
      }
    }
  }

  float x_median;
  float y_median;
  float z_median;

  std::sort(x_vec.begin(), x_vec.end());
  std::sort(y_vec.begin(), y_vec.end());
  std::sort(z_vec.begin(), z_vec.end());

  int x_size = x_vec.size();
  int y_size = y_vec.size();
  int z_size = z_vec.size();

  if(x_size != 0)
  {
    if(x_size % 2 == 0)
    {
      x_median = (x_vec[x_size/2-1] + x_vec[x_size/2]) / 2;
    }
    else
    {
      x_median = x_vec[x_size/2];
    }
  }
  else
  {
    x_median = std::numeric_limits<float>::quiet_NaN();
  }

  if(y_size != 0)
  {
    if(y_size % 2 == 0)
    {
      y_median = (y_vec[y_size/2-1] + y_vec[y_size/2]) / 2;
    }
    else
    {
      y_median = y_vec[y_size/2];
    }
  }
  else
  {
    y_median = std::numeric_limits<float>::quiet_NaN();
  }

  if(z_size != 0)
  {
    if(z_size % 2 == 0)
    {
      z_median = (z_vec[z_size/2-1] + z_vec[z_size/2]) / 2;
    }
    else
    {
      z_median = z_vec[z_size/2];
    }
  }
  else
  {
    z_median = std::numeric_limits<float>::quiet_NaN();
  }

// ROS_INFO_STREAM("x_vec: " << x_vec.size() << " y_vec:  " << y_vec.size() << " z_vec:  " << z_vec.size());


  ObjectProperties OP_bbox;
  OP_bbox.center.x = x_median;
  OP_bbox.center.y = y_median;
  OP_bbox.center.z = z_median;

  return  OP_bbox;
}

//########## DRAW BOUNDING BOX #########################################################################################
cv::Mat ServiceAreaDetection::drawBoundingBox(ObjectProperties properties, cv::Mat &image)
{
  // =========== Aufgabe 5 ===========================================================================================

  /* Die Bounding-Box des detektierten Objekts soll in das Farbild (image) eingezeichnet werden. Das Bild mit
     * eingezeichneter Bounding-Box soll zurückgegeben werden. Das Ausgangsbild soll die gleiche Größe und Dimension
     * wie das Eingangsbild haben.
     *
     * ==> Projizieren Sie die Bounding-Box (aus properties) in das Farbbild (image). Zeichnen dann Sie eine
     *     2D-Bounding-Box in das Farbbild ein und geben dieses als Rückgabewert zurück
     */

  // =========== Hinweise ============================================================================================

  /*
     * Links:
     *   http://wiki.ros.org/image_geometry/Tutorials/ProjectTfFrameToImage
     *   http://docs.opencv.org/2.4/modules/core/doc/drawing_functions.html
     *
     */
  // =================================================================================================================

  // Mittelpunkt
  cv::Point3d pt_cv(properties.center.x, properties.center.y, properties.center.z);

  uv = camera_model_.project3dToPixel(pt_cv);
  cv::circle(image, uv, 3, CV_RGB(0,0,0), -1);

  //    // 8 Boxpunkte
  //    cv::Point3d point1_3d(properties.bounding_box_min_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_min_corner.z);
  //    cv::Point2d point1;
  //    point1 = camera_model_.project3dToPixel(point1_3d);

  //    cv::Point3d point2_3d(properties.bounding_box_min_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_min_corner.z);
  //    cv::Point2d point2;
  //    point2 = camera_model_.project3dToPixel(point2_3d);

  //    cv::Point3d point3_3d(properties.bounding_box_min_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_max_corner.z);
  //    cv::Point2d point3;
  //    point3 = camera_model_.project3dToPixel(point3_3d);

  //    cv::Point3d point4_3d(properties.bounding_box_min_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_max_corner.z);
  //    cv::Point2d point4;
  //    point4 = camera_model_.project3dToPixel(point4_3d);

  //    cv::Point3d point5_3d(properties.bounding_box_max_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_min_corner.z);
  //    cv::Point2d point5;
  //    point5 = camera_model_.project3dToPixel(point5_3d);

  //    cv::Point3d point6_3d(properties.bounding_box_max_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_max_corner.z);
  //    cv::Point2d point6;
  //    point6 = camera_model_.project3dToPixel(point6_3d);

  //    cv::Point3d point7_3d(properties.bounding_box_max_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_min_corner.z);
  //    cv::Point2d point7;
  //    point7 = camera_model_.project3dToPixel(point7_3d);

  //    cv::Point3d point8_3d(properties.bounding_box_max_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_max_corner.z);
  //    cv::Point2d point8;
  //    point8 = camera_model_.project3dToPixel(point8_3d);

  //    // Polylinien für die Box zusammengesetzt aus den Boxpunkten
  //    vector<Point> points_a;
  //    points_a.push_back(point1);
  //    points_a.push_back(point2);
  //    points_a.push_back(point3);
  //    points_a.push_back(point4);
  //    cv::polylines(image, points_a, 3, Scalar(0, 0, 0));

  //    vector<Point> points_b;
  //    points_b.push_back(point3);
  //    points_b.push_back(point4);
  //    points_b.push_back(point8);
  //    points_b.push_back(point6);
  //    cv::polylines(image, points_b, 3, Scalar(0, 0, 0));

  //    vector<Point> points_c;

  //    points_c.push_back(point5);
  //    points_c.push_back(point6);
  //    points_c.push_back(point8);
  //    points_c.push_back(point7);
  //    cv::polylines(image, points_c, 3, Scalar(0, 0, 0));

  //    vector<Point> points_d;
  //    points_d.push_back(point1);
  //    points_d.push_back(point2);
  //    points_d.push_back(point5);
  //    points_d.push_back(point7);
  //    cv::polylines(image, points_d, 3, Scalar(0, 0, 0));

  // 4 Boxpunkte
  cv::Point3d point1_3d(properties.bounding_box_min_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_min_corner.z);
  cv::Point2d point1;
  point1 = camera_model_.project3dToPixel(point1_3d);

  cv::Point3d point2_3d(properties.bounding_box_min_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_min_corner.z);
  cv::Point2d point2;
  point2 = camera_model_.project3dToPixel(point2_3d);

  cv::Point3d point3_3d(properties.bounding_box_max_corner.x, properties.bounding_box_max_corner.y, properties.bounding_box_min_corner.z);
  cv::Point2d point3;
  point3 = camera_model_.project3dToPixel(point3_3d);

  cv::Point3d point4_3d(properties.bounding_box_max_corner.x, properties.bounding_box_min_corner.y, properties.bounding_box_min_corner.z);
  cv::Point2d point4;
  point4 = camera_model_.project3dToPixel(point4_3d);

  // Polylinien für die Box zusammengesetzt aus den Boxpunkten
  vector<Point> points_a;
  points_a.push_back(point1);
  points_a.push_back(point2);
  points_a.push_back(point3);
  points_a.push_back(point4);
  cv::polylines(image, points_a, 3, Scalar(0, 0, 0));

  cv_bridge::CvImage img_bridge;
  sensor_msgs::Image img_msg;

  std_msgs::Header header; // empty header
  header.stamp = ros::Time::now(); // time
  img_bridge = cv_bridge::CvImage(header, sensor_msgs::image_encodings::RGB8, image);
  img_bridge.toImageMsg(img_msg); // from cv_bridge to sensor_msgs::Image
  image_pub_result_.publish(img_msg); // ros::Publisher pub_img = node.advertise<sensor_msgs::Image>("topic", queuesize);

  //        imshow("Bounding Box und Mittelpunkt", image);
  //        cv::waitKey(1);

  return image;
}

//########## PUBLISH OBJECT POSE #######################################################################################
void ServiceAreaDetection::publishObjectPose(cv::Point3d position, std_msgs::Header header)
{
  geometry_msgs::PoseStamped pose_msg;
  pose_msg.header = header;
  pose_msg.header.stamp = ros::Time::now();
  pose_msg.pose.position.x = position.x;
  pose_msg.pose.position.y = position.y;
  pose_msg.pose.position.z = position.z;
  pose_msg.pose.orientation.w = 1;

  object_pub_.publish(pose_msg);
}

//########## TRANSFORM TO RGB FRAME ####################################################################################
ObjectProperties ServiceAreaDetection::transformProperties(ObjectProperties properties, std_msgs::Header pointcloud_header)
{
  tf::StampedTransform transform;
  // camera_model_.tfFrame()

  try
  {
    tf_listener_.waitForTransform("/base_link", pointcloud_header.frame_id,
                                  ros::Time(0), ros::Duration(0.1));
    tf_listener_.lookupTransform("/base_link", pointcloud_header.frame_id,
                                 ros::Time(0), transform);
  }
  catch(tf::TransformException& ex)
  {
    ROS_WARN("TF exception:\n%s", ex.what());
    return properties;
  }

  ObjectProperties transformed_props;

  tf::Vector3 center;
  center.setX(properties.center.x);
  center.setY(properties.center.y);
  center.setZ(properties.center.z);

  if(object_detected == true)
  {
    tf::Vector3 bbmin;
    bbmin.setX(properties.bounding_box_min_corner.x);
    bbmin.setY(properties.bounding_box_min_corner.y);
    bbmin.setZ(properties.bounding_box_min_corner.z);

    tf::Vector3 bbmax;
    bbmax.setX(properties.bounding_box_max_corner.x);
    bbmax.setY(properties.bounding_box_max_corner.y);
    bbmax.setZ(properties.bounding_box_max_corner.z);
    bbmin = transform(bbmin);
    bbmax = transform(bbmax);
    transformed_props.bounding_box_min_corner.x = bbmin.x();
    transformed_props.bounding_box_min_corner.y = bbmin.y();
    transformed_props.bounding_box_min_corner.z = bbmin.z();
    transformed_props.bounding_box_max_corner.x = bbmax.x();
    transformed_props.bounding_box_max_corner.y = bbmax.y();
    transformed_props.bounding_box_max_corner.z = bbmax.z();
  }

  center = transform(center);
  transformed_props.center.x = center.x();
  transformed_props.center.y = center.y();
  transformed_props.center.z = center.z();

  return transformed_props;
}

//########## PUBLISH DEBUG IMAGE #######################################################################################
void ServiceAreaDetection::publishDebugImage(cv::Mat &image)
{
  // convert image to image message and publish
  sensor_msgs::Image msg;
  msg.width = image.cols;
  msg.height = image.rows;
  msg.step = image.cols * 3;
  msg.data.assign(image.data, image.data + image.cols*image.rows*image.channels());
  msg.encoding = sensor_msgs::image_encodings::RGB8;
  image_pub_.publish(msg);
}

//########## DYNAMIC RECONFIGURE CALLBACK ##############################################################################
void ServiceAreaDetection::dynamicReconfigureCallback(service_area_detection::ServiceAreaDetectionConfig &config, uint32_t level)
{
  // === Params for blob detection ===
  min_blob_size_ = config.blob_min_size * config.blob_min_size; // square to get logarithmic scale for slider element
  max_blob_size_ = config.blob_max_size * config.blob_max_size; // square to get logarithmic scale for slider element

  morph_kernel_1_ = cv::getStructuringElement(cv::MORPH_RECT,
                                              cv::Size(2 * config.morph_kernel_size_1 + 1,
                                                       2 * config.morph_kernel_size_1 + 1),
                                              cv::Point(config.morph_kernel_size_1, config.morph_kernel_size_1));
  morph_kernel_2_ = cv::getStructuringElement(cv::MORPH_RECT,
                                              cv::Size(2 * config.morph_kernel_size_2 + 1,
                                                       2 * config.morph_kernel_size_2 + 1),
                                              cv::Point(config.morph_kernel_size_2, config.morph_kernel_size_2));
  morph_kernel_3_ = cv::getStructuringElement(cv::MORPH_RECT,
                                              cv::Size(2 * config.morph_kernel_size_3 + 1,
                                                       2 * config.morph_kernel_size_3 + 1),
                                              cv::Point(config.morph_kernel_size_3, config.morph_kernel_size_3));

  //      h_min_ = config.color_filter_h_min;
  //      h_max_ = config.color_filter_h_max;
  //      s_min_ = config.color_filter_s_min;
  //      s_max_ = config.color_filter_s_max;
  //      v_min_ = config.color_filter_v_min;
  //      v_max_ = config.color_filter_v_max;
}

//########## MAIN ######################################################################################################
int main(int argc, char** argv)
{
  ros::init(argc, argv, "service_area_detection_node");

  ros::NodeHandle node_handle;
  ServiceAreaDetection service_area_detection(node_handle);

  ROS_INFO("Node is spinning ...");
  ros::spin();

  return 0;
}
