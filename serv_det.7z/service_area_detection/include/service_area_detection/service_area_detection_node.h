/* *****************************************************************
 *
 * object_detection
 *
 * Copyright (c) %YEAR%,
 * Institute of Mechatronic Systems,
 * Leibniz Universitaet Hannover.
 * (BSD License)
 * All rights reserved.
 *
 * http://www.imes.uni-hannover.de
 *
 * This software is distributed WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE.
 *
 * For further information see http://www.linfo.org/bsdlicense.html
 *
 ******************************************************************/

/**
 * @file   %FILENAME%
 * @author %USER% (%$EMAIL%)
 * @date   %DATE%
 *
 * @brief  Filedescription
 */

#ifndef SERVICE_AREA_DETECTION_SERVICE_AREA_DETECTION_H
#define SERVICE_AREA_DETECTION_SERVICE_AREA_DETECTION_H

#include "ros/ros.h"
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <opencv2/opencv.hpp>
#include <image_transport/image_transport.h>
#include <sensor_msgs/image_encodings.h>
#include <dynamic_reconfigure/server.h>
#include <service_area_detection/ServiceAreaDetectionConfig.h>
#include <geometry_msgs/PoseArray.h>
#include <std_srvs/Empty.h>
#include <geometry_msgs/PoseStamped.h>
#include <image_geometry/pinhole_camera_model.h>
#include <tf/transform_listener.h>
#include <std_srvs/SetBool.h>
#include "cv_bridge/cv_bridge.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
//#include "luh_youbot_controller_api/controller_api.h"


struct ObjectProperties
{
    // object center in 3D camera coordinates
    cv::Point3d center;

    // bounding box in 3D camera coordinates
    cv::Point3d bounding_box_min_corner;
    cv::Point3d bounding_box_max_corner;
};

class ServiceAreaDetection
{
public:
    ServiceAreaDetection(ros::NodeHandle &node_handle);
    ~ServiceAreaDetection();

private:

    // ROS
    ros::NodeHandle *node_;
    ros::Subscriber point_cloud_sub_;        
    ros::Publisher object_pub_;
    image_transport::ImageTransport it_;
    image_transport::Publisher image_pub_;
    image_transport::Publisher image_pub_result_;
    image_transport::Publisher image_pub_blob_mask_;
    image_transport::Subscriber image_sub_;
    ros::Subscriber camera_sub_;
    ros::ServiceServer trigger_;
    dynamic_reconfigure::Server<service_area_detection::ServiceAreaDetectionConfig> dyn_reconf_server_;
    tf::TransformListener tf_listener_;
    bool object_detected;
    //int index_closest;
    //double closest_distance;

    //std::vector<ObjectProperties> objects;

    // camera/image
    image_geometry::PinholeCameraModel camera_model_;

    //youbot_api
    cv::Mat rgb_img;
    cv::Mat maske;
    cv::Mat hsvsimage;

    cv::Mat debug_image;



    // Parameters
    cv::Mat morph_kernel_1_;
    cv::Mat morph_kernel_2_;
    cv::Mat morph_kernel_3_;
    int min_blob_size_;
    int max_blob_size_;
    float radius_limit;
    int h_min_, h_max_, s_min_, s_max_, v_min_, v_max_;
    bool m_brelevant_;
    cv::Point2d uv;

    bool serviceTrigger(std_srvs::SetBool::Request &req, std_srvs::SetBool::Response &res);
    void allFunctions();
    void pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr& input);
    void imageCallback(const sensor_msgs::ImageConstPtr& image_msg);
    void cameraCallback(const sensor_msgs::CameraInfoConstPtr& info_msg);
    cv::Mat createObjectMask(pcl::PointCloud<pcl::PointXYZRGB> &cloud);
    cv::Mat filterObjectMask(cv::Mat &mask);
    void clearBorder(cv::Mat &mask);
    cv::Mat selectBlob(cv::Mat &mask);
    ObjectProperties getObjectProperties(pcl::PointCloud<pcl::PointXYZRGB> &cloud, cv::Mat &mask);
    void publishObjectPose(cv::Point3d position, std_msgs::Header header);
    cv::Mat drawBoundingBox(ObjectProperties properties, cv::Mat &image);
    void publishDebugImage(cv::Mat &image);
    void dynamicReconfigureCallback(service_area_detection::ServiceAreaDetectionConfig &config, uint32_t level);
    ObjectProperties transformProperties(ObjectProperties properties, std_msgs::Header pointcloud_header);
};

#endif // OBJECT_DETECTION_OBJECT_DETECTION_H

