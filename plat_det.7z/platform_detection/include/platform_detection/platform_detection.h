/* *****************************************************************
 *
 * laser_scan
 *
 * Copyright (c) %YEAR%,
 * Institute of Mechatronic Systems,
 * Leibniz Universitaet Hannover.
 * (BSD License)
 * All rights reserved.
 *
 * http://www.imes.uni-hannover.de
 *
 * This software is distributed WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE.
 *
 * For further information see http://www.linfo.org/bsdlicense.html
 *
 ******************************************************************/

/**
 * @file   %FILENAME%
 * @author %USER% (%$EMAIL%)
 * @date   %DATE%
 *
 * @brief  Filedescription
 */

#ifndef PLATFORM_DETECTION_PLATFORM_DETECTION_H
#define PLATFORM_DETECTION_PLATFORM_DETECTION_H

#include "ros/ros.h"
#include "std_msgs/Float32MultiArray.h"
#include "std_srvs/Empty.h"
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/PoseArray.h>
#include <vector>
#include <algorithm>


class PlatformDetectionNode
{
public:
    PlatformDetectionNode(ros::NodeHandle &node_handle);

private:
    // node handle
    ros::NodeHandle *node_;

    // ros communication
    ros::Subscriber subscriber_laserscan_front_;
    ros::Subscriber subscriber_laserscan_back_;

    ros::Publisher publisher_PlatformDetection_front_;
    ros::Publisher publisher_PlatformDetection_back_;

;

    // callbacks
    void subscriberCallback_Front(const sensor_msgs::LaserScan &msg);
    void subscriberCallback_Back(const sensor_msgs::LaserScan &msg);
};

#endif // PLATFORM_DETECTION_PLATFORM_DETECTION_H
