/* *****************************************************************
 *
 * laser_scan
 *
 * Copyright (c) %YEAR%,
 * Institute of Mechatronic Systems,
 * Leibniz Universitaet Hannover.
 * (BSD License)
 * All rights reserved.
 *
 * http://www.imes.uni-hannover.de
 *
 * This software is distributed WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE.
 *
 * For further information see http://www.linfo.org/bsdlicense.html
 *
 ******************************************************************/

/**
 * @file   %FILENAME%
 * @author %USER% (%$EMAIL%)
 * @date   %DATE%
 *
 * @brief  Filedescription
 */

#include "platform_detection/platform_detection.h"
#include "math.h"
#include "tf/transform_listener.h"
#include "stdio.h"


//############################################################################################################################
//####################################################### CONSTRUCTOR ########################################################
//############################################################################################################################
/*
 * output="screen" launchfile auskommentiert
 * /scan      -> laser_scan_node (subcriber)
 * /scan_back -> laser_scan_node (subcriber)
 *               laser_scan_node (publisher) -> PlatformDetection/front
 *               laser_scan_node (publisher) -> PlatformDetection/back
*/
//############################################################################################################################
//############################################################################################################################
//############################################################################################################################
PlatformDetectionNode::PlatformDetectionNode(ros::NodeHandle &node_handle):
    node_(&node_handle)
{



    // === SUBSCRIBERS ===
    subscriber_laserscan_front_ = node_->subscribe("scan", 10, &PlatformDetectionNode::subscriberCallback_Front, this);
    subscriber_laserscan_back_ = node_->subscribe("scan_back", 10, &PlatformDetectionNode::subscriberCallback_Back, this);

    // === PUBLISHERS ===
    publisher_PlatformDetection_front_ = node_->advertise<geometry_msgs::PoseArray>("/platform_detection/front", 10);
    publisher_PlatformDetection_back_ = node_->advertise<geometry_msgs::PoseArray>("/platform_detection/back", 10);
}

//############################################################################################################################
//################################################ CALLBACK: SUBSCRIBER FRONT ################################################
//############################################################################################################################
/*
 * angle_min:       -1.8   rad ^ -103  deg
 * angle_max:        1.8   rad ^  103  deg
 * angle_increment:  0.006 rad ^  0.35 deg
 *
 *              Range [degree]     Radius [cm]     Index     Speed Factor
 * Sector 1     -103 -> -90           35          0 ->  37    factor[0]
 * Sector 2     -90  -> -48           30         38 -> 158    factor[1]
 * Sector 3     -48  ->  48           25        159 -> 433    factor[2]
 * Sector 4      48  ->  90           30        434 -> 554    factor[3]
 * Sector 5      90  ->  103          35        555 -> 587    factor[4]
 *
 *            0 deg
 *              ^
 *              |
 *              |
 * 90 deg <-----------> -90 deg
 */
//############################################################################################################################
//############################################################################################################################
//############################################################################################################################
void PlatformDetectionNode::subscriberCallback_Front(const sensor_msgs::LaserScan &msg)
{
    unsigned int i;
    unsigned int num;

    num = msg.ranges.size();// Number of readings num = 588


    //ROS_INFO("Number of readings: %d",num);

    /*****************************************************************************************/
    /************************************** Derivation ***************************************/
    /*****************************************************************************************/ //Idee:Die Ableitung der Abstände die auf die Plattform treffen müsste eine bestimmt Form haben, sobald wir parallel zur Plattform
    double fArray_derivation[num];
    unsigned int iBeginPlatformIncrement;
    unsigned int iEndPlatformIncrement;
    double iThreshold = 0.1;
    bool bInCylinder = false;
    bool foundPlatform = false;

    for (unsigned int j = 1; j < (num - 1); j++)
    {
        if ((msg.ranges[j-1] > 0.019999999553 && msg.ranges[j-1] < 5.59999990463) && (msg.ranges[j+1] > 0.019999999553 && msg.ranges[j+1] < 5.59999990463))
           fArray_derivation[j] = (msg.ranges[j+1] - msg.ranges[j-1]) / 2;

           if (fArray_derivation[j] < -iThreshold)
           {
               iBeginPlatformIncrement = j;
               bInCylinder = true;

           }
           if (fArray_derivation[j] > iThreshold & bInCylinder == true)
           {
               iEndPlatformIncrement = j;
               bInCylinder = false;
               foundPlatform = true;

           }
    }
    if(foundPlatform){

    /*****************************************************************************************/
    /********************************* Platform detection  ***********************************/
    /*****************************************************************************************/


    //ROS_INFO("Index Begin %d Ende %d",iBeginPlatformIncrement,iEndPlatformIncrement);

    /*****************************************************************************************/
    /******************************* Angle(Theta) to platform ********************************/
    /*****************************************************************************************/ //Nur sinvoll wenn Roboter in X-Richtung mittig vor der Plattform stehe
    double iAnglePlatformLeftSide;
    double iAnglePlatformRightSide;

    double const iStartAngleBotFront = -1.80396139622;
    double const iEndAngleBotFront = 1.79782545567;
    double const iIncrementAngle = 0.00613592332229;



    iAnglePlatformRightSide = (iBeginPlatformIncrement * iIncrementAngle) + iStartAngleBotFront; // + weil iStartAngleBotFront schon negativ ist
    iAnglePlatformLeftSide = (iEndPlatformIncrement * iIncrementAngle) + iStartAngleBotFront;

    //ROS_INFO("Winkel Platformbegin %f Winkel Platformende %f",iAnglePlatformRightSideDegree,iAnglePlatformLeftSideDegree);
    /*****************************************************************************************/
    /********************************* X-Position to platform ********************************/
    /*****************************************************************************************/
    double iDistanceX;
    double BeginPlatform[2];
    double EndPlatform[2];

    BeginPlatform[0] = msg.ranges[iBeginPlatformIncrement] * cos(iAnglePlatformRightSide);
    EndPlatform[0] = msg.ranges[iEndPlatformIncrement] * cos(iAnglePlatformLeftSide);

    iDistanceX = (EndPlatform[0] + BeginPlatform[0]) / 2;
    //ROS_INFO("Abstand Mittelpunkt in X-Richtung %f",iDistanceX);

    /*****************************************************************************************/
    /********************************* Y-Position to platform ********************************/
    /*****************************************************************************************/

    double iDistanceY;

    BeginPlatform[1] = msg.ranges[iBeginPlatformIncrement] * sin(iAnglePlatformRightSide);
    EndPlatform[1] = msg.ranges[iEndPlatformIncrement] * sin(iAnglePlatformLeftSide);

    iDistanceY = (EndPlatform[1] + BeginPlatform[1]) / 2;
    //ROS_INFO("Abstand Mittelpunkt in Y-Richtung %f",iDistanceY);



    /*****************************************************************************************/
    /********************************* Scanner to Base KS  ********************************/
    /*****************************************************************************************/

    tf::Transform Mittelpunkt;
    tf::Transform BeginPlatform_Base;
    tf::Transform EndPlatform_Base;
    tf::Vector3 position;

    tf::Transform tf_laser_front;

    tf::Vector3 pos;
    tf::Quaternion q;
    pos.setX(0.309);
    pos.setY(0);
    pos.setZ(-0.03);

    q.setX(0);
    q.setY(0);
    q.setZ(0);
    q.setW(1);

    tf_laser_front.setOrigin(pos);
    tf_laser_front.setRotation(q);

    position.setX(iDistanceX);
    position.setY(iDistanceY);
    Mittelpunkt.setOrigin(position);
    Mittelpunkt.setRotation(q);
    tf::Transform new_tf = tf_laser_front * Mittelpunkt;

    position.setX(BeginPlatform[0]);
    position.setY(BeginPlatform[1]);
    BeginPlatform_Base.setOrigin(position);
    BeginPlatform_Base.setRotation(q);
    tf::Transform new_BeginPlatform = tf_laser_front * BeginPlatform_Base;

    position.setX(EndPlatform[0]);
    position.setY(EndPlatform[1]);
    EndPlatform_Base.setOrigin(position);
    EndPlatform_Base.setRotation(q);
    tf::Transform new_EndPlatform = tf_laser_front * EndPlatform_Base;


    //ROS_INFO_STREAM("X: " << new_tf.getOrigin().getX()<< " Y:" << new_tf.getOrigin().getY());

    /*****************************************************************************************/
    /************************************** Publisher  ***************************************/
    /*****************************************************************************************/
    geometry_msgs::PoseArray publish_msg_front;
    publish_msg_front.poses.resize(3);
    publish_msg_front.poses[0].position.x = new_tf.getOrigin().getX();
    publish_msg_front.poses[0].position.y = new_tf.getOrigin().getY();

    publish_msg_front.poses[1].position.x = new_BeginPlatform.getOrigin().getX();
    publish_msg_front.poses[1].position.y = new_BeginPlatform.getOrigin().getY();

    publish_msg_front.poses[2].position.x = new_EndPlatform.getOrigin().getX();
    publish_msg_front.poses[2].position.y = new_EndPlatform.getOrigin().getY();

    ROS_INFO("Abstand Beginn Platform in X-Richtung %f",new_BeginPlatform.getOrigin().getX());
    ROS_INFO("Abstand EndPlatform in X-Richtung %f",new_EndPlatform.getOrigin().getX());


    publisher_PlatformDetection_front_.publish(publish_msg_front);
    }
}











//############################################################################################################################
//################################################ CALLBACK: SUBSCRIBER BACK #################################################
//############################################################################################################################
/*
 * angle_min:       -1.8   rad ^ -103  deg
 * angle_max:        1.8   rad ^  103  deg
 * angle_increment:  0.006 rad ^  0.35 deg
 *
 *              Range [degree]     Radius [cm]     Index     Speed Factor
 * Sector 6     -103 -> -90           35          0 ->  37    factor[5]
 * Sector 7     -90  -> -48           30         38 -> 158    factor[6]
 * Sector 8     -48  ->  48           25        159 -> 433    factor[7]
 * Sector 9      48  ->  90           30        434 -> 554    factor[8]
 * Sector 10     90  ->  103          35        555 -> 587    factor[9]
 *
 *            0 deg
 *              ^
 *              |
 *              |
 * 90 deg <-----------> -90 deg
 */
//############################################################################################################################
//############################################################################################################################
//############################################################################################################################
void PlatformDetectionNode::subscriberCallback_Back(const sensor_msgs::LaserScan &msg)
{

    unsigned int i;
    unsigned int num;

    num = msg.ranges.size();// Number of readings num = 588


    //ROS_INFO("Number of readings: %d",num);

    /*****************************************************************************************/
    /************************************** Derivation ***************************************/
    /*****************************************************************************************/ //Idee:Die Ableitung der Abstände die auf die Plattform treffen müsste eine bestimmt Form haben, sobald wir parallel zur Plattform
    double fArray_derivation[num];
    unsigned int iBeginPlatformIncrement;
    unsigned int iEndPlatformIncrement;
    double iThreshold = 0.1;//stehen. Wenn das so ist könnten wir das evtl. zur Auswertung des Winkels heranziehen.
    bool bInCylinder = false;
    bool foundPlatform = false;

    for (unsigned int j = 1; j < (num - 1); j++)
    {
        if ((msg.ranges[j-1] > 0.019999999553 && msg.ranges[j-1] < 5.59999990463) && (msg.ranges[j+1] > 0.019999999553 && msg.ranges[j+1] < 5.59999990463))
           fArray_derivation[j] = (msg.ranges[j+1] - msg.ranges[j-1]) / 2;

           if (fArray_derivation[j] < -iThreshold)
           {
               iBeginPlatformIncrement = j;
               bInCylinder = true;

           }
           if (fArray_derivation[j] > iThreshold & bInCylinder == true)
           {
               iEndPlatformIncrement = j;
               bInCylinder = false;
               foundPlatform = true;

           }
    }
    if(foundPlatform){
    /*****************************************************************************************/
    /********************************* Platform detection  ***********************************/
    /*****************************************************************************************/


    //ROS_INFO("Index Begin %d Ende %d",iBeginPlatformIncrement,iEndPlatformIncrement);

    /*****************************************************************************************/
    /******************************* Angle(Theta) to platform ********************************/
    /*****************************************************************************************/ //Nur sinvoll wenn Roboter in X-Richtung mittig vor der Plattform stehe
    double iAnglePlatformLeftSide;
    double iAnglePlatformRightSide;

    double const iStartAngleBotFront = -1.80396139622;
    double const iIncrementAngle = 0.00613592332229;



    iAnglePlatformRightSide = (iBeginPlatformIncrement * iIncrementAngle) + iStartAngleBotFront; // + weil iStartAngleBotFront schon negativ ist
    iAnglePlatformLeftSide = (iEndPlatformIncrement * iIncrementAngle) + iStartAngleBotFront;

    //ROS_INFO("Winkel Platformbegin %f Winkel Platformende %f",iAnglePlatformRightSideDegree,iAnglePlatformLeftSideDegree);
    /*****************************************************************************************/
    /********************************* X-Position to platform ********************************/
    /*****************************************************************************************/
    float iDistanceX;
    double BeginPlatform[2];
    double EndPlatform[2];

    BeginPlatform[0] = msg.ranges[iBeginPlatformIncrement] * cos(iAnglePlatformRightSide);
    EndPlatform[0] = msg.ranges[iEndPlatformIncrement] * cos(iAnglePlatformLeftSide);

    iDistanceX = (EndPlatform[0] + BeginPlatform[0]) / 2;
    //ROS_INFO("Abstand Mittelpunkt_back in X-Richtung %f",iDistanceX);

    /*****************************************************************************************/
    /********************************* Y-Position to platform ********************************/
    /*****************************************************************************************/

    float iDistanceY;

    BeginPlatform[1] = msg.ranges[iBeginPlatformIncrement] * sin(iAnglePlatformRightSide);
    EndPlatform[1] = msg.ranges[iEndPlatformIncrement] * sin(iAnglePlatformLeftSide);

    iDistanceY = (EndPlatform[1] + BeginPlatform[1]) / 2;
    //ROS_INFO("Abstand Mittelpunkt_back in Y-Richtung %f",iDistanceY);




    /*****************************************************************************************/
    /********************************* Scanner to Base KS  ********************************/
    /*****************************************************************************************/

    tf::Transform Mittelpunkt;
    tf::Transform BeginPlatform_Base;
    tf::Transform EndPlatform_Base;
    tf::Vector3 position;

    tf::Transform tf_laser_back;

    tf::Vector3 pos;
    tf::Quaternion q;
    tf::Quaternion hinten;

    pos.setX(-0.309);
    pos.setY(0);
    pos.setZ(-0.03);

    q.setX(0);
    q.setY(0);
    q.setZ(1);
    q.setW(-1.0341e-13);

    hinten.setX(0);
    hinten.setY(0);
    hinten.setZ(0);
    hinten.setW(1);

    tf_laser_back.setOrigin(pos);
    tf_laser_back.setRotation(q);

    position.setX(iDistanceX);
    position.setY(iDistanceY);


    Mittelpunkt.setOrigin(position);
    Mittelpunkt.setRotation(hinten);
    tf::Transform new_tf = tf_laser_back * Mittelpunkt;

    position.setX(BeginPlatform[0]);
    position.setY(BeginPlatform[1]);
    BeginPlatform_Base.setOrigin(position);
    BeginPlatform_Base.setRotation(hinten);
    tf::Transform new_BeginPlatform = tf_laser_back * BeginPlatform_Base;

    position.setX(EndPlatform[0]);
    position.setY(EndPlatform[1]);
    EndPlatform_Base.setOrigin(position);
    EndPlatform_Base.setRotation(hinten);
    tf::Transform new_EndPlatform = tf_laser_back * EndPlatform_Base;

    //ROS_INFO_STREAM("X: " << new_tf.getOrigin().getX()<< " Y:" << new_tf.getOrigin().getY());

    /*****************************************************************************************/
    /************************************** Publisher  ***************************************/
    /*****************************************************************************************/
    geometry_msgs::PoseArray publish_msg_back;
    publish_msg_back.poses.resize(3);
    publish_msg_back.poses[0].position.x = new_tf.getOrigin().getX();
    publish_msg_back.poses[0].position.y = new_tf.getOrigin().getY();

    publish_msg_back.poses[1].position.x = new_BeginPlatform.getOrigin().getX();
    publish_msg_back.poses[1].position.y = new_BeginPlatform.getOrigin().getY();

    publish_msg_back.poses[2].position.x = new_EndPlatform.getOrigin().getX();
    publish_msg_back.poses[2].position.y = new_EndPlatform.getOrigin().getY();

    ROS_INFO("Abstand Beginn Platform hinten in X-Richtung %f",new_BeginPlatform.getOrigin().getX());
    ROS_INFO("Abstand EndPlatform hinten in X-Richtung %f",new_EndPlatform.getOrigin().getX());

    publisher_PlatformDetection_back_.publish(publish_msg_back);


  }
}


//############################################################################################################################
//########################################################## MAIN ############################################################
//############################################################################################################################
int main(int argc, char** argv)
{
    ros::init(argc, argv, "platform_detection");

    ros::NodeHandle node_handle;
    PlatformDetectionNode platform_detection(node_handle);

    ROS_INFO("Node is spinning...");
    ros::spin();

    return 0;
}
