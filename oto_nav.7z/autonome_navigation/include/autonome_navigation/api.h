#ifndef API_H
#define API_H

// cpp
#include <iostream>
#include <stdio.h>
#include <string>
#include <yaml-cpp/yaml.h>
#include <fstream>

// ros
#include <ros/ros.h>
#include <ros/package.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <nav_msgs/GetPlan.h>
#include <nav_msgs/Path.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <tf/transform_listener.h>

// autonom_navigation
#include <autonome_navigation/PositionService.h>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

// Funktionen
bool fexists(const std::string& filename);

// Callbacks
void currentPoseCb(const geometry_msgs::PoseWithCovarianceStamped &msg);

// global variables
geometry_msgs::Pose currentPose_;


class navigation_api
{
public:
  navigation_api();
  navigation_api(ros::NodeHandle &node_handle);
  ~navigation_api();

  // Funktionen
  bool nextPyramide();
  bool savePyramide(double y);
  void deleteNextPyramide();

  bool nextTray(std::vector<std::string> cargoInhalt, std::string& current_target);
  bool saveTray(double y, std::string color);

  bool nextHiddenTray();
  void deleteNextHiddenTray();

  bool moveToPose(std::string position_name, std::string file_name);
  bool moveToPose(std::string position_name, std::string file_name, std::string& current_target);

  bool savePose(std::string position_name, std::string file_name);
  bool savePoseRelativeToBase(double relative_y, std::string position_name, std::string file_name);
  bool removePose(std::string position_name, std::string file_name);


private:

  // ROS
  ros::NodeHandle *node_;

  ros::ServiceClient drive_to_client_;
  ros::ServiceClient save_pose_client_;
  ros::ServiceClient save_pose_relative_client_;
  ros::ServiceClient remove_pose_client_;
  ros::ServiceClient get_costmap_client_;
  ros::ServiceClient get_next_target_;

  // move_base
  MoveBaseClient *action_client_;



  // Variablen
  int counter_pyramide_;

  // Parameters
  std::string pyramide_name_;
  std::string tray_name_;
  std::string hidden_tray_name_;


  //Funktionen

  std::string getClosest(std::string file_name, std::vector<std::string> filter);
};

#endif // API_H
