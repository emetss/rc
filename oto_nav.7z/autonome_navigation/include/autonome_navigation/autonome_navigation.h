#ifndef AUTONOME_NAVIGATION_H
#define AUTONOME_NAVIGATION_H

// c++
#include<stdio.h>
#include <yaml-cpp/yaml.h>
#include <fstream>


// ros
#include <ros/ros.h>
#include <ros/package.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <nav_msgs/GetPlan.h>
#include <nav_msgs/Path.h>
#include <std_srvs/Empty.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/server/simple_action_server.h>

// own files
#include <autonome_navigation/PositionService.h>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

// ros communication
ros::Subscriber current_position_sub_;
ros::Publisher set_goal_pub_;
ros::ServiceServer position_server_;
ros::ServiceServer closest_target_server_;
ros::ServiceClient get_costmap_client_;
ros::ServiceClient clear_costmap_cient_;

// move_base
MoveBaseClient *action_client_;

// global variables
std::string path_;
geometry_msgs::Pose currentPose_;

// param
std::string file_name_;


// callbacks
bool getTargetService(autonome_navigation::PositionService::Request  &req,
         autonome_navigation::PositionService::Response &res);

bool getClosestTarget(autonome_navigation::PositionService::Request  &req,
         autonome_navigation::PositionService::Response &res);

void currentPoseCb(const geometry_msgs::PoseWithCovarianceStamped &msg);

#endif // AUTONOME_NAVIGATION_H
