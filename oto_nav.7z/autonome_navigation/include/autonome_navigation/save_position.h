#ifndef SAVE_POSITION_H
#define SAVE_POSITION_H

// c++
#include<stdio.h>
#include <yaml-cpp/yaml.h>
#include <fstream>

// ros
#include <ros/ros.h>
#include <ros/package.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/Pose.h>
#include <tf/transform_listener.h>

// own files
#include <autonome_navigation/PositionService.h>

// Callbacks
void currentPoseCb(const geometry_msgs::PoseWithCovarianceStamped &msg);
bool savePositionService(autonome_navigation::PositionService::Request  &req,
         autonome_navigation::PositionService::Response &res);
bool saveRelativePositionService(autonome_navigation::PositionService::Request  &req,
                         autonome_navigation::PositionService::Response &res);
bool removovePositionService(autonome_navigation::PositionService::Request  &req,
                             autonome_navigation::PositionService::Response &res);
bool cleanRunService(autonome_navigation::PositionService::Request  &req,
                           autonome_navigation::PositionService::Response &res);

// Ros Communication
ros::Subscriber current_position_sub_;
ros::ServiceServer position_server_;
ros::ServiceServer position_relative_server_;
ros::ServiceServer clean_server_;
ros::ServiceServer remove_server_;
tf::TransformListener *listener_;

// global Variables
geometry_msgs::Pose currentPose_;
std::string path_;

// param
std::string file_name_;

// functions
bool fexists(const std::string& filename);

#endif // SAVE_POSITION_H
