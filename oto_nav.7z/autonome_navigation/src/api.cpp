#include <autonome_navigation/api.h>


/*
 * in nextPyramide -> aus der SM kommt kein String. Fahre nächste Pyramide an. Egal ob groß oder klein
 *
 * in next Tray -> übergabe der Color, offset zum Tray berechnen zum anfahren
 *
 *
 */
navigation_api::navigation_api()
{

}
navigation_api::navigation_api(ros::NodeHandle &node_handle):
  node_(&node_handle)
{
  drive_to_client_ = node_->serviceClient<autonome_navigation::PositionService>("/autonome_navigation/move_to_position");
  save_pose_client_ = node_->serviceClient<autonome_navigation::PositionService>("/autonome_navigation/save_position");
  save_pose_relative_client_ =  node_->serviceClient<autonome_navigation::PositionService>("/autonome_navigation/save_position_relative_to_base");
  remove_pose_client_ = node_->serviceClient<autonome_navigation::PositionService>("/autonome_navigation/remove_position");
  get_next_target_ = node_->serviceClient<autonome_navigation::PositionService>("/autonome_navigation/get_closest_target");
  get_costmap_client_ = node_->serviceClient<nav_msgs::GetPlan>("/move_base/make_plan");

  counter_pyramide_ = 0;

  tray_name_ = "Tray.yaml";
  pyramide_name_ = "Pyramide.yaml";
  hidden_tray_name_ = "HiddenTray.yaml";

}
navigation_api::~navigation_api()
{

}

/*
 *  Funktionen
 *
 * */
bool fexists(const std::string& filename)
{
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

bool navigation_api::nextPyramide()
{
  // dummy string
  std::string pyramide_name;

  // Namen der nächsten  Pyramide mit getClosest
  pyramide_name = getClosest(pyramide_name_, std::vector<std::string>());

  if(pyramide_name == "")
  {
    ROS_INFO_STREAM("no piramide found");
    return false;
  }
  else
  {
    ROS_INFO_STREAM("try to move to pyramide " << pyramide_name);
    // ruft funktion moveToPose auf um zur nächsten Pose zu fahren
    std::string current_target;
    if(moveToPose(pyramide_name, pyramide_name_, current_target))
    {
      ROS_INFO_STREAM(current_target << " reached");
      return true;
    }
    else
    {
      ROS_INFO_STREAM("can't reach " << pyramide_name);
      return false;
    }
  }
}

bool navigation_api::nextTray(std::vector<std::string> cargoInhalt, std::string& current_target)
{
  // dummy string
  std::string tray_name;

  // den Namen des nächsten Trays mit getClosest bekommen
  tray_name = getClosest(tray_name_, cargoInhalt);

  if(tray_name == "")
  {
    //ROS_INFO_STREAM("no tray found");
    return false;
  }
  else
  {
    ROS_INFO_STREAM("try to move to tray " << tray_name);
    // ruft funktion moveToPose auf um zur nächsten Pose zu fahren
    if(moveToPose(tray_name, tray_name_, current_target))
    {
      ROS_INFO_STREAM(current_target << " reached");
      return true;
    }
    else
    {
      ROS_INFO_STREAM("can't reach " << tray_name);
      return false;
    }

  }

}

bool navigation_api::nextHiddenTray()
{
  // dummy string
  std::string hidden_tray_name;

  // Namen der nächsten  Pyramide mit getClosest
  hidden_tray_name = getClosest(hidden_tray_name_, std::vector<std::string>());

  if(hidden_tray_name == "")
  {
    ROS_INFO_STREAM("no piramide found");
    return false;
  }
  else
  {
    ROS_INFO_STREAM("try to move to pyramide " << hidden_tray_name);
    // ruft funktion moveToPose auf um zur nächsten Pose zu fahren
    std::string current_target;
    if(moveToPose(hidden_tray_name, hidden_tray_name_, current_target))
    {
      ROS_INFO_STREAM(current_target << " reached");
      return true;
    }
    else
    {
      ROS_INFO_STREAM("can't reach " << hidden_tray_name);
      return false;
    }
  }
}

bool navigation_api::savePyramide(double y)
{
  bool success = false;
  // Client savePosition Service

  // erstelle string stream um int in string zu konvertieren
  std::stringstream ss;
  ss << counter_pyramide_;

  // rufe Funktion savePose auf um werte zu speichern
  success = savePoseRelativeToBase(y, ss.str(), pyramide_name_);

  // counter für kleine pyramiden erhöhen
  counter_pyramide_++;

  return success;
}

void navigation_api::deleteNextPyramide()
{
  // dummy string
  std::string name;

  // löschen die nächste pyramide

  // Namen der nächsten kleinen Pyramide mit getClosest
  name = getClosest(pyramide_name_, std::vector<std::string>());

  // rufe Funktion remove Pose um eine kleine Pyramide zu löschen
  removePose(name, pyramide_name_);

}

void navigation_api::deleteNextHiddenTray()
{
  // dummy string
  std::string name;

  // löschen die nächste pyramide

  // Namen der nächsten kleinen Pyramide mit getClosest
  name = getClosest(hidden_tray_name_, std::vector<std::string>());

  // rufe Funktion remove Pose um eine kleine Pyramide zu löschen
  removePose(name, hidden_tray_name_);

}

bool navigation_api::saveTray(double y, std::string color)
{
  // ruft save Pose und gebt Ergebniss ob es erfolgreich war zurück
  return savePoseRelativeToBase(y, color, tray_name_);
}

bool navigation_api::moveToPose(std::string position_name, std::string file_name)
{
  ROS_INFO("in move to pose");
  // service call move
  autonome_navigation::PositionService srv;

  // erwartet den namen der Pose und den Namen der Datei in autonom_navigation/poses
  srv.request.position_name = position_name;
  srv.request.file_name = file_name;

  // ruft Client auf um zur Pose zur fahren
  drive_to_client_.call(srv);

  ROS_INFO("reached");

  // gibt das Ergebniss ob es erfolgreich war zurück
  return srv.response.sucess;

}

bool navigation_api::moveToPose(std::string position_name, std::string file_name, std::string& current_target)
{
  ROS_INFO("in move to pose");
  // service call move
  autonome_navigation::PositionService srv;

  // erwartet den namen der Pose und den Namen der Datei in autonom_navigation/poses
  srv.request.position_name = position_name;
  srv.request.file_name = file_name;

  // ruft Client auf um zur Pose zur fahren
  drive_to_client_.call(srv);

  ROS_INFO("reached");

  // setzt current target
  current_target = srv.response.next_target;

  // gibt das Ergebniss ob es erfolgreich war zurück
  return srv.response.sucess;
}

bool navigation_api::savePose(std::string position_name, std::string file_name)
{

  // service call move
  autonome_navigation::PositionService srv;

  // erwartet den namen der Pose und den Namen der Datei in autonom_navigation/poses
  srv.request.position_name = position_name;
  srv.request.file_name = file_name;

  // ruft Client auf um pose zu speichern
  save_pose_client_.call(srv);

  // gibt das Ergebniss ob es erfolgreich war zurück
  return srv.response.sucess;

}

bool navigation_api::savePoseRelativeToBase(double relative_y, std::string position_name, std::string file_name)
{
  // service call move
  autonome_navigation::PositionService srv;

  // erwartet den namen der Pose und den Namen der Datei in autonom_navigation/poses
  srv.request.position_name = position_name;
  srv.request.file_name = file_name;
  srv.request.relative_y = relative_y;

  // ruft Client auf um pose zu speichern
  save_pose_relative_client_.call(srv);

  // gibt das Ergebniss ob es erfolgreich war zurück
  return srv.response.sucess;
}

bool navigation_api::removePose(std::string position_name, std::string file_name)
{

  // service call move
  autonome_navigation::PositionService srv;

  // erwartet den namen der Pose und den Namen der Datei in autonom_navigation/poses
  srv.request.position_name = position_name;
  srv.request.file_name = file_name;

  // ruft Client auf um pose zu löschen
  remove_pose_client_.call(srv);

  // gibt das Ergebniss ob es erfolgreich war zurück
  return srv.response.sucess;

}

std::string navigation_api::getClosest(std::string file_name, std::vector<std::string> filter)
{

  autonome_navigation::PositionService srv;
  srv.request.file_name = file_name;
  srv.request.filter = filter;

  get_next_target_.call(srv);

  std::string next_target;

  next_target = srv.response.next_target;

  return next_target;

}
