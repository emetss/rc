#include <autonome_navigation/save_position.h>


// function to check if a file already exists
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

// ServiceServer to save position in positions.yaml

// Einfügen von mehreren Positionsdateien
// Tray oder Pyrmaide
// Farbe Tray und Größe Pyramide
//

bool savePositionService(autonome_navigation::PositionService::Request  &req,
                         autonome_navigation::PositionService::Response &res)
{
  std::string new_pose_name = req.position_name;
  std::string file_path;
  std::string file_name = req.file_name;

  YAML::Node node;

  // check if req has filename

  if(!(file_name == ""))
  {
    file_path = ros::package::getPath("autonome_navigation").c_str();
    file_path.append("/poses/");
    file_path.append(req.file_name);
  }
  else
  {
    file_path = path_;
  }

  // check if position.yaml already exists
  if(fexists(file_path))
  {
    node = YAML::LoadFile(file_path);  // starts out as null
  }

  ROS_INFO_STREAM("opened :"  << file_path);

  // check if position in positions.yaml already exists
  // if yes overwrite old positions
  // if not create new position

  if(node[new_pose_name])
  {
    node[new_pose_name][0] = currentPose_.position.x;  // node["seq"] automatically becomes a sequence
    node[new_pose_name][1] = currentPose_.position.y;
    node[new_pose_name][2] = currentPose_.position.z;
    node[new_pose_name][3] = currentPose_.orientation.x;
    node[new_pose_name][4] = currentPose_.orientation.y;
    node[new_pose_name][5] = currentPose_.orientation.z;
    node[new_pose_name][6] = currentPose_.orientation.w;
  }
  else{
    node[new_pose_name].push_back(currentPose_.position.x);  // node["seq"] automatically becomes a sequence
    node[new_pose_name].push_back(currentPose_.position.y);
    node[new_pose_name].push_back(currentPose_.position.z);
    node[new_pose_name].push_back(currentPose_.orientation.x);
    node[new_pose_name].push_back(currentPose_.orientation.y);
    node[new_pose_name].push_back(currentPose_.orientation.z);
    node[new_pose_name].push_back(currentPose_.orientation.w);
  }

  ROS_INFO_STREAM(node[new_pose_name]);

  std::ofstream fout(file_path.c_str());
  fout << node;

  std::string info;
  info = "Saved to: ";
  info.append(file_path);

  res.information = info;
  res.sucess = true;
}

bool saveRelativePositionService(autonome_navigation::PositionService::Request  &req,
                         autonome_navigation::PositionService::Response &res)
{
  std::string new_pose_name = req.position_name;
  std::string file_path;
  std::string file_name = req.file_name;

  YAML::Node node;

  // check if req has filename

  if(!(file_name == ""))
  {
    file_path = ros::package::getPath("autonome_navigation").c_str();
    file_path.append("/poses/");
    file_path.append(req.file_name);
  }
  else
  {
    file_path = path_;
  }

  // check if position.yaml already exists
  if(fexists(file_path))
  {
    node = YAML::LoadFile(file_path);  // starts out as null
  }

  ROS_INFO_STREAM("opened :"  << file_path);

  // calculate pose one the map
  // ##########################

  geometry_msgs::PoseStamped base_pose;

  base_pose.header.frame_id = "base_link";
  base_pose.header.stamp = ros::Time::now();

  base_pose.pose.position.x = -0.15;
  base_pose.pose.position.y = req.relative_y;
  base_pose.pose.position.z = 0;

  base_pose.pose.orientation.x = 0;
  base_pose.pose.orientation.y = 0;
  base_pose.pose.orientation.z = 0;
  base_pose.pose.orientation.w = 1;

  geometry_msgs::PoseStamped map_pose;

  try{
    listener_->waitForTransform("map", "base_link", ros::Time::now(), ros::Duration(3.0));
    listener_->transformPose("map", base_pose, map_pose);
  }
  catch(tf::TransformException& ex)
  {
    ROS_ERROR("Received an exception trying to transform a point from \"base_link\" to \"base_map\": %s", ex.what());
  }

  ROS_INFO_STREAM(base_pose);
  ROS_INFO_STREAM(map_pose);

  // check if position in positions.yaml already exists
  // if yes overwrite old positions
  // if not create new position

  if(node[new_pose_name])
  {
    node[new_pose_name][0] = map_pose.pose.position.x;  // node["seq"] automatically becomes a sequence
    node[new_pose_name][1] = map_pose.pose.position.y;
    node[new_pose_name][2] = map_pose.pose.position.z;
    node[new_pose_name][3] = map_pose.pose.orientation.x;
    node[new_pose_name][4] = map_pose.pose.orientation.y;
    node[new_pose_name][5] = map_pose.pose.orientation.z;
    node[new_pose_name][6] = map_pose.pose.orientation.w;
  }
  else{
    node[new_pose_name].push_back(map_pose.pose.position.x);  // node["seq"] automatically becomes a sequence
    node[new_pose_name].push_back(map_pose.pose.position.y);
    node[new_pose_name].push_back(map_pose.pose.position.z);
    node[new_pose_name].push_back(map_pose.pose.orientation.x);
    node[new_pose_name].push_back(map_pose.pose.orientation.y);
    node[new_pose_name].push_back(map_pose.pose.orientation.z);
    node[new_pose_name].push_back(map_pose.pose.orientation.w);
  }

  ROS_INFO_STREAM(node[new_pose_name]);

  std::ofstream fout(file_path.c_str());
  fout << node;

  std::string info;
  info = "Saved to: ";
  info.append(file_path);

  res.information = info;
  res.sucess = true;
}

// ServiceServer to remove position in positions.yaml
bool cleanRunService(autonome_navigation::PositionService::Request  &req,
                           autonome_navigation::PositionService::Response &res)
{
    std::string backup_path;

    backup_path = ros::package::getPath("autonome_navigation").c_str();
    backup_path.append("/poses/backup.yaml");

    std::string backup_path_2;

    backup_path_2 = ros::package::getPath("autonome_navigation").c_str();
    backup_path_2.append("/poses/backup2.yaml");

    YAML::Node backup_node;
    YAML::Node backup_node_2;
    YAML::Node empty_node;

    empty_node.reset();

    std::string pyramids_path;

    pyramids_path = ros::package::getPath("autonome_navigation").c_str();
    pyramids_path.append("/poses/Pyramide.yaml");

    std::string trays_path;

    trays_path = ros::package::getPath("autonome_navigation").c_str();
    trays_path.append("/poses/Tray.yaml");

    std::string hidden_trays_path;

    hidden_trays_path = ros::package::getPath("autonome_navigation").c_str();
    hidden_trays_path.append("/poses/HiddenTray.yaml");

    if(fexists(backup_path))
    {
        backup_node = YAML::LoadFile(backup_path);
        backup_node_2 = YAML::LoadFile(backup_path_2);


        std::ofstream fout(pyramids_path.c_str());
        ROS_INFO("opened pyromids file");
        fout << backup_node;
        ROS_INFO("saved pyromids file");

        fout.close();
        ROS_INFO("closed pyromids file");

        fout.open(trays_path.c_str());
        ROS_INFO("opened tray file");

        fout << " ";
        ROS_INFO("cleared tray file");

        fout.close();
        ROS_INFO("closed tray file");

        fout.open(hidden_trays_path.c_str());
        ROS_INFO("opened hiddentray file");

        fout << backup_node_2;
        ROS_INFO("saved hiddentray file");

        fout.close();
        ROS_INFO("closed hiddentray file");


        return true;

    }
    else
    {
        return false;
    }
}

//
bool removePositionService(autonome_navigation::PositionService::Request  &req,
                           autonome_navigation::PositionService::Response &res)
{
  std::string new_pose_name = req.position_name;
  std::string file_path;
  std::string file_name = req.file_name;
  std::string info;

  YAML::Node node;
  YAML::Node nodeAbbild;

  // check if req has filename

  if(!(file_name == ""))
  {
    file_path = ros::package::getPath("autonome_navigation").c_str();
    file_path.append("/poses/");
    file_path.append(req.file_name);
  }
  else
  {
    file_path = path_;
  }

  // check if position.yaml already exists
  if(fexists(file_path))
  {
    node = YAML::LoadFile(file_path);// Load current file in node


    ROS_INFO_STREAM("opened :"  << file_path);

    // check if position in positions.yaml already exists
    // if yes overwrite old positions
    // if not create new

    if(node[new_pose_name])
    {
      ROS_INFO("exists");
      // Add all values to nodeAbbild instead of that one which should be erased
      for (YAML::const_iterator it = node.begin(); it != node.end(); ++it)
      {
        ROS_INFO("in");
        if (it->first.as<std::string>() != new_pose_name)
        {
          nodeAbbild[it->first] = node[it->first];
          nodeAbbild[it->second] = node[it->second];  // node["seq"] automatically becomes a sequence
        }else{
          ROS_INFO("deleted");
        }
      }



      // Reset existing File
      node.reset();

      std::ofstream kout(file_path.c_str());
      kout << nodeAbbild;

      // Write new File
      //std::ofstream fout(file_path.c_str());
      //fout << nodeAbbild;


      info = "removed: ";
      info.append(new_pose_name);
      info.append(" from ");
      info.append(file_path);
    }

    else
    {

      info = new_pose_name;
      info.append(" not found in ");
      info.append(file_path);
    }
    res.information = info;
    res.sucess = true;
  }
}

// subscriber callback for getting current pose from amcl (addaptive monte carlo localisation)
void currentPoseCb(const geometry_msgs::PoseWithCovarianceStamped &msg)
{
  currentPose_ = msg.pose.pose;
}

// Main

int main(int argc, char **argv)
{
  ros::init(argc, argv, "save_position");
  ros::NodeHandle nh;
  tf::TransformListener listener;
  listener_ = &listener;

  // load parameters
  nh.param<std::string>("autonome_navigation/file_name", file_name_, "test.yaml");

  path_ = ros::package::getPath("autonome_navigation").c_str();
  path_.append("/poses/");
  path_.append(file_name_);

  ROS_INFO_STREAM("Path to positions-file is:");
  ROS_INFO_STREAM(path_);

  current_position_sub_ = nh.subscribe("/amcl_pose",1,currentPoseCb);
  position_server_ = nh.advertiseService("/autonome_navigation/save_position", savePositionService);
  position_relative_server_ = nh.advertiseService("/autonome_navigation/save_position_relative_to_base", saveRelativePositionService);
  clean_server_ = nh.advertiseService("/autonome_navigation/clean", cleanRunService);

  remove_server_ = nh.advertiseService("/autonome_navigation/remove_position", removePositionService);

  ROS_INFO("Node is spinning");
  ros::spin();
}
