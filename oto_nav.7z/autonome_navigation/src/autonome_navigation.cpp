#include <autonome_navigation/autonome_navigation.h>

bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

// callbacks
bool getClosestTarget(autonome_navigation::PositionService::Request  &req,
                      autonome_navigation::PositionService::Response &res)
{
  ROS_INFO("IN SERVICE GET CLOSEST TARGET");
  bool filter;
  std::vector<std::string> filter_vec;

  if(req.filter.size() > 0)
  { 
    filter_vec = req.filter;
    if(filter_vec.at(0) != "")
    {
      ROS_INFO("- search for closest with filter");
      for(size_t at = 0; at < filter_vec.size(); at ++)
      {
        std::string test = filter_vec.at(at);
        ROS_INFO_STREAM(test);
      }
      filter = true;
    }
    else
    {
      ROS_INFO("- search for closest without filter");
      filter = false;
    }
  }
  else
  {
    ROS_INFO("- search for closest without filter");
    filter = false;
  }

  // clear costmap
  std_srvs::Empty srv_dummy;
  clear_costmap_cient_.call(srv_dummy);

  ROS_INFO("- cleared Costmap");
  ros::Duration(1).sleep();

  // save information
  std::string file_name = req.file_name;

  std::string file_path_close;
  YAML::Node node_close;

  geometry_msgs::PoseStamped currentPose_close_;
  geometry_msgs::PoseStamped pose_from_file_Posestamped_;

  nav_msgs::GetPlan plan_;
  unsigned int length_path_ = 999999;
  bool closest_found = false;


  std::string nearest_object_;


  //wait for pose


  file_path_close = ros::package::getPath("autonome_navigation").c_str();
  file_path_close.append("/poses/");
  file_path_close.append(file_name);



  if(fexists(file_path_close))
  {
    node_close = YAML::LoadFile(file_path_close);
    ROS_INFO_STREAM("- opened :"  << file_path_close);

    //getting current pose
    currentPose_close_.pose.position.x = currentPose_.position.x;
    currentPose_close_.pose.position.y = currentPose_.position.y;
    currentPose_close_.pose.position.z = currentPose_.position.z;

    currentPose_close_.pose.orientation.x = currentPose_.orientation.x;
    currentPose_close_.pose.orientation.y = currentPose_.orientation.y;
    currentPose_close_.pose.orientation.z = currentPose_.orientation.z;
    currentPose_close_.pose.orientation.w = currentPose_.orientation.w;

    currentPose_close_.header.stamp = ros::Time::now();
    currentPose_close_.header.frame_id = "/map" ;

    ROS_INFO("- got current pose");
    ROS_INFO("- search for closest");

    for (YAML::const_iterator it = node_close.begin(); it != node_close.end(); ++it)
    {

      // service callclear costmap

      YAML::Node temp_node;
      // from file to vector
      temp_node = it->second;

      //from vector to PoseStamped
      pose_from_file_Posestamped_.pose.position.x = temp_node[0].as<double>();
      pose_from_file_Posestamped_.pose.position.y = temp_node[1].as<double>();
      pose_from_file_Posestamped_.pose.position.z = temp_node[2].as<double>();

      pose_from_file_Posestamped_.pose.orientation.x = temp_node[3].as<double>();
      pose_from_file_Posestamped_.pose.orientation.y = temp_node[4].as<double>();
      pose_from_file_Posestamped_.pose.orientation.z = temp_node[5].as<double>();
      pose_from_file_Posestamped_.pose.orientation.w = temp_node[6].as<double>();

      pose_from_file_Posestamped_.header.stamp = ros::Time::now();
      pose_from_file_Posestamped_.header.frame_id = "/map";

      // create path servive msg
      plan_.request.start = currentPose_close_;
      plan_.request.goal = pose_from_file_Posestamped_;

      // call service "get path"
      get_costmap_client_.call(plan_);

      ROS_INFO_STREAM(it->first.as<std::string>());
      ROS_INFO_STREAM(plan_.response.plan.poses.size());

      if (length_path_ > plan_.response.plan.poses.size() && plan_.response.plan.poses.size() > 0)
      {
        if(filter)
        {
          std::string name_pose = it->first.as<std::string>();
          for(unsigned int  i= 0; i < filter_vec.size(); i++)
          {
            if(name_pose == filter_vec.at(i))
            {
              closest_found = true;
              length_path_ = plan_.response.plan.poses.size();
              nearest_object_ = it->first.as<std::string>();
            }
          }
        }
        else
        {
          closest_found = true;
          length_path_ = plan_.response.plan.poses.size();
          nearest_object_ = it->first.as<std::string>();
        }

      }

    }

  }
  else
  {
    ROS_INFO_STREAM(file_name << " doesn't exist at path: "  << file_path_close);
    nearest_object_ = file_name;
    nearest_object_.append( " doesn't exist at path: ");
    nearest_object_.append(file_path_close);
  }

  ROS_INFO_STREAM(" ");
  ROS_INFO_STREAM("RESULT:");
  ROS_INFO_STREAM("fastest path to: " << nearest_object_<< " with legnth: "<< length_path_);
  ROS_INFO_STREAM(" ");

  res.sucess = closest_found;
  res.next_target = nearest_object_;

  return true;
}

bool getTargetService(autonome_navigation::PositionService::Request  &req,
                      autonome_navigation::PositionService::Response &res)
{
  ROS_INFO("Service getTargetService called");
  std::string target_name = req.position_name;
  std::string file_path;
  std::string file_name = req.file_name;

  YAML::Node node;

  if(!(file_name == ""))
  {
    file_path = ros::package::getPath("autonome_navigation").c_str();
    file_path.append("/poses/");
    file_path.append(req.file_name);
  }
  else
  {
    file_path = path_;
  }

  if(fexists(file_path))
  {
    node = YAML::LoadFile(file_path);

    if(node[target_name])
    {
      move_base_msgs::MoveBaseGoal goal;

      // create a msgs for action client
      goal.target_pose.header.frame_id = "/map";
      goal.target_pose.header.stamp = ros::Time::now();

      goal.target_pose.pose.position.x = node[target_name][0].as<double>();
      goal.target_pose.pose.position.y = node[target_name][1].as<double>();
      goal.target_pose.pose.position.z = node[target_name][2].as<double>();

      goal.target_pose.pose.orientation.x = node[target_name][3].as<double>();
      goal.target_pose.pose.orientation.y = node[target_name][4].as<double>();
      goal.target_pose.pose.orientation.z = node[target_name][5].as<double>();
      goal.target_pose.pose.orientation.w = node[target_name][6].as<double>();

      res.information = "target send to move_base";
      res.sucess = true;

      //tell the action client that we want to spin a thread by default
      MoveBaseClient ac("move_base", true);

      //wait for the action server to come up
      while(!ac.waitForServer(ros::Duration(5.0))){
        ROS_INFO("Waiting for the move_base action server to come up");
      }
      // clear costmap
      ROS_INFO("clear costmap");
      std_srvs::Empty srv_dummy;
      clear_costmap_cient_.call(srv_dummy);
      ros::Duration(1).sleep();

      ROS_INFO_STREAM("Next target" << target_name);

      ROS_INFO("Sending goal");
      ac.sendGoal(goal);

      bool finished_in_time = ac.waitForResult(ros::Duration(25.0));

      ROS_INFO_STREAM(finished_in_time);
      if(finished_in_time)
      {
        ROS_INFO_STREAM(ac.getState().toString());
        if (ac.getState().toString() == "SUCCEEDED")
        {
          ROS_INFO("return true");
          res.sucess = true;
          res.information = "target reached";
          res.next_target = target_name;
        }
        else
        {
          res.sucess = false;
          res.information = "canceled";
        }
      }else
      {
        res.sucess = false;
        res.information = "out of time";
      }
    }
    else{
      res.information = "target is not saved in .yaml file";
      res.sucess = false;
    }
  }
  else{
    res.information = ".yaml file not found";
    res.sucess = false;
  }

  return res.sucess;


}

// subscriber callback for getting current pose from amcl (addaptive monte carlo localisation)
void currentPoseCb(const geometry_msgs::PoseWithCovarianceStamped &msg)
{
  currentPose_ = msg.pose.pose;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "autonome_navigation");
  ros::NodeHandle nh;

  // load parameters
  nh.param<std::string>("autonome_navigation/file_name", file_name_, "test.yaml");

  path_ = ros::package::getPath("autonome_navigation").c_str();
  path_.append("/poses/");
  path_.append(file_name_);

  ROS_INFO_STREAM("Path to positions-file is:");
  ROS_INFO_STREAM(path_);

  current_position_sub_ = nh.subscribe("/amcl_pose",1,currentPoseCb);
  get_costmap_client_ = nh.serviceClient<nav_msgs::GetPlan>("/move_base/GlobalPlanner/make_plan");
  clear_costmap_cient_ = nh.serviceClient<std_srvs::Empty>("/move_base/clear_costmaps");
  position_server_ = nh.advertiseService("/autonome_navigation/move_to_position", getTargetService);
  closest_target_server_ = nh.advertiseService("/autonome_navigation/get_closest_target", getClosestTarget);
  set_goal_pub_ = nh.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1);

  ROS_INFO("Node is spinning");
  ros::spin();
}
