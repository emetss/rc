#!/bin/bash

if (( $# != 2 )); then
    echo "Error: Wrong number of arguments"
    echo "Usage: rename.sh package_name node_name"
    exit
fi

cd "$(dirname "$0")"

package_name=$(echo $1 | tr '[:upper:]' '[:lower:]')
node_name=$(echo $2 | tr '[:upper:]' '[:lower:]')
include_guard=${1}_${2}
include_guard=$(echo $include_guard | tr '[:lower:]' '[:upper:]')
class_name=$(echo $2 | sed -r 's/(^|_)([a-z])/\U\2/g' )

# CMakeLists.txt
sed -i -- "s/my_pkg/$package_name/g" ./CMakeLists.txt
sed -i -- "s/my_node/$node_name/g" ./CMakeLists.txt

# package.xml
sed -i -- "s/my_pkg/$package_name/g" ./package.xml
sed -i -- "s/IMES Node Template/$package_name/g" ./package.xml

# launchfile
sed -i -- "s/my_pkg/$package_name/g" ./launch/my_launchfile.launch
sed -i -- "s/my_node/$node_name/g" ./launch/my_launchfile.launch

# header
sed -i -- "s/MyNode/$class_name/g" ./include/my_pkg/my_node.h
sed -i -- "s/MY_NODE/$include_guard/g" ./include/my_pkg/my_node.h
sed -i -- "s/my_pkg/$package_name/g" ./include/my_pkg/my_node.h

# src
sed -i -- "s/my_node_name/$node_name/g" ./src/my_node.cpp
sed -i -- "s/MyNode/$class_name/g" ./src/my_node.cpp
sed -i -- "s/my_pkg/$package_name/g" ./src/my_node.cpp
sed -i -- "s/my_namespace/$package_name/g" ./src/my_node.cpp
sed -i -- "s/my_node/$node_name/g" ./src/my_node.cpp

# rename files
mv ./launch/my_launchfile.launch ./launch/$node_name.launch
mv ./include/my_pkg/my_node.h ./include/my_pkg/$node_name.h
mv ./src/my_node.cpp ./src/$node_name.cpp
mv ./include/my_pkg ./include/$package_name
cd ..
mv ./my_pkg ./$package_name
cd $package_name

