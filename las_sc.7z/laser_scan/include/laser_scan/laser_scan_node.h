/* *****************************************************************
 *
 * laser_scan
 *
 * Copyright (c) %YEAR%,
 * Institute of Mechatronic Systems,
 * Leibniz Universitaet Hannover.
 * (BSD License)
 * All rights reserved.
 *
 * http://www.imes.uni-hannover.de
 *
 * This software is distributed WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE.
 *
 * For further information see http://www.linfo.org/bsdlicense.html
 *
 ******************************************************************/

/**
 * @file   %FILENAME%
 * @author %USER% (%$EMAIL%)
 * @date   %DATE%
 *
 * @brief  Filedescription
 */

#ifndef LASER_SCAN_LASER_SCAN_NODE_H
#define LASER_SCAN_LASER_SCAN_NODE_H

#include "ros/ros.h"
#include "std_msgs/Float32MultiArray.h"
#include "std_srvs/Empty.h"
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Twist.h>
#include <vector>
#include <algorithm>


class LaserScanNode
{
public:
    LaserScanNode(ros::NodeHandle &node_handle);

private:
    // node handle
    ros::NodeHandle *node_;

    // ros communication
    ros::Subscriber subscriber_laserscan_front_;
    ros::Subscriber subscriber_laserscan_back_;

    ros::Publisher publisher_laserscan_front_;
    ros::Publisher publisher_laserscan_back_;

    // speed factor param
    float factor[10];

    // sektor param
    double SEKTOR1_RADIUS;
    double SEKTOR1_SUBZONE1_RADIUS;
    double SEKTOR1_SUBZONE2_RADIUS;

    double SEKTOR2_RADIUS;
    double SEKTOR2_SUBZONE1_RADIUS;
    double SEKTOR2_SUBZONE2_RADIUS;

    double SEKTOR3_RADIUS;
    double SEKTOR3_SUBZONE1_RADIUS;
    double SEKTOR3_SUBZONE2_RADIUS;

    double SEKTOR4_RADIUS;
    double SEKTOR4_SUBZONE1_RADIUS;
    double SEKTOR4_SUBZONE2_RADIUS;

    double SEKTOR5_RADIUS;
    double SEKTOR5_SUBZONE1_RADIUS;
    double SEKTOR5_SUBZONE2_RADIUS;

    double SEKTOR6_RADIUS;
    double SEKTOR6_SUBZONE1_RADIUS;
    double SEKTOR6_SUBZONE2_RADIUS;

    double SEKTOR7_RADIUS;
    double SEKTOR7_SUBZONE1_RADIUS;
    double SEKTOR7_SUBZONE2_RADIUS;

    double SEKTOR8_RADIUS;
    double SEKTOR8_SUBZONE1_RADIUS;
    double SEKTOR8_SUBZONE2_RADIUS;

    double SEKTOR9_RADIUS;
    double SEKTOR9_SUBZONE1_RADIUS;
    double SEKTOR9_SUBZONE2_RADIUS;

    double SEKTOR10_RADIUS;
    double SEKTOR10_SUBZONE1_RADIUS;
    double SEKTOR10_SUBZONE2_RADIUS;

    // callbacks
    void subscriberCallback_Front(const sensor_msgs::LaserScan &msg);
    void subscriberCallback_Back(const sensor_msgs::LaserScan &msg);
};

#endif // LASER_SCAN_LASER_SCAN_NODE_H
