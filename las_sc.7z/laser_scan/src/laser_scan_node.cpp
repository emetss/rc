/* *****************************************************************
 *
 * laser_scan
 *
 * Copyright (c) %YEAR%,
 * Institute of Mechatronic Systems,
 * Leibniz Universitaet Hannover.
 * (BSD License)
 * All rights reserved.
 *
 * http://www.imes.uni-hannover.de
 *
 * This software is distributed WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE.
 *
 * For further information see http://www.linfo.org/bsdlicense.html
 *
 ******************************************************************/

/**
 * @file   %FILENAME%
 * @author %USER% (%$EMAIL%)
 * @date   %DATE%
 *
 * @brief  Filedescription
 */

#include "laser_scan/laser_scan_node.h"


//############################################################################################################################
//####################################################### CONSTRUCTOR ########################################################
//############################################################################################################################
/*
 * output="screen" launchfile auskommentiert
 * /scan      -> laser_scan_node (subcriber)
 * /scan_back -> laser_scan_node (subcriber)
 *               laser_scan_node (publisher) -> object_detection/front
 *               laser_scan_node (publisher) -> object_detection/back
*/
//############################################################################################################################
//############################################################################################################################
//############################################################################################################################
LaserScanNode::LaserScanNode(ros::NodeHandle &node_handle):
    node_(&node_handle)
{

    // === PARAM ===
    node_->param("laser_scan_detection/SEKTOR1_RADIUS", SEKTOR1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR1_SUBZONE1_RADIUS", SEKTOR1_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR1_SUBZONE2_RADIUS", SEKTOR1_SUBZONE2_RADIUS, 0.5);

    node_->param("laser_scan_detection/SEKTOR2_RADIUS", SEKTOR2_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR2_SUBZONE1_RADIUS", SEKTOR2_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR2_SUBZONE2_RADIUS", SEKTOR2_SUBZONE2_RADIUS, 0.5);

    node_->param("laser_scan_detection/SEKTOR3_RADIUS", SEKTOR3_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR3_SUBZONE1_RADIUS", SEKTOR3_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR3_SUBZONE2_RADIUS", SEKTOR3_SUBZONE2_RADIUS, 0.5);

    node_->param("laser_scan_detection/SEKTOR4_RADIUS", SEKTOR4_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR4_SUBZONE1_RADIUS", SEKTOR4_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR4_SUBZONE2_RADIUS", SEKTOR4_SUBZONE2_RADIUS, 0.5);

    node_->param("laser_scan_detection/SEKTOR5_RADIUS", SEKTOR5_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR5_SUBZONE1_RADIUS", SEKTOR5_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR5_SUBZONE2_RADIUS", SEKTOR5_SUBZONE2_RADIUS, 0.5);

    node_->param("laser_scan_detection/SEKTOR6_RADIUS", SEKTOR6_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR6_SUBZONE1_RADIUS", SEKTOR6_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR6_SUBZONE2_RADIUS", SEKTOR6_SUBZONE2_RADIUS, 0.5);

    node_->param("laser_scan_detection/SEKTOR7_RADIUS", SEKTOR7_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR7_SUBZONE1_RADIUS", SEKTOR7_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR7_SUBZONE2_RADIUS", SEKTOR7_SUBZONE2_RADIUS, 0.5);


    node_->param("laser_scan_detection/SEKTOR8_RADIUS", SEKTOR8_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR8_SUBZONE1_RADIUS", SEKTOR8_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR8_SUBZONE2_RADIUS", SEKTOR8_SUBZONE2_RADIUS, 0.5);

    node_->param("laser_scan_detection/SEKTOR9_RADIUS", SEKTOR9_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR9_SUBZONE1_RADIUS", SEKTOR9_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR9_SUBZONE2_RADIUS", SEKTOR9_SUBZONE2_RADIUS, 0.5);

    node_->param("laser_scan_detection/SEKTOR10_RADIUS", SEKTOR10_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR10_SUBZONE1_RADIUS", SEKTOR10_SUBZONE1_RADIUS, 0.5);
    node_->param("laser_scan_detection/SEKTOR10_SUBZONE2_RADIUS", SEKTOR10_SUBZONE2_RADIUS, 0.5);

    // === SUBSCRIBERS ===
    subscriber_laserscan_front_ = node_->subscribe("scan", 10, &LaserScanNode::subscriberCallback_Front, this);
    subscriber_laserscan_back_ = node_->subscribe("scan_back", 10, &LaserScanNode::subscriberCallback_Back, this);

    // === PUBLISHERS ===
    publisher_laserscan_front_ = node_->advertise<std_msgs::Float32MultiArray>("/collusion_detection/front", 10);
    publisher_laserscan_back_ = node_->advertise<std_msgs::Float32MultiArray>("/collusion_detection/back", 10);
}


//############################################################################################################################
//################################################ CALLBACK: SUBSCRIBER FRONT ################################################
//############################################################################################################################
/*
 * angle_min:       -1.8   rad ^ -103  deg
 * angle_max:        1.8   rad ^  103  deg
 * angle_increment:  0.006 rad ^  0.35 deg
 *
 *              Range [degree]     Radius [cm]     Index     Speed Factor
 * Sector 1     -103 -> -90           35          0 ->  37    factor[0]
 * Sector 2     -90  -> -48           30         38 -> 158    factor[1]
 * Sector 3     -48  ->  48           25        159 -> 433    factor[2]
 * Sector 4      48  ->  90           30        434 -> 554    factor[3]
 * Sector 5      90  ->  103          35        555 -> 587    factor[4]
 *
 *            0 deg
 *              ^
 *              |
 *              |
 * 90 deg <-----------> -90 deg
 */
//############################################################################################################################
//############################################################################################################################
//############################################################################################################################
void LaserScanNode::subscriberCallback_Front(const sensor_msgs::LaserScan &msg)
{
    unsigned int i;
    //unsigned int num;
    float smallest_element;

    std_msgs::Float32MultiArray publish_msg_front;
    publish_msg_front.data.resize(5);

    //num = msg.ranges.size();// Number of readings num = 588
    //ROS_INFO("Number of readings: %d);

    /*****************************************************************************************/
    /**************************************** Sektor1 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin(), msg.ranges.begin()+37);
    factor[0] = 1;// 100% full speed, if object located outside sector 1
    if((smallest_element < SEKTOR1_RADIUS) && (smallest_element >= SEKTOR1_SUBZONE1_RADIUS))
        factor[0] = 0.6;// 60% full speed, if object located inside sector 1
    if((smallest_element < SEKTOR1_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR1_SUBZONE2_RADIUS))
        factor[0] = 0.4;// 40% full speed, if object located inside sector 1 subzone 1
    if(smallest_element < SEKTOR1_SUBZONE2_RADIUS)
    {
        factor[0] = 0;// 0% full speed, if object located inside sector 1 subzone 2
        ROS_INFO("Sector 1 too close, danger!");
    }

    /*****************************************************************************************/
    /**************************************** Sektor2 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin()+38, msg.ranges.begin()+158);
    factor[1] = 1;// 100% full speed, if object located outside sector 2
    if((smallest_element < SEKTOR2_RADIUS) && (smallest_element >= SEKTOR2_SUBZONE1_RADIUS))
        factor[1] = 0.6;// 60% full speed, if object located inside sector 2
    if((smallest_element < SEKTOR2_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR2_SUBZONE2_RADIUS))
        factor[1] = 0.4;// 40% full speed, if object located inside sector 2 subzone 1
    if(smallest_element < SEKTOR2_SUBZONE2_RADIUS)
    {
        factor[1] = 0;// 0% full speed, if object located inside sector 2 subzone 2
        ROS_INFO("Sector 2 too close, danger!");
    }

    /*****************************************************************************************/
    /**************************************** Sektor3 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin()+159, msg.ranges.begin()+433);
    factor[2] = 1;// 100% full speed, if object located outside sector 3
    if((smallest_element < SEKTOR3_RADIUS) && (smallest_element >= SEKTOR3_SUBZONE1_RADIUS))
        factor[2] = 0.6;// 60% full speed, if object located inside sector 3
    if((smallest_element < SEKTOR3_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR3_SUBZONE2_RADIUS))
        factor[2] = 0.4;// 40% full speed, if object located inside sector 3 subzone 1
    if(smallest_element < SEKTOR3_SUBZONE2_RADIUS)
    {
        factor[2] = 0;// 0% full speed, if object located inside sector 3 subzone 2
        ROS_INFO("Sector 3 too close, danger!");
    }

    /*****************************************************************************************/
    /**************************************** Sektor4 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin()+434, msg.ranges.begin()+554);
    factor[3] = 1;// 100% full speed, if object located outside sector 4
    if((smallest_element < SEKTOR4_RADIUS) && (smallest_element >= SEKTOR4_SUBZONE1_RADIUS))
        factor[3] = 0.6;// 60% full speed, if object located inside sector 4
    if((smallest_element < SEKTOR4_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR4_SUBZONE2_RADIUS))
        factor[3] = 0.4;// 40% full speed, if object located inside sector 4 subzone 1
    if(smallest_element < SEKTOR4_SUBZONE2_RADIUS)
    {
        factor[3] = 0;// 0% full speed, if object located inside sector 4 subzone 2
        ROS_INFO("Sector 4 too close, danger!");
    }

    /*****************************************************************************************/
    /**************************************** Sektor5 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin()+555, msg.ranges.begin()+588);
    factor[4] = 1;// 100% full speed, if object located outside sector 5
    if((smallest_element < SEKTOR5_RADIUS) && (smallest_element >= SEKTOR5_SUBZONE1_RADIUS))
        factor[4] = 0.6;// 60% full speed, if object located inside sector 5
    if((smallest_element < SEKTOR5_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR5_SUBZONE2_RADIUS))
        factor[4] = 0.4;// 40% full speed, if object located inside sector 5 subzone 1
    if(smallest_element < SEKTOR5_SUBZONE2_RADIUS)
    {
        factor[4] = 0;// 0% full speed, if object located inside sector 5 subzone 2
        ROS_INFO("Sector 5 too close, danger!");
    }

    for(size_t i = 0; i < 5; i++)
    {
      publish_msg_front.data[i] = factor[i];
    }
    publisher_laserscan_front_.publish(publish_msg_front);
}


//############################################################################################################################
//################################################ CALLBACK: SUBSCRIBER BACK #################################################
//############################################################################################################################
/*
 * angle_min:       -1.8   rad ^ -103  deg
 * angle_max:        1.8   rad ^  103  deg
 * angle_increment:  0.006 rad ^  0.35 deg
 *
 *              Range [degree]     Radius [cm]     Index     Speed Factor
 * Sector 6     -103 -> -90           35          0 ->  37    factor[5]
 * Sector 7     -90  -> -48           30         38 -> 158    factor[6]
 * Sector 8     -48  ->  48           25        159 -> 433    factor[7]
 * Sector 9      48  ->  90           30        434 -> 554    factor[8]
 * Sector 10     90  ->  103          35        555 -> 587    factor[9]
 *
 *            0 deg
 *              ^
 *              |
 *              |
 * 90 deg <-----------> -90 deg
 */
//############################################################################################################################
//############################################################################################################################
//############################################################################################################################
void LaserScanNode::subscriberCallback_Back(const sensor_msgs::LaserScan &msg)
{
    unsigned int i;
    //unsigned int num;
    float smallest_element;

    std_msgs::Float32MultiArray publish_msg_back;
    publish_msg_back.data.resize(5);

    //num = msg.ranges.size();// Number of readings num = 588
    //ROS_INFO("Number of readings: %d);

    /*****************************************************************************************/
    /**************************************** Sektor6 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin(), msg.ranges.begin()+37);
    factor[5] = 1;// 100% full speed, if object located outside sector 6
    if((smallest_element < SEKTOR6_RADIUS) && (smallest_element >= SEKTOR6_SUBZONE1_RADIUS))
        factor[5] = 0.6;// 60% full speed, if object located inside sector 6
    if((smallest_element < SEKTOR6_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR6_SUBZONE2_RADIUS))
        factor[5] = 0.4;// 40% full speed, if object located inside sector 6 subzone 1
    if(smallest_element < SEKTOR6_SUBZONE2_RADIUS)
    {
        factor[5] = 0;// 0% full speed, if object located inside sector 6 subzone 2
        ROS_INFO("Sector 6 too close, danger!");
    }

    /*****************************************************************************************/
    /**************************************** Sektor7 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin()+38, msg.ranges.begin()+158);
    factor[6] = 1;// 100% full speed, if object located outside sector 7
    if((smallest_element < SEKTOR7_RADIUS) && (smallest_element >= SEKTOR7_SUBZONE1_RADIUS))
        factor[6] = 0.6;// 60% full speed, if object located inside sector 7
    if((smallest_element < SEKTOR7_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR7_SUBZONE2_RADIUS))
        factor[6] = 0.4;// 40% full speed, if object located inside sector 7 subzone 1
    if(smallest_element < SEKTOR7_SUBZONE2_RADIUS)
    {
        factor[6] = 0;// 0% full speed, if object located inside sector 7 subzone 2
        ROS_INFO("Sector 7 too close, danger!");
    }

    /*****************************************************************************************/
    /**************************************** Sektor8 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin()+159, msg.ranges.begin()+433);
    factor[7] = 1;// 100% full speed, if object located outside sector 8
    if((smallest_element < SEKTOR8_RADIUS) && (smallest_element >= SEKTOR8_SUBZONE1_RADIUS))
        factor[7] = 0.6;// 60% full speed, if object located inside sector 8
    if((smallest_element < SEKTOR8_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR8_SUBZONE2_RADIUS))
        factor[7] = 0.4;// 40% full speed, if object located inside sector 8 subzone 1
    if(smallest_element < SEKTOR8_SUBZONE2_RADIUS)
    {
        factor[7] = 0;// 0% full speed, if object located inside sector 8 subzone 2
        ROS_INFO("Sector 8 too close, danger!");
    }

    /*****************************************************************************************/
    /**************************************** Sektor9 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin()+434, msg.ranges.begin()+554);
    factor[8] = 1;// 100% full speed, if object located outside sector 9
    if((smallest_element < SEKTOR9_RADIUS) && (smallest_element >= SEKTOR9_SUBZONE1_RADIUS))
        factor[8] = 0.6;// 60% full speed, if object located inside sector 9
    if((smallest_element < SEKTOR9_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR9_SUBZONE2_RADIUS))
        factor[8] = 0.4;// 40% full speed, if object located inside sector 9 subzone 1
    if(smallest_element< SEKTOR9_SUBZONE2_RADIUS)
    {
        factor[8] = 0;// 0% full speed, if object located inside sector 9 subzone 2
        ROS_INFO("Sector 9 too close, danger!");
    }

    /*****************************************************************************************/
    /**************************************** Sektor10 ****************************************/
    /*****************************************************************************************/
    smallest_element = *std::min_element(msg.ranges.begin()+555, msg.ranges.begin()+588);
    factor[9] = 1;// 100% full speed, if object located outside sector 10
    if((smallest_element < SEKTOR10_RADIUS) && (smallest_element >= SEKTOR10_SUBZONE1_RADIUS))
        factor[9] = 0.6;// 60% full speed, if object located inside sector 10
    if((smallest_element < SEKTOR10_SUBZONE1_RADIUS) && (smallest_element >= SEKTOR10_SUBZONE2_RADIUS))
        factor[9] = 0.4;// 40% full speed, if object located inside sector 10 subzone 1
    if(smallest_element< SEKTOR10_SUBZONE2_RADIUS)
    {
        factor[9] = 0;// 0% full speed, if object located inside sector 10 subzone 2
        ROS_INFO("Sector 10 too close, danger!");
    }

    for(size_t i = 5; i < 10; i++)
    {
      publish_msg_back.data[i-5] = factor[i];
    }
    publisher_laserscan_back_.publish(publish_msg_back);
}


//############################################################################################################################
//########################################################## MAIN ############################################################
//############################################################################################################################
int main(int argc, char** argv)
{
    ros::init(argc, argv, "laser_scan_node");

    ros::NodeHandle node_handle;
    LaserScanNode laser_scan_node(node_handle);

    ROS_INFO("Node is spinning...");
    ros::spin();

    return 0;
}
